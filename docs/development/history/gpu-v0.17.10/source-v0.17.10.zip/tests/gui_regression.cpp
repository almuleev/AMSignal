// Integration tests linked to the production GUI modules; no visible windows.
#include "../gui_dialogs.hpp"
#include "../gui_analysis_source.hpp"
#include "../gui_analysis_range.hpp"
#include "../gui_marker_values.hpp"
#include "../gui_gap_details.hpp"
#include "../gui_menu.hpp"
#include "../gui_commands.hpp"
#include "../gui_frf.hpp"
#include "../gui_frequency_view.hpp"
#include "../gui_frf_render.hpp"
#include "../gui_input.hpp"
#include "../gui_navigation.hpp"
#include "../gui_playback.hpp"
#include "../gui_hotkeys.hpp"
#include "../gui_window.hpp"
#include "../gui_layout.hpp"
#include "../gui_export.hpp"
#include "../gui_export_metadata.hpp"
#include "../gui_ids.hpp"
#include "../gui_loading.hpp"
#include "../gui_loading_drop.hpp"
#include "../gui_documents.hpp"
#include "../gui_main.hpp"
#include "../gui_processing.hpp"
#include "../gui_render.hpp"
#include "../gui_render_data.hpp"
#include "../gui_spectrum.hpp"
#include "../gui_side_panel.hpp"
#include "../gui_state.hpp"
#include "../gui_state_history.hpp"
#include "../gui_status.hpp"
#include "../gui_text.hpp"
#include "../gui_theme.hpp"
#include "../gui_time_axis.hpp"
#include "../gui_settings_window.hpp"
#include "../gui_settings.hpp"
#include "../gui_resources.hpp"
#include "../gui_overview.hpp"
#include "../gui_overview_render.hpp"
#include "../gui_controls.hpp"
#include "../gui_recording_cache.hpp"
#include "../gui_recording_processing.hpp"
#include "../gui_filter_state_cache.hpp"
#include "../gui_source_export.hpp"
#include "../disk_spectrum.hpp"
#include "../analysis_executor.hpp"
#include "../gpu_fft.hpp"
using namespace gui;
#include <iostream>
#include <stdexcept>
#include <chrono>
#include <iomanip>
#include <psapi.h>
#include <future>
#include <set>
#ifdef near
#undef near
#endif

namespace {
int checks = 0;
void require(bool condition, const char* message) {
    ++checks;
    if (!condition) throw std::runtime_error(message);
}
void near(double actual, double expected, const char* message) {
    require(std::isfinite(actual) && std::fabs(actual - expected) < 1e-9, message);
}
const std::filesystem::path test_dir = "tests/_tmp_gui_regression";

void reset_document(const std::vector<std::string>& names, const std::vector<double>& time,
                    const std::vector<std::vector<double>>& channels) {
    cancel_recording_overview();
    g_overview_worker.trim_cache(0);
    g_frf_worker.cancel();
    g = App{};
    g_undo.clear(); g_redo.clear(); g_filter_slider_before.reset();
    g_str = &kEn;
    g_config_path = (test_dir / "settings.ini").wstring();
    g.ds.ok = true; g.ds.names = names; g.ds.time = time; g.ds.raw_time = time; g.ds.channels = channels;
    g.visible.assign(names.size(), 1);
    g.channel_colors.clear();
    for (const auto& name : names) g.channel_labels.push_back(to_w(name));
    g.data_t0 = g.win_start = time.front(); g.data_t1 = g.win_end = time.back();
    g.channel_formulas.assign(names.size(), L"x");
    ensure_channel_formula_vectors();
}

void reopen(const std::filesystem::path& path, bool dedup = false) {
    auto ds = lvm::read_lvm_file(path);
    require(ds.ok, "export must be readable");
    if (dedup) lvm::drop_duplicate_time_channels(ds, ds.raw_time);
    auto comments = ds.export_comments;
    reset_document(ds.names, ds.time, ds.channels);
    g.ds.frequency_axis = ds.frequency_axis;
    g.ds.export_comments = comments;
    apply_export_metadata_from_comments(comments);
}

void document_history_and_save_state() {
    reset_document({"A"}, {0, 1, 2, 3}, {{1, 2, 3, 4}});
    mark_active_document_saved();
    g.visual_smooth = true;
    mark_active_document_dirty();
    require(active_document_has_unsaved_changes(), "project graph setting marks the document dirty without an undo action");
    mark_active_document_saved();
    GuideLine first;
    first.value = 1.0;
    g.guides.push_back(first);
    UndoAction first_action;
    first_action.type = UndoAction::ADD_LINE;
    first_action.line = first;
    push_undo(first_action);
    require(active_document_has_unsaved_changes(), "editing a document marks its project dirty");
    pop_undo();
    require(!active_document_has_unsaved_changes(), "undoing to the saved revision clears the dirty state");
    pop_redo();
    require(active_document_has_unsaved_changes(), "redoing past the saved revision restores the dirty state");
    pop_undo();
    require(!active_document_has_unsaved_changes(), "undo returns to the original saved revision before branching");
    GuideLine branch;
    branch.value = 1.5;
    g.guides.push_back(branch);
    UndoAction branch_action;
    branch_action.type = UndoAction::ADD_LINE;
    branch_action.line = branch;
    push_undo(branch_action);
    require(active_document_has_unsaved_changes(), "a new branch after undo cannot reuse the saved revision");
    mark_active_document_saved();
    require(!active_document_has_unsaved_changes(), "successful project save records the active history revision");
    GuideLine after_save;
    after_save.value = 3.0;
    g.guides.push_back(after_save);
    UndoAction after_save_action;
    after_save_action.type = UndoAction::ADD_LINE;
    after_save_action.line = after_save;
    push_undo(after_save_action);
    require(active_document_has_unsaved_changes(), "new edit after saving marks the project dirty again");

    DocumentState other = static_cast<DocumentState&>(g);
    g.stitch_time_gaps=true;other.stitch_time_gaps=false;
    other.file_name = L"other.lvm";
    other.history.reset();
    other.project_revision = 0;
    other.next_project_revision = 0;
    other.saved_project_revision = 0;
    other.project_dirty = false;
    g.inactive_documents.push_back(std::move(other));
    const std::size_t first_history_count = g_undo.size();
    require(switch_to_document(1), "switches to an inactive document for independent history");
    require(!g.stitch_time_gaps,"switching files restores that file's independent stitching choice");
    require(g_undo.empty(), "inactive document starts with its own empty undo history");
    GuideLine second;
    second.value = 2.0;
    g.guides.push_back(second);
    UndoAction second_action;
    second_action.type = UndoAction::ADD_LINE;
    second_action.line = second;
    push_undo(second_action);
    require(g_undo.size() == 1, "second document receives its own undo action");
    require(switch_to_document(1), "switches back to the first document");
    require(g.stitch_time_gaps,"returning to the first file restores its enabled stitching");
    require(g_undo.size() == first_history_count, "first document restores its own undo history");
    require(active_document_has_unsaved_changes(), "first document restores its independent dirty state");
}

void exports() {
    ExportOptions opts;
    opts.selected_range = ExportRangeMode::Whole;
    opts.include_hidden_channels = true;
    const auto path = test_dir / std::filesystem::u8path(u8"измерение_測定.csv");
    reset_document({"A"}, {0,1,2,3}, {{10,11,12,13}});
    g.global_formula = L"2*x"; rebuild_formula_cache_from_state();
    require(save_tabular_export(path.wstring(), opts), "processed export");
    reopen(path);
    near(rendered_channel_sample(0,0), 20, "processed export must not apply formula twice");
    require(save_tabular_export(path.wstring(), opts), "second export");
    reopen(path);
    near(rendered_channel_sample(0,0), 20, "multiple roundtrips remain stable");

    reset_document({"A","B"}, {0,1,2,3}, {{10,11,12,13},{20,21,22,23}});
    g.visible = {0,1}; g.channel_formulas = {L"3*x",L"x+7"}; rebuild_formula_cache_from_state();
    opts.include_hidden_channels = false; opts.apply_processing_to_data = false;
    require(save_tabular_export(path.wstring(), opts), "subset export");
    reopen(path);
    require(g.ds.names == std::vector<std::string>{"B"} && g.visible[0], "subset identity and visibility");
    near(rendered_channel_sample(0,0), 27, "subset local formula mapping");

    reset_document({u8"Датчик, \"A\", visible=0","B"}, {0,1,2,3}, {{10,11,12,13},{20,21,22,23}});
    opts.include_hidden_channels = true;
    require(save_tabular_export(path.wstring(), opts), "quoted name export");
    reopen(path);
    require(g.ds.names[0] == u8"Датчик, \"A\", visible=0" && g.ds.names[1] == "B", "UTF-8 and metadata text escaping");

    reset_document({"A","B"}, {0,1,2,3}, {{10,11,12,13},{20,21,22,23}});
    opts.format = ExportFileFormat::Lvm;
    const auto lvm_path = test_dir / "roundtrip.lvm";
    require(save_lvm_export(lvm_path.wstring(), opts), "LVM export");
    auto parsed = lvm::read_lvm_file(lvm_path);
    require(parsed.ok, "read LVM");
    lvm::drop_duplicate_time_channels(parsed, parsed.raw_time);
    require(parsed.names == std::vector<std::string>{"A","B"}, "LVM labels match data without metadata import");
    near(parsed.channels[0][0], 10, "LVM channel A"); near(parsed.channels[1][3], 23, "LVM channel B");

    ExportOptions original;
    original.save_mode = ExportSaveMode::OriginalData;
    original.selected_range = ExportRangeMode::Whole;
    original.apply_processing_to_data = false;
    original.include_channel_names = true;
    original.include_hidden_channels = true;
    original.include_metadata = false;
    g.global_formula = L"5*x"; rebuild_formula_cache_from_state();
    const auto original_path = test_dir / "original.csv";
    require(save_tabular_export(original_path.wstring(), original), "original-data export");
    auto original_data = lvm::read_lvm_file(original_path);
    require(original_data.ok && original_data.export_comments.empty(), "original export contains no AMSignal settings");
    near(original_data.channels[0][0], 10, "original export retains unprocessed samples");

    g.visible = {1, 0};
    g.global_formula = L"2*x"; g.channel_formulas = {L"x+1", L"x-1"};
    g.noise_threshold_enabled = true; g.noise_threshold_min = 0.25; g.noise_threshold_max = 0.75;
    g.distinguish_curves = true;
    g.stitch_time_gaps = true;
    g.show_channel_legend = false;
    g.show_marker_values = false;
    g.frf.apply_processing = false;
    g.frf.logarithmic_frequency_axis = false;
    g.frf.show_reference_amplitude = false;
    g.frf.reference_height_fraction = .42;
    g.frf.reference_auto_y = false;
    g.frf.reference_y_min = -1.5;
    g.frf.reference_y_max = 7.5;
    rebuild_formula_cache_from_state();
    const auto project_path = test_dir / "roundtrip.AMSig";
    require(save_project_file(project_path.wstring()), "project export");
    reopen(project_path, true);
    require(g.ds.names == std::vector<std::string>{"A", "B"} && g.visible == std::vector<char>{1, 0},
            "project restores all channels and visibility");
    near(g.ds.channels[0][0], 10, "project retains raw samples");
    require(g.global_formula == L"2*x" && g.channel_formulas[0] == L"x+1",
            "project restores formulas without baking them into data");
    require(g.noise_threshold_enabled, "project restores filter settings");
    require(g.distinguish_curves, "project restores grayscale curve symbols");
    require(g.stitch_time_gaps,"project restores the document's stitching choice");
    require(!g.show_channel_legend, "project restores hidden channel legend");
    require(!g.show_marker_values,"project restores the marker readout visibility choice");
    require(!g.frf.apply_processing, "project restores the FRF raw-channel choice");
    require(!g.frf.logarithmic_frequency_axis && !g.frf.show_reference_amplitude &&
            std::fabs(g.frf.reference_height_fraction-.42)<1e-9 && !g.frf.reference_auto_y &&
            std::fabs(g.frf.reference_y_min+1.5)<1e-9 &&
            std::fabs(g.frf.reference_y_max-7.5)<1e-9,
            "project restores FRF axis and Reference graph display settings");

    opts.format = ExportFileFormat::Csv; opts.selected_range = ExportRangeMode::Visible;
    { std::ofstream out(path); out << "KEEP THIS FILE"; }
    g.win_start = 10; g.win_end = 11;
    require(!save_tabular_export(path.wstring(), opts), "invalid export fails");
    std::ifstream in(path); std::string content; std::getline(in, content);
    require(content == "KEEP THIS FILE", "failed export preserves destination");
}

void frf_project_roundtrip() {
    std::vector<double> t(1024),x(1024),z(1024),y(1024);
    for(std::size_t i=0;i<t.size();++i) {t[i]=i/1024.;x[i]=std::sin(2*std::acos(-1.)*32*i/1024.);z[i]=3*x[i];y[i]=4*x[i];}
    reset_document({"support A","support B","response"},t,{x,z,y});
    g.frf.inputs={0,1};g.frf.outputs={2};g.frf.options.segment_length=128;
    g.frf.options.remove_mean=false;g.frf.options.reference_threshold=2e-5;
    g.frf.display_smoothing_octaves=1./3.;g.frf.apply_processing=false;
    g.frf.auto_y=false;g.frf.y_min=.2;g.frf.y_max=3.;g.frf.frequency_start=8;g.frf.frequency_end=400;
    g.fft_window_active=true;g.fft_window_start=t[128];g.fft_window_end=t[895];
    g.global_formula=L"2*x";rebuild_formula_cache_from_state();
    require(ensure_current_frf(),"project regression computes the original selected FRF");
    const auto expected=g.frf.result.common();const auto path=test_dir/"frf_reproducible.AMSig";
    g.frf.auto_y=false;g.frf.y_min=.2;g.frf.y_max=3.;
    require(set_frf_frequency_range(8,400),"project regression selects physical viewing limits after calculation");
    require(save_project_file(path.wstring()),"FRF configuration saves with raw project data");reopen(path,true);
    require(g.frf.inputs==std::vector<int>{0,1} && g.frf.outputs==std::vector<int>{2},"project restores multiple reference and response identities");
    require(g.frf.options.estimator==lvm::FrfEstimator::H1 && g.frf.options.segment_length==128 && !g.frf.options.remove_mean && !g.frf.apply_processing,"project restores estimator, L, mean and raw/processed choice");
    near(g.frf.options.reference_threshold,2e-5,"project restores reference threshold");
    near(g.frf.display_smoothing_octaves,1./3.,"project restores display smoothing");
    require(g.fft_window_active && g.fft_window_start==t[128] && g.fft_window_end==t[895],"project restores the shared numerical interval");
    require(!g.frf.auto_y && g.frf.y_min==.2 && g.frf.y_max==3. && g.frf.frequency_start==8 && g.frf.frequency_end==400 && g.frf.view_initialized,"project restores FRF viewing limits");
    require(ensure_current_frf(),"reopened project recalculates without reselecting channels or parameters");
    const auto& actual=g.frf.result.common();
    require(actual.frequencies==expected.frequencies && actual.valid==expected.valid && actual.segment_length==expected.segment_length && actual.averages==expected.averages && actual.sample_count==expected.sample_count,"recalculation restores frequency grid and segment counts");
    for(std::size_t k=0;k<actual.valid.size();++k)if(actual.valid[k])require(std::abs(actual.transfer[k]-expected.transfer[k])<1e-12,"reopened complex H agrees with original");
    require(save_frf_csv((test_dir/"frf_passport.csv").wstring()),"FRF exports its analysis passport");
    const auto exported=lvm::read_lvm_file(path);
    require(std::find(exported.export_comments.begin(),exported.export_comments.end(),"application_version="+to_utf8(APP_VERSION_W))!=exported.export_comments.end(),"project records producing build version");
    g.frf.options.estimator=lvm::FrfEstimator::Direct;g.frf.options.segment_length=0;g.frf.display_smoothing_octaves=0;
    require(save_project_file(path.wstring()),"Direct Auto and unsmoothed project saves");reopen(path,true);
    require(g.frf.options.estimator==lvm::FrfEstimator::Direct && !g.frf.options.segment_length && !g.frf.display_smoothing_octaves,"Direct Auto and unsmoothed state survive reopening");
    require(ensure_current_frf(),"restored Direct project recalculates");
    reset_document({"hidden","support","response"},t,{z,x,y});g.visible={0,1,1};g.frf.inputs={1};g.frf.outputs={2};
    ExportOptions subset;subset.selected_range=ExportRangeMode::Whole;subset.apply_processing_to_data=false;subset.include_hidden_channels=false;
    require(save_tabular_export((test_dir/"frf_subset.csv").wstring(),subset),"subset export writes remapped FRF roles");reopen(test_dir/"frf_subset.csv");
    require(g.frf.inputs==std::vector<int>{0} && g.frf.outputs==std::vector<int>{1},"subset roles refer to exported columns");
    reset_document({"A","B"},t,{x,y});
    apply_export_metadata_from_comments({"[frf_settings]","references=1","responses=1","segment_length=-4","reference_threshold=nan"});
    require(g.frf.inputs.empty() && g.frf.outputs.empty() && !g.frf.options.segment_length && g.frf.options.reference_threshold==1e-6,"invalid or overlapping FRF settings rejected");
    apply_export_metadata_from_comments({"[graph_settings]","show_channel_legend=0"});
    require(!g.show_channel_legend && g.frf.inputs.empty(),"legacy project remains readable");
}

void processing() {
    frf_project_roundtrip();
    reset_document({"same","same"},{0,.1,.2,.3,.4,.5,.6,.7},{{1,0,-1,0,1,0,-1,0},{2,0,-2,0,2,0,-2,0}});
    compute_spectrum_for_window(0,.7,false);
    require(g.spec_channel_indices == std::vector<int>{0,1}, "duplicate names retain independent spectrum identities");
    g.global_formula=L"2*x"; rebuild_formula_cache_from_state();
    compute_spectrum_for_window(0,.7,false); g.mode = AnalysisMode::FFT;
    ExportOptions opts; opts.apply_processing_to_data=false; opts.include_hidden_channels=true;
    lvm::Spectrum spec; std::vector<int> ids; bool all=false;
    require(build_export_spectrum(opts,spec,ids,all), "raw spectrum export");
    const auto peaks=lvm::find_peaks(spec.freqs,spec.amp[0],1);
    require(!peaks.empty(), "raw spectrum peak"); near(peaks[0].amp,1,"raw FFT export ignores active formula");

    std::vector<double> time(1000), signal(1000,0);
    for(std::size_t i=0;i<time.size();++i) time[i]=double(i)/1000;
    signal[499]=1; signal[500]=std::nan("");
    reset_document({"signal"},time,{signal});
    g.noise_threshold_enabled=true;g.noise_threshold_mode=FilterModeBandPass;
    g.noise_threshold_topology=FilterTopologyLinkwitzRiley;g.noise_threshold_min=10;g.noise_threshold_max=100;
    ensure_filtered_channel_cache(0);
    near(g.filtered_channel_cache[0][501],0,"all LR stages reset after NaN");
    g.noise_threshold_enabled=false;
    g.global_formula=L"sqrt(x)";rebuild_formula_cache_from_state();
    require(std::isnan(transform_channel_value(0,-1)),"domain error does not silently restore input");

    constexpr std::size_t count=4096;
    constexpr double sample_rate=16384.0;
    constexpr double pi=3.14159265358979323846;
    std::vector<double> filter_time(count),mixed(count),response(count);
    for (std::size_t i=0;i<count;++i) {
        filter_time[i]=i/sample_rate;
        mixed[i]=std::sin(2*pi*1000*filter_time[i])+std::sin(2*pi*4000*filter_time[i]);
        response[i]=2*mixed[i];
    }
    reset_document({"Reference","Response"},filter_time,{mixed,response});
    compute_spectrum_for_window(filter_time.front(),filter_time.back(),false);
    const double raw_low=g.spec.amp[0][250],raw_high=g.spec.amp[0][1000];
    g.noise_threshold_enabled=true;
    g.noise_threshold_mode=FilterModeLowPass;
    g.noise_threshold_min=0;
    g.noise_threshold_max=2000;
    invalidate_filtered_channel_cache();
    compute_spectrum_for_window(filter_time.front(),filter_time.back(),false);
    require(g.spec.amp[0][250]>raw_low*.7,"2 kHz low-pass keeps the 1 kHz FFT component");
    require(g.spec.amp[0][1000]<raw_high*.3,"2 kHz low-pass attenuates, rather than removes, the 4 kHz FFT component");
    require(rendered_channel_sample(0,10)!=g.ds.channels[0][10],"Time view reads the filtered channel cache");
    require(g.frf.apply_processing,"new FRF documents apply active processing by default");
    require(set_frf_channels({0},{1}),"processed FRF test selects Reference and Response");
    g.frf.options.estimator=lvm::FrfEstimator::Direct;
    set_mode(AnalysisMode::FRF);
    require(g.frf.result.ok,"processed FRF is calculated");
    near(lvm::frf_dynamic_coefficient(g.frf.result.common(),250),2,"equal filtering of Reference and Response cancels in linear KD");
    require(g.frf.result.common().reference_amplitude[1000] < g.frf.result.common().reference_amplitude[250]*.3,
            "separate averaged Reference graph shows low-pass attenuation");
}

void fft_recording_recovery() {
    std::vector<double> time, signal;
    constexpr double pi = 3.14159265358979323846;
    for (int i = 0; i < 1152; ++i) {
        const int local = i < 128 ? i : i - 128;
        const double offset = i >= 128 && local > 0 && local < 1023 ? 0.0001 * std::sin(2 * pi * local / 17) : 0;
        const double t = (i < 128 ? 0 : 10) + local / 1024.0 + offset;
        time.push_back(t); signal.push_back(std::sin(2 * pi * 64 * t));
    }
    reset_document({"signal"}, time, {signal});
    compute_spectrum_for_window(time.front(), time.back(), false);
    require(g.spec_valid && g.spec.gaps_ignored && g.spec.resampled && g.spec.n == 1152, "GUI uses every jittered sample around a gap");
    require(g.spec_channel_indices == std::vector<int>{0}, "recovered FFT preserves GUI channel mapping");
    near(g.spec.source_start, 0, "GUI spectrum records the full selected interval");
    g_str = &kRu;
    const auto status = spectrum_sampling_status(g.spec);
    require(status.find(L"без учёта пропусков") != std::wstring::npos && status.find(L"интерполяция") != std::wstring::npos,
            "Russian status explains ignored gaps and interpolation");
    g_str = &kEn;

    // Exercise the real background worker, then its GUI completion handler.
    lvm::SpectrumWorker worker;
    worker.submit(g.ds, {7}, 1);
    worker.submit(g.ds, {0}, 2);
    std::optional<lvm::SpectrumWorker::Result> result;
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(10);
    while (!result && std::chrono::steady_clock::now() < deadline) {
        result = worker.take_result();
        if (!result) std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
    require(result && result->generation == 2, "worker publishes the latest FFT request");
    require(result->spectrum.ok && result->spectrum.resampled && result->spectrum.gaps_ignored && result->spectrum.n == 1152,
            "background FFT recovers the same irregular recording");
    g.freq_start = 0; g.freq_end = 1; g.spec_pending = true; g.spec_fit_pending = true;
    apply_spectrum_result(std::move(result->spectrum));
    require(g.spec_valid && !g.spec_pending && !g.spec_fit_pending, "GUI accepts background FFT result");
    near(g.freq_end, g.spec.nyquist, "background FFT restores full frequency axis");

    // Re-entering the same source window must still request a fresh axis fit.
    set_mode(AnalysisMode::FFT);
    require(g.spec_valid && g.freq_end > 100, "entering FFT fits the frequency axis");
    set_mode(AnalysisMode::Time); g.freq_end = 1;
    set_mode(AnalysisMode::FFT);
    near(g.freq_end, g.spec.nyquist, "re-entering FFT restores full frequency axis");

    ExportOptions opts; opts.selected_range = ExportRangeMode::Whole; opts.include_hidden_channels = true;
    const auto path = test_dir / "recovered_fft.csv";
    require(save_tabular_export(path.wstring(), opts), "recovered spectrum exports");
    const auto exported = lvm::read_lvm_file(path);
    require(exported.ok && exported.rows() == g.spec.freqs.size(), "recovered spectrum export has all frequency bins");
    bool source = false, resampled = false, gaps_ignored = false;
    for (const auto& comment : exported.export_comments) {
        source = source || comment == "source_start=0";
        resampled = resampled || comment == "resampled=1";
        gaps_ignored = gaps_ignored || comment == "gaps_ignored=1";
    }
    require(source && resampled && gaps_ignored, "export records full FFT source, interpolation and ignored gaps");
}

void fft_selected_gap_range() {
    // Selection boundaries lie between samples, inside gaps. Large outside
    // impulses must not leak into the FFT; both interior channels must survive.
    constexpr std::size_t count = 12032, lo = 100, hi = 11932;
    std::vector<double> time(count);
    std::vector<std::vector<double>> values(2, std::vector<double>(count));
    lvm::Dataset compact;
    compact.names = {"A", "B"}; compact.channels.resize(2);
    for (std::size_t i = 0; i < count; ++i) {
        time[i] = i ? time[i - 1] + (i % 8 ? 1025.0 : 1.0) / 1024 : 50.0;
        for (std::size_t c = 0; c < 2; ++c) {
            values[c][i] = i < lo || i >= hi ? 1e6 : std::sin(i * (0.13 + 0.2 * c));
            if (i >= lo && i < hi) compact.channels[c].push_back(values[c][i]);
        }
        if (i >= lo && i < hi) compact.time.push_back((i - lo) / 1024.0);
    }
    const auto expected = lvm::compute_spectrum(compact, 0);
    require(expected.ok, "selected-range FFT oracle");
    for (bool light : {false, true}) for (bool stitched : {false, true}) {
        reset_document({"A", "B"}, time, values);
        g.stitch_time_gaps = stitched; g.visible = {static_cast<char>(light), 1};
        const double start = (time[lo - 1] + time[lo]) / 2;
        const double end = (time[hi - 1] + time[hi]) / 2;
        set_fft_window(start, end);
        set_mode(AnalysisMode::FFT);
        require(g.spec_valid && g.spec.n == int(hi - lo) && g.spec_source_from_selection, "GUI FFT uses the entire selected range in every display mode");
        near(g.spec.source_start, time[lo], "selected FFT first included timestamp");
        near(g.spec.source_end, time[hi - 1], "selected FFT last included timestamp");
        require(g.spec.freqs == expected.freqs && g.spec.amp.back() == expected.amp[1], "selected GUI FFT matches all compact reference bins");
        require(g.spec.source_channels.back() == 1, "selected FFT keeps original visible channel identity");
        ExportOptions opts; opts.include_hidden_channels = true; opts.apply_processing_to_data = false;
        lvm::Spectrum exported; std::vector<int> channels; bool all = false;
        require(build_export_spectrum(opts, exported, channels, all), "selected FFT export rebuilds all channels");
        require(exported.freqs == expected.freqs && exported.amp == expected.amp, "selected FFT export uses every sample and excludes outside impulses");
    }
}

void stitched_gap_regressions() {
    std::vector<double> time(11001), values(11001);
    for (std::size_t i = 0; i < time.size(); ++i) {
        time[i] = i ? time[i - 1] + (i > 1000 ? 1025.0 : 1.0) / 1024 : 0;
        values[i] = std::sin(i);
    }
    reset_document({"A"}, time, {values});
    g.stitch_time_gaps = true;
    near(stitched_time_at_index(11000), 11000.0 / 1024, "graph compresses 10000 gaps even when they are the majority");
    bool invertible = true;
    for (std::size_t i = 0; i < time.size(); i += 113) {
        invertible = invertible && std::fabs(raw_time_from_stitched(i / 1024.0) - time[i]) < 1e-9;
    }
    require(invertible, "graph selection maps compact positions back across many gaps");
    reset_document({"A"}, {0, 1, 2, 1e100}, {{0, 1, 2, 3}});
    g.stitch_time_gaps = true;
    near(stitched_time_at_index(3), 3, "huge gap does not collapse the graph axis");
    near(raw_time_from_stitched(1.5), 1.5, "huge final gap cannot move a selection in the initial segment");
    reset_document({"A"}, {0, 1, 2, 4, 5, 6}, {{0, 1, 2, 3, 4, 5}});
    g.stitch_time_gaps = true;
    near(stitched_time_at_index(5), 5, "graph also compresses a single missing sample");
}

void spectrum_visibility_cache() {
    std::vector<double> time(8192);
    std::vector<std::vector<double>> values(3, std::vector<double>(time.size()));
    for (std::size_t i = 0; i < time.size(); ++i) {
        time[i] = i / 1024.0;
        for (std::size_t c = 0; c < values.size(); ++c) values[c][i] = std::sin(i * (0.1 + c * 0.2));
    }
    reset_document({"A", "B", "C"}, time, values);
    g.visible = {1, 1, 0}; g.mode = AnalysisMode::FFT;
    // A message-only window exercises the production asynchronous branch
    // without showing any UI. Earlier GUI tests used only its synchronous path.
    struct TestWindow {
        HWND handle = CreateWindowExW(0, L"STATIC", L"FFT regression", 0, 0, 0, 0, 0,
                                      HWND_MESSAGE, nullptr, GetModuleHandleW(nullptr), nullptr);
        ~TestWindow() { g_spectrum_worker.cancel(); g.main = nullptr; if (handle) DestroyWindow(handle); }
    } window;
    require(window.handle != nullptr, "message-only FFT test window");
    g.main = window.handle;
    const auto finish = [] {
        const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(10);
        std::optional<lvm::SpectrumWorker::Result> result;
        while (!result && std::chrono::steady_clock::now() < deadline) {
            result = g_spectrum_worker.take_result();
            if (!result) std::this_thread::sleep_for(std::chrono::milliseconds(5));
        }
        require(result && result->generation == g.spec_generation, "production worker returns the current generation");
        apply_spectrum_result(std::move(result->spectrum));
        require(g.spec_valid && !g.spec_pending, "production FFT leaves loading state only after applying its result");
    };
    compute_spectrum_for_window(time.front(), time.back(), true);
    require(g.spec_pending && !g.spec_valid, "initial LM FFT enters asynchronous loading state");
    const auto initial_generation = g.spec_generation;
    for (const auto& visible : std::vector<std::vector<char>>{{0,1,0}, {0,0,0}, {1,1,0}}) {
        g.visible = visible;
        require(!ensure_current_spectrum() && g.spec_pending, "visibility toggles keep pending FFT in loading state");
        require(g.spec_generation == initial_generation, "hiding or restoring requested channels does not restart pending FFT");
    }
    finish();
    require(g.spec.source_channels == std::vector<std::size_t>{0,1}, "LM calculates only requested channels");
    const double* cached_amplitudes = g.spec.amp[1].data();
    for (const auto& visible : std::vector<std::vector<char>>{{0,1,0}, {0,0,0}, {1,1,0}}) {
        g.visible = visible;
        require(ensure_current_spectrum() && !g.spec_pending, "hiding and restoring cached channels is immediate");
        require(g.spec_generation == initial_generation && g.spec.amp[1].data() == cached_amplitudes,
                "visibility preserves existing FFT buffers without recomputation");
    }
    g.visible = {0,1,1};
    require(!ensure_current_spectrum() && g.spec_pending && g.spec_generation > initial_generation,
            "showing an uncomputed channel schedules background FFT");
    finish();
    require(g.spec.source_channels == std::vector<std::size_t>{1,2}, "new LM request respects current visible channels");
    const auto prior_window = g.spec_generation;
    set_fft_window(time[100], time[2000]);
    compute_spectrum_for_window(time[100], time[2000], true);
    require(g.spec_pending && g.spec_generation > prior_window, "changing the source window invalidates cached spectra");
    finish();
    require(g.spec.n == 1901, "recomputed LM FFT uses the new source window");
    const auto prior_transform = g.spec_generation;
    g.global_formula = L"2*x"; rebuild_formula_cache_from_state();
    on_signal_transform_changed();
    require(g.spec_pending && g.spec_generation > prior_transform, "changing processing invalidates cached spectra");
    finish();
    const auto cached_generation=g.spec_generation;
    g.mode=AnalysisMode::Time;
    set_mode(AnalysisMode::FFT);
    require(g.spec_generation==cached_generation && !g.spec_pending,
            "returning to the FFT tab reuses an unchanged completed cache");
}

void user_axis_names_outside_plot() {
    reset_document({"A"}, {0,1}, {{1,2}});
    const Theme* previous_theme = g_theme;
    HDC dc = CreateCompatibleDC(nullptr);
    BITMAPINFO info{};
    info.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    info.bmiHeader.biWidth = 320;
    info.bmiHeader.biHeight = -240;
    info.bmiHeader.biPlanes = 1;
    info.bmiHeader.biBitCount = 32;
    info.bmiHeader.biCompression = BI_RGB;
    void* pixels = nullptr;
    HBITMAP bitmap = CreateDIBSection(dc, &info, DIB_RGB_COLORS, &pixels, nullptr, 0);
    require(bitmap && pixels, "axis name rendering surface");
    HGDIOBJ old_bitmap = SelectObject(dc, bitmap);
    auto* data = static_cast<unsigned long*>(pixels);
    constexpr unsigned long background = 0x00354251;
    for (const Theme* theme : {&kLightTheme, &kDarkTheme}) {
        g_theme = theme;
        for (AnalysisMode mode : {AnalysisMode::Time, AnalysisMode::FFT, AnalysisMode::FRF}) {
            for (bool long_names : {false, true}) {
                const std::wstring x = long_names ? L"Длинное название оси X & время сигнала" : L"X";
                const std::wstring y = long_names ? L"Длинное название оси Y & амплитуда" : L"Y";
                g.axis_x_label = g.fft_axis_x_label = g.frf_axis_x_label = x;
                g.time_axis_y_label = g.fft_axis_y_label = g.frf_axis_y_label = y;
                const RECT plot{40,40,long_names ? 100 : 280,150};
                std::fill(data, data + 320*240, background);
                draw_user_axis_names(dc, plot, mode);
                GdiFlush();
                int above = 0, below = 0, unexpected = 0;
                for (int py=0; py<240; ++py) for (int px=0; px<320; ++px) {
                    if ((data[py*320+px] & 0x00ffffff) == background) continue;
                    if (px < plot.left || px >= plot.right) ++unexpected;
                    else if (py < plot.top) ++above;
                    else if (py > plot.bottom + 20) ++below;
                    else ++unexpected;
                }
                require(above > 0 && below > 0, "both editable axis names render outside the graph in each theme and mode");
                require(unexpected == 0, "axis captions never repaint data or numeric ticks, even in a narrow plot");
            }
        }
    }
    SelectObject(dc, old_bitmap);
    DeleteObject(bitmap);
    DeleteDC(dc);
    g_theme = previous_theme;
}

void spectrum_pending_message() {
    reset_document({"A"},{0,1,2,3},{{1,2,3,4}});
    g.mode=AnalysisMode::FFT;g.spec_attempted=true;g.spec_visible_state=g.visible;
    const auto* previous_theme=g_theme;
    HDC dc=CreateCompatibleDC(nullptr);BITMAPINFO info{};
    info.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);info.bmiHeader.biWidth=640;info.bmiHeader.biHeight=-300;
    info.bmiHeader.biPlanes=1;info.bmiHeader.biBitCount=32;info.bmiHeader.biCompression=BI_RGB;
    void* pixels=nullptr;HBITMAP bitmap=CreateDIBSection(dc,&info,DIB_RGB_COLORS,&pixels,nullptr,0);
    require(bitmap && pixels,"spectrum waiting notice has a real GDI rendering surface");
    const auto old_bitmap=SelectObject(dc,bitmap);
    HFONT font=CreateFontW(-18,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,
        OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,ANTIALIASED_QUALITY,DEFAULT_PITCH,L"Segoe UI");
    const auto old_font=SelectObject(dc,font);g.ui_font=g.axis_font=font;
    const RECT plot{50,40,600,240};auto* data=static_cast<unsigned long*>(pixels);
    for(const auto* theme:{&kLightTheme,&kDarkTheme})for(const auto* language:{&kEn,&kRu})for(int state=0;state<3;++state) {
        g_theme=theme;g_str=language;g.spec_pending=state==0;g.spec.error=state==1 ? "FFT test error" : "";
        draw_axes(dc,plot,0,1,0,1);GdiFlush();
        const std::vector<unsigned long> axes(data,data+640*300);
        draw_freq(dc,plot);GdiFlush();
        int top=300,bottom=-1,count=0;
        for(int y=plot.top+24;y<plot.top+60;++y)for(int x=plot.left+24;x<plot.right-24;++x)
            if((data[y*640+x]&0xffffff)!=(axes[y*640+x]&0xffffff)){++count;top=std::min(top,y);bottom=std::max(bottom,y);}
        require(count>40 && bottom-top>=8,
            "spectrum pending/error/unavailable notice renders full glyphs despite axis baseline alignment in both languages/themes");
    }
    SelectObject(dc,old_font);g.ui_font=g.axis_font=nullptr;DeleteObject(font);
    SelectObject(dc,old_bitmap);DeleteObject(bitmap);DeleteDC(dc);g_theme=previous_theme;g_str=&kEn;
}

void channel_legend_visibility() {
    reset_document({"A", "B"}, {0,1,2,3}, {{1,2,3,4},{2,3,4,5}});
    require(g.show_channel_legend, "old and new documents show the legend by default");
    update_theme_brushes();
    HDC dc = CreateCompatibleDC(nullptr);
    HDC screen = GetDC(nullptr);
    HBITMAP bitmap = CreateCompatibleBitmap(screen, 640, 480);
    ReleaseDC(nullptr, screen);
    HGDIOBJ old_bitmap = SelectObject(dc, bitmap);
    const RECT plot{60,40,600,400};
    draw_legend(dc, plot);
    require(g_legend_items.size() == 2 && !IsRectEmpty(&g_legend_close_box), "legend has rows and a close control");
    require(g_legend_box.bottom - g_legend_box.top == 2 * 16 + 12 &&
            g_legend_close_box.top == g_legend_items.front().rect.top &&
            g_legend_items.front().rect.right < g_legend_close_box.left,
            "legend close control shares the first row without adding height or overlapping channel hits");
    const auto visibility = g.visible;
    mark_active_document_saved();
    handle_commands_message(nullptr, WM_COMMAND, IDM_CHANNEL_LEGEND, 0);
    require(!g.show_channel_legend && g_legend_items.empty() && IsRectEmpty(&g_legend_box) &&
            IsRectEmpty(&g_legend_close_box), "hiding clears all legend hit areas immediately");
    require(g.visible == visibility && active_document_has_unsaved_changes(), "legend hiding preserves channels and marks project changed");
    draw_legend(dc, plot);
    require(g_legend_items.empty(), "hidden legend stays absent during rendering and PNG drawing");
    pop_undo();
    require(g.show_channel_legend && !active_document_has_unsaved_changes(), "legend undo returns to saved state");
    pop_redo();
    require(!g.show_channel_legend, "legend hiding supports redo");
    DocumentState second;
    second.ds = g.ds;
    second.visible = g.visible;
    g.inactive_documents.push_back(std::move(second));
    require(switch_to_document(1) && g.show_channel_legend, "other document retains its own legend visibility");
    require(switch_to_document(1) && !g.show_channel_legend, "returning restores hidden legend");
    handle_commands_message(nullptr, WM_COMMAND, IDM_CHANNEL_LEGEND, 0);
    draw_legend(dc, plot);
    require(g.show_channel_legend && g_legend_items.size() == 2, "menu command restores the legend");
    HWND window = CreateWindowExW(0,L"STATIC",L"Legend test",WS_POPUP,0,0,640,480,
                                  nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    require(window != nullptr, "legend click test window");
    const auto old_proc = reinterpret_cast<WNDPROC>(SetWindowLongPtrW(window, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(WndProc)));
    handle_input_message(window, WM_LBUTTONDOWN, 0,
        MAKELPARAM(g_legend_close_box.left + 2, g_legend_close_box.top + 2));
    require(!g.show_channel_legend && g.visible == visibility, "close click hides legend without toggling a channel");
    g.main = window;
    g.ui_font = reinterpret_cast<HFONT>(GetStockObject(DEFAULT_GUI_FONT));
    layout();
    Gdiplus::GdiplusStartupInput startup;
    ULONG_PTR token = 0;
    require(Gdiplus::GdiplusStartup(&token, &startup, nullptr) == Gdiplus::Ok, "legend PNG startup");
    require(save_png((test_dir / "legend_hidden.png").wstring()) && g_legend_items.empty(),
            "PNG export respects hidden legend");
    handle_commands_message(window, WM_COMMAND, IDM_CHANNEL_LEGEND, 0);
    require(save_png((test_dir / "legend_visible.png").wstring()) && g_legend_items.size() == 2,
            "PNG export includes restored legend");
    const Theme* previous_theme = g_theme;
    g_theme = &kDarkTheme;
    g.axis_x_label = L"Длинная пользовательская подпись времени X";
    g.time_axis_y_label = L"Пользовательская подпись амплитуды Y";
    require(save_png((test_dir / "axis_names_dark.png").wstring()), "dark PNG with long editable axis names");
    g_theme = previous_theme;
    Gdiplus::GdiplusShutdown(token);
    g.main = nullptr;
    SetWindowLongPtrW(window, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(old_proc));
    DestroyWindow(window);
    SelectObject(dc, old_bitmap);
    DeleteObject(bitmap);
    DeleteDC(dc);
}

void shift_range_with_point_mode() {
    const auto window=CreateWindowExW(0,L"STATIC",L"Shift range selection",WS_POPUP,0,0,1000,650,
        nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    require(window!=nullptr,"Shift selection regression has a hidden window");
    struct Cleanup {HWND hwnd;~Cleanup(){if(GetCapture()==hwnd)ReleaseCapture();DestroyWindow(hwnd);g.main=nullptr;}} cleanup{window};
    for(bool points:{false,true}) for(bool locked:{false,true}) for(bool stitched:{false,true}) {
        reset_document({"A"},{0,1,2,102,103,104},{{0,1,2,1,0,1}});
        g.main=window;g.measure_mode=points;g.annotations_locked=locked;
        g.show_channel_legend=false;g.stitch_time_gaps=stitched;g.snap_to_data=false;
        const RECT plot=plot_rect();g.vrect=plot;g.vx0=0;g.vx1=stitched_time_from_raw(104);
        g.vy0=0;g.vy1=2;g.vvalid=true;
        const int start=plot.left+(plot.right-plot.left)/4;
        const int end=plot.left+3*(plot.right-plot.left)/4;
        const int y=(plot.top+plot.bottom)/2;
        const auto raw_at=[&](int x){return raw_time_from_stitched(
            double(x-plot.left)/(plot.right-plot.left)*stitched_time_from_raw(104));};
        const double start_time=raw_at(start),end_time=raw_at(end);
        PointGroup group;group.points={{start_time,1}};g.point_groups.push_back(group);
        g.show_gap_markers=true;
        g.visible_gap_markers.push_back({{start-5,plot.top,start+5,plot.bottom},100,100});
        seek_playhead(start_time);
        handle_input_message(window,WM_LBUTTONDOWN,MK_SHIFT|MK_LBUTTON,MAKELPARAM(start,y));
        require(g.fft_selecting && !g.point_click_pending && !g.dragging && !g.playhead_dragging &&
                g.annotation_drag_kind==App::AnnotationDragKind::None && !g.gap_click_pending,
            "Shift selects a range ahead of points, gap cards and the red timeline, including locked annotations");
        handle_input_message(window,WM_MOUSEMOVE,MK_SHIFT|MK_LBUTTON,MAKELPARAM(end,y));
        // Releasing Shift before the mouse must still finish the range gesture.
        handle_input_message(window,WM_LBUTTONUP,0,MAKELPARAM(end,y));
        require(!g.fft_selecting && has_fft_window(),"releasing the mouse commits the selected analysis interval");
        near(g.fft_window_start,start_time,"Shift range begins at the original acquisition coordinate");
        near(g.fft_window_end,end_time,"Shift range ends at the original acquisition coordinate");
        require(g.point_groups.front().points==group.points && g.playhead==start_time &&
                g.measure_mode==points && g.win_start==0 && g.win_end==104,
            "Shift selection preserves points, timeline, point mode and viewport");
        require(g_undo.size()==1,"a Shift range selection creates one undo entry");
        pop_undo();require(!has_fft_window(),"undo restores the previous whole-recording analysis range");
        pop_redo();require(has_fft_window() && g.fft_window_start==start_time && g.fft_window_end==end_time,
            "redo restores the exact selected interval");
        handle_input_message(window,WM_LBUTTONDOWN,MK_SHIFT,MAKELPARAM((start+end)/2,y));
        handle_input_message(window,WM_LBUTTONUP,0,MAKELPARAM((start+end)/2,y));
        require(!has_fft_window() && g.point_groups.front().points==group.points,
            "Shift clicking the selected interval clears it without placing a point");
        if(points && !locked) {
            reset_playback();
            handle_input_message(window,WM_LBUTTONDOWN,0,MAKELPARAM(end,y));
            handle_input_message(window,WM_LBUTTONUP,0,MAKELPARAM(end,y));
            std::size_t count=0;for(const auto& item:g.point_groups)count+=item.points.size();
            require(count==2 && !has_fft_window(),"a plain click still places a point with point mode enabled");
        }
        g.win_start=start_time;g.win_end=end_time;
        set_fft_window(start_time,end_time);
        const auto revision=g.numerical_revision;
        const double left=stitched_time_from_raw(start_time),right=stitched_time_from_raw(end_time);
        const double step=(right-left)*.1;
        POINT wheel{(start+end)/2,y};ClientToScreen(window,&wheel);
        const auto wheel_position=MAKELPARAM(wheel.x,wheel.y);
        WndProc(window,WM_MOUSEWHEEL,MAKEWPARAM(MK_SHIFT,WHEEL_DELTA),wheel_position);
        near(stitched_time_from_raw(g.win_start),left-step,"Shift wheel pans left using the message modifier, including point mode and stitched time");
        near(stitched_time_from_raw(g.win_end),right-step,"Shift wheel preserves the viewport width");
        WndProc(window,WM_MOUSEWHEEL,MAKEWPARAM(MK_SHIFT,-WHEEL_DELTA),wheel_position);
        near(g.win_start,start_time,"reverse Shift wheel returns to the original position");
        WndProc(window,WM_MOUSEHWHEEL,MAKEWPARAM(0,WHEEL_DELTA),wheel_position);
        near(stitched_time_from_raw(g.win_start),left+step,"native horizontal wheel is routed to rightward graph navigation");
        WndProc(window,WM_MOUSEHWHEEL,MAKEWPARAM(0,-WHEEL_DELTA),wheel_position);
        near(g.win_start,start_time,"native horizontal wheel supports the reverse direction");
        require(has_fft_window() && g.fft_window_start==start_time && g.fft_window_end==end_time &&
            g.numerical_revision==revision,"wheel navigation preserves the selected analysis interval and numerical revision");
    }
}

void analysis_range_edge_editing() {
    HWND window=CreateWindowExW(0,L"STATIC",L"Analysis range edges",WS_POPUP,0,0,1000,650,
        nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    require(window!=nullptr,"analysis range editing has a hidden window");
    struct Cleanup {HWND hwnd;~Cleanup(){if(GetCapture()==hwnd)ReleaseCapture();DestroyWindow(hwnd);g.main=nullptr;}} cleanup{window};
    for(bool stitched:{false,true}) for(bool points:{false,true}) for(bool locked:{false,true}) {
        reset_document({"A"},{0,1,2,102,103,104},{{0,1,2,1,0,1}});
        g.main=window;g.stitch_time_gaps=stitched;g.measure_mode=points;g.annotations_locked=locked;
        g.show_channel_legend=false;g.show_gap_markers=false;g.snap_to_data=false;
        const RECT plot=plot_rect();const int y=(plot.top+plot.bottom)/2;
        const auto x=[&](double fraction){return plot.left+static_cast<int>((plot.right-plot.left)*fraction);};
        const auto time=[&](int pixel){return raw_time_from_stitched(double(pixel-plot.left)/(plot.right-plot.left)*stitched_time_from_raw(104));};
        const double a=time(x(.25)),b=time(x(.75));set_fft_window(a,b);g_undo.clear();g_redo.clear();
        const auto revision=g.frf.generation;
        int left=analysis_range_edge_x(a,plot),right=analysis_range_edge_x(b,plot);
        require(hit_test_analysis_range_edge(left,y)==1 && hit_test_analysis_range_edge(right,y)==2,
            "both real interval edges can be grabbed on normal and stitched axes");
        WndProc(window,WM_LBUTTONDOWN,0,MAKELPARAM(left,y));
        WndProc(window,WM_MOUSEMOVE,MK_LBUTTON,MAKELPARAM(x(.125),y));
        require(g.fft_selecting && g.fft_resize_edge==1 && g.fft_window_start==a && g.fft_window_end==b &&
            g.frf.generation==revision && g_undo.empty(),"edge movement previews without recalculation or undo entries, including point/locked modes");
        WndProc(window,WM_LBUTTONUP,0,MAKELPARAM(x(.125),y));
        near(g.fft_window_start,time(x(.125)),"left-edge release commits the exact original time");
        require(g.fft_window_end==b && g_undo.size()==1 && !g.fft_selecting && !g.fft_resize_edge,
            "left-edge edit preserves the opposite edge and creates one undo entry");
        pop_undo();require(g.fft_window_start==a && g.fft_window_end==b,"Undo restores the entire previous interval");
        pop_redo();near(g.fft_window_start,time(x(.125)),"Redo restores the dragged edge");
        right=analysis_range_edge_x(b,plot);
        const double unchanged_left=g.fft_window_start;
        WndProc(window,WM_LBUTTONDOWN,0,MAKELPARAM(right,y));
        WndProc(window,WM_MOUSEMOVE,MK_LBUTTON,MAKELPARAM(x(.875),y));
        WndProc(window,WM_LBUTTONUP,0,MAKELPARAM(x(.875),y));
        near(g.fft_window_end,time(x(.875)),"right-edge release commits its original acquisition time");
        require(g.fft_window_start==unchanged_left,"right-edge edit leaves the left endpoint fixed");
        for(UINT cancel:{WM_KEYDOWN,WM_CAPTURECHANGED,WM_CANCELMODE,WM_RBUTTONDOWN}) {
            const double before_start=g.fft_window_start,before_end=g.fft_window_end;
            const auto undo_count=g_undo.size();
            left=analysis_range_edge_x(before_start,plot);
            WndProc(window,WM_LBUTTONDOWN,0,MAKELPARAM(left,y));
            WndProc(window,WM_MOUSEMOVE,MK_LBUTTON,MAKELPARAM(x(.375),y));
            WndProc(window,cancel,cancel==WM_KEYDOWN ? VK_ESCAPE : 0,0);
            require(!g.fft_selecting && !g.fft_resize_edge && g.fft_window_start==before_start &&
                g.fft_window_end==before_end && g_undo.size()==undo_count,"Escape, capture loss, cancellation and right click discard edge previews");
        }
        left=analysis_range_edge_x(g.fft_window_start,plot);
        const auto undo_count=g_undo.size();
        WndProc(window,WM_LBUTTONDOWN,0,MAKELPARAM(left,y));
        WndProc(window,WM_LBUTTONUP,0,MAKELPARAM(left,y));
        require(g_undo.size()==undo_count,"clicking an edge without movement leaves the selected interval intact");
        const double fixed_end=g.fft_window_end;
        WndProc(window,WM_LBUTTONDOWN,0,MAKELPARAM(left,y));
        WndProc(window,WM_MOUSEMOVE,MK_LBUTTON,MAKELPARAM(x(.95),y));
        WndProc(window,WM_LBUTTONUP,0,MAKELPARAM(x(.95),y));
        require(g.fft_window_start==fixed_end && g.fft_window_end>fixed_end,
            "dragging an edge past its opposite endpoint keeps the interval ordered and nonempty");
        pop_undo();
        g.win_start=time(x(.5));g.win_end=104;
        require(analysis_range_edge_x(g.fft_window_start,plot)<0 && !hit_test_analysis_range_edge(plot.left+4,y),
            "an off-screen boundary does not create a phantom drag handle at the plot edge");
    }
    reset_document({"A"},{0,1,2,3,4,5,6,7,8,9,10},{{0,1,0,1,0,1,0,1,0,1,0}});g.main=window;
    Gdiplus::GdiplusStartupInput startup;ULONG_PTR token=0;
    require(Gdiplus::GdiplusStartup(&token,&startup,nullptr)==Gdiplus::Ok,"GDI+ starts for range overlay pixel checks");
    HDC dc=CreateCompatibleDC(nullptr);BITMAPINFO info{};info.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
    info.bmiHeader.biWidth=400;info.bmiHeader.biHeight=-160;info.bmiHeader.biPlanes=1;info.bmiHeader.biBitCount=32;info.bmiHeader.biCompression=BI_RGB;
    void* pixels=nullptr;HBITMAP bitmap=CreateDIBSection(dc,&info,DIB_RGB_COLORS,&pixels,nullptr,0);
    const auto old=SelectObject(dc,bitmap);const auto previous_theme=g_theme;
    const RECT image{0,0,400,160},plot{10,10,390,150};
    for(const auto* theme:{&kLightTheme,&kDarkTheme}) {
        g_theme=theme;HBRUSH background=CreateSolidBrush(theme->bg_plot);FillRect(dc,&image,background);GdiFlush();
        const auto* begin=static_cast<const unsigned char*>(pixels);std::vector<unsigned char> baseline(begin,begin+400*160*4);
        const auto unchanged=[&](int left,int top,int right,int bottom) {
            for(int y=top;y<bottom;++y) {
                const int offset=(y*400+left)*4;
                if(!std::equal(baseline.begin()+offset,baseline.begin()+offset+(right-left)*4,begin+offset))return false;
            }
            return true;
        };
        g.win_start=3;g.win_end=7;set_fft_window(1,2);draw_analysis_range_selection(dc,plot);GdiFlush();
        require(!unchanged(12,12,388,148) && unchanged(0,0,400,10),
            "zooming outside the working interval shows sparse hatching only inside the plot in both themes");
        const std::vector<unsigned char> excluded_view(begin,begin+400*160*4);
        FillRect(dc,&image,background);set_fft_window(8,9);draw_analysis_range_selection(dc,plot);GdiFlush();
        require(std::equal(excluded_view.begin(),excluded_view.end(),begin),
            "a working interval outside either viewport edge produces the same hatching without cumulative shading");
        FillRect(dc,&image,background);
        g.win_start=0;g.win_end=10;set_fft_window(3,7);draw_analysis_range_selection(dc,plot);GdiFlush();
        require(unchanged(132,12,268,148) && !unchanged(12,30,115,130) && !unchanged(285,30,388,130),
            "the working interval remains pixel-identical while sparse hatching marks both excluded sides");
        FillRect(dc,&image,background);g.win_start=3;g.win_end=7;set_fft_window(0,10);
        draw_analysis_range_selection(dc,plot);GdiFlush();
        require(std::equal(baseline.begin(),baseline.end(),begin),
            "zooming inside the selected interval leaves every pixel unchanged in both themes");
        set_fft_window(3,7);g.win_start=0;g.win_end=10;
        update_analysis_range_hover(window,-1,-1);FillRect(dc,&image,background);draw_analysis_range_selection(dc,plot);GdiFlush();
        const std::vector<unsigned char> normal_edges(begin,begin+400*160*4);
        const RECT actual_plot=plot_rect();
        WndProc(window,WM_MOUSEMOVE,0,MAKELPARAM(analysis_range_edge_x(3,actual_plot),(actual_plot.top+actual_plot.bottom)/2));
        FillRect(dc,&image,background);draw_analysis_range_selection(dc,plot);GdiFlush();
        require(!std::equal(normal_edges.begin(),normal_edges.end(),begin) && unchanged(132,30,268,130),
            "hover increases boundary contrast without changing the working interior");
        WndProc(window,WM_MOUSELEAVE,0,0);FillRect(dc,&image,background);draw_analysis_range_selection(dc,plot);GdiFlush();
        require(std::equal(normal_edges.begin(),normal_edges.end(),begin),"mouse leave clears range-boundary hover styling");
        for(const auto* language:{&kRu,&kEn}) {
            g_str=language;const auto caption=analysis_range_caption_text();
            require(caption.find(L"3–7")!=std::wstring::npos && caption.find(L"Δt 4")!=std::wstring::npos,
                "analysis caption shows both original endpoints and duration");
            g.win_start=8;g.win_end=10;
            require(analysis_range_caption_text()==caption,"offscreen selection keeps its interval caption");
            g.stitch_time_gaps=true;
            require(analysis_range_caption_text().find(language==&kEn ? L"source" : L"исх.")!=std::wstring::npos,
                "stitched analysis caption identifies original acquisition times");
            g.stitch_time_gaps=false;g.win_start=0;g.win_end=10;
            g.fft_selecting=true;g.fft_select_anchor_t=8;g.fft_select_current_t=2;
            require(analysis_range_caption_text().find(L"2–8")!=std::wstring::npos &&
                analysis_range_caption_text().find(L"Δt 6")!=std::wstring::npos,"caption follows ordered selection previews");
            g.fft_selecting=false;
        }
        g_str=&kEn;g.mode=AnalysisMode::FFT;require(analysis_range_caption_text().empty(),"time interval caption is hidden outside Signal");g.mode=AnalysisMode::Time;
        DeleteObject(background);
    }
    g_theme=previous_theme;SelectObject(dc,old);DeleteObject(bitmap);DeleteDC(dc);Gdiplus::GdiplusShutdown(token);
}

void analysis_range_edge_magnet() {
    HWND window=CreateWindowExW(0,L"STATIC",L"Range magnet",WS_POPUP,0,0,1000,650,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    require(window!=nullptr,"range magnet has a hidden input window");
    struct Cleanup {HWND window;~Cleanup(){cancel_overview_snap();if(GetCapture()==window)ReleaseCapture();DestroyWindow(window);g.main=nullptr;}} cleanup{window};
    const double nan=std::numeric_limits<double>::quiet_NaN();
    for(bool stitched:{false,true})for(bool locked:{false,true}) {
        reset_document({"Low","High"},stitched ? std::vector<double>{0,1,2,102,103,104} : std::vector<double>{0,1,2,3,4,5},
            {{nan,nan,1,nan,nan,nan},{nan,nan,nan,9,nan,nan}});
        g.main=window;g.stitch_time_gaps=stitched;g.annotations_locked=locked;g.measure_mode=true;
        g.snap_to_data=true;g.show_channel_legend=false;
        const RECT plot=plot_rect();g.vrect=plot;g.vx0=0;g.vx1=5;g.vy0=0;g.vy1=10;g.vvalid=true;
        const auto px=[&](double time){return plot.left+static_cast<int>(time/5*(plot.right-plot.left));};
        const auto py=[&](double value){return plot.bottom-static_cast<int>(value/10*(plot.bottom-plot.top));};
        const double a=.5,b=raw_time_from_stitched(4.5),high_time=stitched ? 102 : 3;
        set_fft_window(a,b);g_undo.clear();g_redo.clear();
        for(int edge:{1,2}) {
            const double expected=edge==1 ? high_time : 2;
            const int x=analysis_range_edge_x(edge==1 ? a : b,plot),y=py(edge==1 ? 9 : 1);
            WndProc(window,WM_LBUTTONDOWN,0,MAKELPARAM(x,y));
            WndProc(window,WM_MOUSEMOVE,MK_LBUTTON,MAKELPARAM(px(2.4),y));
            require(g.fft_select_current_t==expected && g.fft_window_start==a && g.fft_window_end==b && g_undo.empty(),
                "each magnetic boundary previews the actual sample on the curve nearest cursor Y without committing");
            WndProc(window,WM_LBUTTONUP,0,MAKELPARAM(px(2.4),y));
            require(g.fft_window_start==(edge==1 ? expected : a) && g.fft_window_end==(edge==2 ? expected : b) && g_undo.size()==1,
                "magnetic boundary release stores original time and exactly one Undo, including stitched/point/locked modes");
            pop_undo();require(g.fft_window_start==a && g.fft_window_end==b,"Undo restores both pre-snap boundaries");
            pop_redo();require((edge==1 ? g.fft_window_start : g.fft_window_end)==expected,"Redo restores the exact magnetic boundary");
            pop_undo();g_undo.clear();g_redo.clear();
        }
        g.visible[1]=0;
        int left=analysis_range_edge_x(a,plot);
        WndProc(window,WM_LBUTTONDOWN,0,MAKELPARAM(left,py(9)));
        WndProc(window,WM_MOUSEMOVE,MK_LBUTTON,MAKELPARAM(px(2.4),py(9)));
        require(g.fft_select_current_t==2,"hidden channels do not attract a moving analysis boundary");
        WndProc(window,WM_KEYDOWN,VK_ESCAPE,0);
        require(g.fft_window_start==a && g.fft_window_end==b && g_undo.empty(),"Escape cancels a magnetic preview without editing the interval");
        g.visible[1]=1;g.snap_to_data=false;
        WndProc(window,WM_LBUTTONDOWN,0,MAKELPARAM(left,py(9)));
        WndProc(window,WM_MOUSEMOVE,MK_LBUTTON,MAKELPARAM(px(2.4),py(9)));
        const double free_time=g.fft_select_current_t;
        require(free_time!=2 && free_time!=high_time,"turning the magnet off leaves continuous boundary positioning");
        WndProc(window,WM_LBUTTONUP,0,MAKELPARAM(px(2.4),py(9)));
        require(g.fft_window_start==free_time && g_undo.size()==1,"free boundary placement preserves its exact cursor coordinate");
        pop_undo();g_undo.clear();g_redo.clear();g.snap_to_data=true;
        WndProc(window,WM_LBUTTONDOWN,0,MAKELPARAM(left,py(9)));
        WndProc(window,WM_LBUTTONUP,0,MAKELPARAM(left,py(9)));
        require(g.fft_window_start==a && g.fft_window_end==b && g_undo.empty(),"clicking a boundary without moving does not magnetize it unexpectedly");
    }
}

void curve_symbols_keep_solid_paths() {
    reset_document({"A","B","C","D","E","F"},{0,1},
        {{1,1},{2,2},{3,3},{4,4},{5,5},{6,6}});
    g.distinguish_curves=true;g.auto_y=false;g.y_lock_min=0;g.y_lock_max=7;
    g.show_channel_legend=false;
    HDC dc=CreateCompatibleDC(nullptr);
    HBITMAP bitmap=CreateBitmap(480,360,1,32,nullptr);
    const auto old=SelectObject(dc,bitmap);
    const RECT plot{60,30,400,310};
    draw_time(dc,plot);
    for(int channel=0;channel<6;++channel) {
        const int y=plot.bottom-(channel+1)*40;
        bool continuous=true;
        for(int x=80;x<380;++x)
            continuous=continuous && GetPixel(dc,x,y)==channel_color(channel);
        require(continuous,"every curve-symbol channel keeps a continuous line between its symbols");
    }
    SelectObject(dc,old);DeleteObject(bitmap);DeleteDC(dc);
}

void submenu_arrow_theme() {
    HDC dc=CreateCompatibleDC(nullptr);
    HBITMAP bitmap=CreateBitmap(300,32,1,32,nullptr);
    const auto old=SelectObject(dc,bitmap);
    const auto previous_theme=g_theme;
    for(const auto* theme:{&kLightTheme,&kDarkTheme})
        for(const auto* label:{L"Недавние файлы",L"Открытые файлы"})
            for(UINT state:{0u,static_cast<UINT>(ODS_SELECTED),static_cast<UINT>(ODS_DISABLED)}) {
                g_theme=theme;
                OwnerDrawMenuEntry entry{label,L"",false,true};
                DRAWITEMSTRUCT item{};item.CtlType=ODT_MENU;item.hDC=dc;
                item.rcItem={0,0,300,32};item.itemState=state;
                item.itemData=reinterpret_cast<ULONG_PTR>(&entry);
                const int saved=SaveDC(dc);
                draw_owner_draw_menu(&item);
                const int drawn=SaveDC(dc);
                SelectClipRgn(dc,nullptr);
                const COLORREF foreground=state&ODS_DISABLED ? theme->text_secondary : theme->text_primary;
                const COLORREF background=state&ODS_SELECTED ? theme->btn_hover : theme->bg_toolbar;
                require(GetPixel(dc,289,16)==foreground && GetPixel(dc,282,16)==background,
                    "submenu arrows use theme text and hover colours in both themes");
                std::vector<COLORREF> before;
                for(int y=0;y<32;++y)for(int x=278;x<300;++x)before.push_back(GetPixel(dc,x,y));
                RestoreDC(dc,drawn);
                RECT native_arrow{278,0,300,32};
                DrawFrameControl(dc,&native_arrow,DFC_MENU,DFCS_MENUARROW);
                SelectClipRgn(dc,nullptr);
                bool unchanged=true;std::size_t index=0;
                for(int y=0;y<32;++y)for(int x=278;x<300;++x)
                    unchanged=unchanged && GetPixel(dc,x,y)==before[index++];
                require(unchanged,"native submenu glyph cannot overwrite the themed arrow after owner drawing");
                RestoreDC(dc,saved);
            }
    g_theme=previous_theme;SelectObject(dc,old);DeleteObject(bitmap);DeleteDC(dc);
}

void line_menu_theme() {
    reset_document({"A"},{0,1,2},{{-1,0,1}});
    struct Observation { bool opened=false; bool themed=false; int items=0; } observation;
    HWND owner=CreateWindowExW(0,L"STATIC",L"Line menu owner",WS_POPUP,
        100,100,300,200,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    require(owner!=nullptr,"line popup has an owner");
    SetWindowSubclass(owner,[](HWND hwnd,UINT message,WPARAM wp,LPARAM lp,UINT_PTR,DWORD_PTR data)->LRESULT {
        if(message==WM_INITMENUPOPUP) {
            auto& seen=*reinterpret_cast<Observation*>(data);
            const auto menu=reinterpret_cast<HMENU>(wp);
            MENUINFO info{};info.cbSize=sizeof(info);info.fMask=MIM_BACKGROUND;
            LOGBRUSH brush{};
            seen.opened=true;seen.items=GetMenuItemCount(menu);
            seen.themed=GetMenuInfo(menu,&info) && info.hbrBack &&
                GetObjectW(info.hbrBack,sizeof(brush),&brush)==sizeof(brush) &&
                brush.lbColor==g_theme->bg_toolbar;
        }
        return DefSubclassProc(hwnd,message,wp,lp);
    },1,reinterpret_cast<DWORD_PTR>(&observation));
    const auto previous_theme=g_theme;
    g.line_menu_btn=owner;
    for(const auto* theme:{&kLightTheme,&kDarkTheme}) {
        g_theme=theme;observation={};
        const auto timer=SetTimer(owner,0,10,[](HWND,UINT,UINT_PTR,DWORD){EndMenu();});
        handle_commands_message(owner,WM_COMMAND,IDC_LINE_MENU,0);
        KillTimer(owner,timer);
        require(observation.opened && observation.items==3 && observation.themed,
            "the actual three-item line popup uses the active theme for its native margins");
    }
    DestroyWindow(owner);g.line_menu_btn=nullptr;g_theme=previous_theme;
}

void exact_line_dialog() {
    reset_document({"A"},{0,1,2},{{-1,0,1}});
    const auto instance=GetModuleHandleW(nullptr);
    HWND owner=CreateWindowExW(0,L"STATIC",L"Guide dialog owner",WS_POPUP,100,100,800,600,nullptr,nullptr,instance,nullptr);
    require(owner!=nullptr,"exact line dialog has a modal owner");g.main=owner;
    const auto previous_theme=g_theme;
    HFONT font=CreateFontW(-14,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,
        CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH,L"Segoe UI");g.ui_font=font;
    struct Cleanup {HWND owner;HFONT font;const Theme* theme;~Cleanup(){
        if(g_guide_prompt.wnd)DestroyWindow(g_guide_prompt.wnd);
        DestroyWindow(owner);DeleteObject(font);
        g.main=nullptr;g.ui_font=nullptr;g_theme=theme;g_str=&kEn;update_theme_brushes();}
    } cleanup{owner,font,previous_theme};
    WNDCLASSEXW cls{};cls.cbSize=sizeof(cls);cls.hInstance=instance;cls.lpfnWndProc=GuidePromptProc;
    cls.lpszClassName=L"GuideDialogRegression";
    require(RegisterClassExW(&cls)!=0,"exact line dialog production procedure registers for testing");
    const auto text=[](HWND control){wchar_t value[256]{};GetWindowTextW(control,value,256);return std::wstring(value);};
    for(const auto* theme:{&kLightTheme,&kDarkTheme})for(const auto* language:{&kRu,&kEn}) {
        g_theme=theme;g_str=language;update_theme_brushes();
        HMENU menu=make_menu();
        require(GetMenuState(menu,IDM_ADD_LINE_EXACT,MF_BYCOMMAND)!=static_cast<UINT>(-1) &&
            GetMenuState(menu,IDM_ADD_HLINE_EXACT_LEGACY,MF_BYCOMMAND)==static_cast<UINT>(-1),
            "the Tools menu contains one exact line command instead of two direction-specific commands");DestroyMenu(menu);
        for(const auto mode:{AnalysisMode::Time,AnalysisMode::FFT,AnalysisMode::FRF}) {
            g.mode=mode;g_guide_prompt=GuidePromptState{};
            g_guide_prompt.vertical_value=.125;g_guide_prompt.horizontal_value=-2.75;
            RECT bounds{0,0,460,236};const DWORD style=WS_CAPTION|WS_SYSMENU|WS_POPUP;
            AdjustWindowRectEx(&bounds,style,FALSE,WS_EX_DLGMODALFRAME|WS_EX_TOOLWINDOW);
            HWND dialog=CreateWindowExW(WS_EX_DLGMODALFRAME|WS_EX_TOOLWINDOW,cls.lpszClassName,guide_prompt_title_text(),style,
                0,0,bounds.right-bounds.left,bounds.bottom-bounds.top,owner,nullptr,instance,nullptr);
            g_guide_prompt.wnd=dialog;
            require(dialog && text(dialog)==guide_prompt_title_text() && SendMessageW(g_guide_prompt.direction,CB_GETCOUNT,0,0)==2,
                "the themed exact line dialog offers both directions in RU/EN and Time/FFT/FRF");
            require(!(GetWindowLongPtrW(g_guide_prompt.edit,GWL_EXSTYLE)&WS_EX_CLIENTEDGE) &&
                (GetWindowLongPtrW(g_guide_prompt.direction,GWL_STYLE)&CBS_OWNERDRAWFIXED),
                "exact line controls use the compact themed edit and owner-drawn direction selector");
            require(text(g_guide_prompt.label)==guide_prompt_label_text(true) && text(g_guide_prompt.edit)==L"0.125",
                "vertical line initially uses the X/frequency label and its own value");
            const auto choose=[&](int direction) {
                SendMessageW(g_guide_prompt.direction,CB_SETCURSEL,direction,0);
                SendMessageW(dialog,WM_COMMAND,MAKEWPARAM(IDC_GUIDE_DIRECTION,CBN_SELCHANGE),reinterpret_cast<LPARAM>(g_guide_prompt.direction));
            };
            SetWindowTextW(g_guide_prompt.edit,L"1.2345678901234567");choose(1);
            require(!g_guide_prompt.vertical && text(g_guide_prompt.label)==guide_prompt_label_text(false) && text(g_guide_prompt.edit)==L"-2.75",
                "horizontal selection uses the Y/amplitude/FRF magnitude label and a separate initial value");
            SetWindowTextW(g_guide_prompt.edit,L"-3.5");choose(0);
            require(text(g_guide_prompt.edit)==L"1.2345678901234567","switching direction retains every digit of the entered coordinate");choose(1);
            require(text(g_guide_prompt.edit)==L"-3.5","returning to the horizontal direction retains its own coordinate");
            for(const auto* invalid:{L"nan",L"inf",L"abc",L""}) {
                SetWindowTextW(g_guide_prompt.edit,invalid);SendMessageW(dialog,WM_COMMAND,IDOK,0);
                require(IsWindow(dialog) && !g_guide_prompt.accepted && !text(g_guide_prompt.error).empty(),
                    "invalid and non-finite line coordinates remain in the themed dialog with an inline error");
            }
            SetWindowTextW(g_guide_prompt.edit,L"-3.5");SendMessageW(dialog,WM_COMMAND,IDOK,0);
            require(g_guide_prompt.accepted && !g_guide_prompt.vertical && g_guide_prompt.value==-3.5 && !IsWindow(dialog),
                "Add accepts the selected direction and exact finite value");
        }
    }
    g.mode=AnalysisMode::Time;g_str=&kEn;g.guides.clear();g_undo.clear();g_redo.clear();
    const UINT_PTR timer=SetTimer(owner,0,1,[](HWND window,UINT,UINT_PTR timer_id,DWORD){
        if(!g_guide_prompt.wnd)return;
        KillTimer(window,timer_id);
        SendMessageW(g_guide_prompt.direction,CB_SETCURSEL,1,0);
        SendMessageW(g_guide_prompt.wnd,WM_COMMAND,MAKEWPARAM(IDC_GUIDE_DIRECTION,CBN_SELCHANGE),0);
        SetWindowTextW(g_guide_prompt.edit,L"-0.125");SendMessageW(g_guide_prompt.wnd,WM_COMMAND,IDOK,0);
    });
    require(timer!=0,"modal guide command has an automated user response");
    handle_commands_message(owner,WM_COMMAND,IDM_ADD_LINE_EXACT,0);KillTimer(owner,timer);
    require(g.guides.size()==1 && !g.guides[0].vertical && g.guides[0].value==-.125 && g.guides[0].mode==AnalysisMode::Time,
        "the unified menu command adds the direction and value chosen in the modal dialog");
    pop_undo();require(g.guides.empty(),"Undo removes the exactly positioned line");
    pop_redo();require(g.guides.size()==1 && !g.guides[0].vertical && g.guides[0].value==-.125,"Redo restores the chosen line");
    const UINT_PTR cancel_timer=SetTimer(owner,0,1,[](HWND window,UINT,UINT_PTR timer_id,DWORD){
        if(!g_guide_prompt.wnd)return;
        KillTimer(window,timer_id);SendMessageW(g_guide_prompt.wnd,WM_COMMAND,IDCANCEL,0);
    });
    require(cancel_timer!=0,"modal guide cancellation has an automated response");
    bool vertical=true;double value=42;
    require(!prompt_exact_guide_value(vertical,value) && vertical && value==42 && g.guides.size()==1 && IsWindowEnabled(owner),
        "Cancel preserves output arguments and annotations and reenables the modal owner");KillTimer(owner,cancel_timer);
}

void offscreen_marker_lines() {
    reset_document({"A"},{1,2,100},{{0,1,0}});
    HDC screen=GetDC(nullptr),dc=CreateCompatibleDC(screen);
    HBITMAP bitmap=CreateCompatibleBitmap(screen,400,240);
    const auto old=SelectObject(dc,bitmap);ReleaseDC(nullptr,screen);
    const auto previous_theme=g_theme;
    struct Cleanup {HDC dc;HBITMAP bitmap;HGDIOBJ old;const Theme* theme;
        ~Cleanup(){g_theme=theme;SelectObject(dc,old);DeleteObject(bitmap);DeleteDC(dc);}
    } cleanup{dc,bitmap,old,previous_theme};
    g.vrect={20,20,380,220};g.vy0=0;g.vy1=10;g.vvalid=true;
    const RECT image{0,0,400,240};
    for(const auto* theme:{&kLightTheme,&kDarkTheme}) {
        g_theme=theme;
        const auto paint=[&](double x,double y) {
            g.markers={{x,y,L"M",false,g.mode,false,-1}};
            HBRUSH background=CreateSolidBrush(theme->bg_plot);
            FillRect(dc,&image,background);DeleteObject(background);draw_markers(dc);GdiFlush();
        };
        for(int mapping=0;mapping<4;++mapping) {
            g.mode=mapping==0 ? AnalysisMode::Time : mapping==1 ? AnalysisMode::FFT : AnalysisMode::FRF;
            g.frf.frequency_start=1;g.frf.frequency_end=100;g.frf.log_start=0;g.frf.log_end=2;
            g.frf.logarithmic_frequency_axis=mapping==3;
            g.vx0=mapping==3 ? 0 : 1;g.vx1=mapping==3 ? 2 : 100;
            for(double x:{.1,1000.0,1e300}) {
                paint(x,5);
                require(GetPixel(dc,80,120)==theme->frame && GetPixel(dc,320,120)==theme->frame,
                    "a marker outside either X edge retains its horizontal projection in Time/FFT/linear/log FRF");
                require(GetPixel(dc,80,80)==theme->bg_plot,
                    "an off-screen marker does not create a false vertical projection");
            }
            const double inside_x=mapping==3 ? 10 : 50.5;
            for(double y:{-1000.0,1000.0,1e300}) {
                paint(inside_x,y);
                require(GetPixel(dc,200,100)==theme->frame && GetPixel(dc,200,180)==theme->frame,
                    "a marker outside either Y edge retains its vertical projection");
                require(GetPixel(dc,80,120)==theme->bg_plot,
                    "an off-screen Y does not create a false horizontal projection");
            }
            paint(1000,1000);
            require(GetPixel(dc,80,120)==theme->bg_plot && GetPixel(dc,200,180)==theme->bg_plot,
                "a marker outside both axes leaves no projections inside the viewport");
        }
        g.mode=AnalysisMode::Time;g.ds.time={0,1,2,102,103,104};g.ds.channels={{0,1,2,3,4,5}};
        g.stitch_time_gaps=true;invalidate_stitched_time_cache();g.vx0=2;g.vx1=4;
        paint(104,5);
        require(GetPixel(dc,80,120)==theme->frame && GetPixel(dc,320,120)==theme->frame,
            "a marker outside the stitched time viewport retains its horizontal projection");
        g.stitch_time_gaps=false;invalidate_stitched_time_cache();
    }
}

void marker_value_readouts() {
    reset_document({"Signal A"},{0,1,2,3,4},{{0,2,4,6,8}});
    HWND window=CreateWindowExW(0,L"STATIC",L"Marker readouts",WS_POPUP,0,0,1000,650,
        nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    require(window!=nullptr,"marker values have a hidden interaction window");g.main=window;
    HDC screen=GetDC(window),dc=CreateCompatibleDC(screen);HBITMAP bitmap=CreateCompatibleBitmap(screen,1000,650);
    const auto old=SelectObject(dc,bitmap);ReleaseDC(window,screen);
    struct Cleanup {HWND hwnd;HDC dc;HBITMAP bitmap;HGDIOBJ old;~Cleanup(){SelectObject(dc,old);DeleteObject(bitmap);DeleteDC(dc);if(GetCapture()==hwnd)ReleaseCapture();DestroyWindow(hwnd);g.main=nullptr;}} cleanup{window,dc,bitmap,old};
    const RECT plot=plot_rect();g.vrect=plot;g.vx0=0;g.vx1=4;g.vy0=0;g.vy1=8;g.vvalid=true;
    g.show_channel_legend=false;g.snap_to_data=false;g.measure_mode=false;g.pending_marker=true;
    const int x=(plot.left+plot.right)/2,y=(plot.top+plot.bottom)/2;
    WndProc(window,WM_LBUTTONDOWN,0,MAKELPARAM(x,y));WndProc(window,WM_LBUTTONUP,0,MAKELPARAM(x,y));
    MarkerValuePanel panel;
    require(g.markers.size()==1 && marker_value_panel(dc,panel) && panel.marker==0,
        "a newly placed free marker immediately exposes stored coordinates without requiring a snapped channel");
    require(panel.x.find(L"t = 2")!=std::wstring::npos && panel.y.find(L"Y = 4")!=std::wstring::npos,
        "the new marker readout uses both stored coordinate values");
    draw_marker_values(dc);const auto count=g.markers.size();
    WndProc(window,WM_LBUTTONDOWN,0,MAKELPARAM(panel.bounds.left+12,panel.bounds.top+12));
    WndProc(window,WM_LBUTTONUP,0,MAKELPARAM(panel.bounds.left+12,panel.bounds.top+12));
    require(g.markers.size()==count && !g.point_click_pending,"clicking the readout cannot place another marker under the panel");
    const auto revision=g.numerical_revision;
    const int close_x=(panel.close.left+panel.close.right)/2,close_y=(panel.close.top+panel.close.bottom)/2;
    WndProc(window,WM_LBUTTONDOWN,0,MAKELPARAM(close_x,close_y));
    require(!g.show_marker_values && g.markers.size()==count && g.numerical_revision==revision,
        "the readout close button hides values without deleting annotations or changing numerical inputs");
    require(!marker_value_panel(dc,panel),"hidden readouts do not produce panels");
    pop_undo();require(g.show_marker_values,"Undo restores hidden marker values");
    pop_redo();require(!g.show_marker_values,"Redo restores readout hiding");
    save_runtime_settings_now();g.show_marker_values=true;load_runtime_settings();
    require(!g.show_marker_values,"the marker values preference persists in runtime settings");
    WndProc(window,WM_COMMAND,IDM_MARKER_VALUES,0);
    require(g.show_marker_values,"the View command restores marker values");
    g.pending_marker=false;g.markers.clear();
    for(int i=0;i<1000;++i)g.markers.push_back({1+i*.002,2,L"M"+std::to_wstring(i+1),false,AnalysisMode::Time,true,0});
    g.active_marker=999;g.vvalid=true;
    const auto previous_theme=g_theme;
    for(const auto* theme:{&kLightTheme,&kDarkTheme}) for(const auto* language:{&kRu,&kEn}) {
        g_theme=theme;g_str=language;
        require(marker_value_panel(dc,panel) && panel.marker==999 && panel.title.find(L"Signal A")!=std::wstring::npos,
            "many markers still produce only one channel-labelled readout in both themes/languages");
        require(panel.bounds.left>plot.left && panel.bounds.right<plot.right && panel.bounds.top>plot.top && panel.bounds.bottom<plot.bottom,
            "marker value panels remain inside the plot and leave scale gutters clear");
    }
    g_theme=previous_theme;g_str=&kEn;
    g.markers={{2,2,L"Lower",false,AnalysisMode::Time,false,-1},{2,6,L"Upper",false,AnalysisMode::Time,false,-1}};
    const int marker_x=plot.left+(plot.right-plot.left)/2;
    update_marker_values_hover(window,marker_x,plot.bottom-(plot.bottom-plot.top)*3/4);
    require(g.active_marker==1,"free markers sharing a frequency/time coordinate can be inspected by their own intersection");
    update_marker_values_hover(window,marker_x,plot.bottom-(plot.bottom-plot.top)/4);
    require(g.active_marker==0,"hovering the other marker with the same X selects its own stored values");
    g.markers.clear();for(int i=0;i<1000;++i)g.markers.push_back({1+i*.002,2,L"M"+std::to_wstring(i+1),false,AnalysisMode::Time,true,0});
    g.active_marker=999;update_marker_values_hover(window,plot.left+(plot.right-plot.left)/4,plot.top+20);
    require(g.active_marker!=999,"hovering a different marker switches the single readout");
    g.markers={{3.999,7.99,L"Edge",false,AnalysisMode::Time,false,-1}};g.active_marker=0;
    require(marker_value_panel(dc,panel) && panel.bounds.right<plot.right && panel.bounds.top>plot.top,
        "a marker near the upper-right corner moves its readout left or below rather than clipping it");
    g.markers[0].x=5;require(!marker_value_panel(dc,panel),"off-screen markers do not leave floating value panels");
    g.markers[0].x=-6.9388939039072284e-18;g.markers[0].y=-1.25;g.vx0=-1;g.vx1=1;g.vy0=-2;g.vy1=2;
    require(marker_value_panel(dc,panel) && panel.x.find(L"-6.938")!=std::wstring::npos && panel.y.find(L"-1.25")!=std::wstring::npos,
        "small and negative original coordinates are not rounded to zero");
    g.markers[0].x=0;g.markers[0].y=1;g.vx0=-1;g.vx1=1;g.stitch_time_gaps=true;
    require(marker_value_panel(dc,panel) && panel.x.find(L"source")!=std::wstring::npos,
        "stitched time readouts explicitly retain the original acquisition coordinate");
    g.stitch_time_gaps=false;g.mode=AnalysisMode::FFT;g.markers[0].mode=g.mode;g.markers[0].x=.5;g.vx0=0;g.vx1=1;
    require(marker_value_panel(dc,panel) && panel.x.find(L"Hz")!=std::wstring::npos && panel.y.find(L"A = 1")!=std::wstring::npos,
        "FFT marker values identify frequency and physical amplitude");
    g.mode=AnalysisMode::FRF;g.markers[0].mode=g.mode;g.markers[0].x=10;g.markers[0].y=1.25;
    g.frf.frequency_start=1;g.frf.frequency_end=100;g.frf.log_start=0;g.frf.log_end=2;
    for(bool logarithmic:{false,true}) {
        g.frf.logarithmic_frequency_axis=logarithmic;g.vx0=logarithmic ? 0 : 1;g.vx1=logarithmic ? 2 : 100;
        require(marker_value_panel(dc,panel) && panel.x.find(L"f = 10 Hz")!=std::wstring::npos && panel.y==L"|H| = 1.25",
            "linear and log FRF show the stored dimensionless magnitude without amplitude units");
    }
    WndProc(window,WM_COMMAND,IDM_MARKER_VALUES,0);
    require(!g.show_marker_values && frf_command_supported(IDM_MARKER_VALUES),"readout visibility remains available in FRF");
}

void playback_timeline_controls() {
    reset_document({"A"},{0,1,2,3,4},{{0,1,2,1,0}});
    const auto window=CreateWindowExW(0,L"STATIC",L"Playback timeline",WS_POPUP,0,0,1000,650,
        nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    require(window!=nullptr,"playback regression has a real hidden timer owner");g.main=window;
    struct Cleanup {HWND hwnd;~Cleanup(){stop_play();if(GetCapture()==hwnd)ReleaseCapture();DestroyWindow(hwnd);g.main=nullptr;}} cleanup{window};
    set_fft_window(1,3);const auto numerical=g.numerical_revision;
    g.win_start=3;g.win_end=4;seek_playhead(4);start_play();
    require(g.playing && g.playhead_active && g.playhead==0 && g.win_start==0 && g.win_end==1,
        "playback after EOF restarts at the recording beginning and restores a visible window");
    LARGE_INTEGER frequency{};QueryPerformanceFrequency(&frequency);g.play_anchor_qpc.QuadPart-=frequency.QuadPart*10;
    handle_playback_message(window,WM_TIMER,1,0);
    require(!g.playing && g.playhead_active && g.playhead==4,"EOF pauses playback without trapping its visible timeline");
    start_play();require(g.playing && g.playhead==0,"playback can be started again after a completed run");
    stop_play();seek_playhead(1.5);start_play();
    require(g.playing && g.play_anchor_data==1.5,"resume uses the explicitly chosen timeline position");stop_play();
    g.win_start=0;g.win_end=4;g.vrect=plot_rect();g.vx0=0;g.vx1=4;g.vy0=0;g.vy1=2;g.vvalid=true;
    const auto px=[&](double fraction){return g.vrect.left+static_cast<int>(fraction*(g.vrect.right-g.vrect.left));};
    const int y=g.vrect.top+40;
    require(hit_test_playhead(px(1.5/4),y) && !hit_test_playhead(px(.9),y),"only the visible red line claims timeline dragging");
    handle_input_message(window,WM_LBUTTONDOWN,0,MAKELPARAM(px(1.5/4),y));
    require(g.playhead_dragging && g.playhead_selected && !g.point_click_pending,"red timeline can be grabbed even with point mode enabled");
    handle_input_message(window,WM_MOUSEMOVE,MK_LBUTTON,MAKELPARAM(px(.75),y));
    handle_input_message(window,WM_LBUTTONUP,0,MAKELPARAM(px(.75),y));
    require(!g.playhead_dragging && !g.playing && std::fabs(g.playhead-3)<.01 && g.point_groups.empty(),
        "timeline dragging seeks without adding an annotation or moving the viewport");
    handle_input_message(window,WM_KEYDOWN,VK_DELETE,0);
    require(!g.playhead_active && !g.playing,"Delete removes the selected timeline");
    seek_playhead(2);handle_input_message(window,WM_KEYDOWN,VK_ESCAPE,0);
    require(!g.playhead_active && has_fft_window() && g.fft_window_start==1 && g.fft_window_end==3,
        "Escape hides the timeline while preserving the numerical analysis interval");
    seek_playhead(2);handle_input_message(window,WM_RBUTTONDOWN,0,MAKELPARAM(px(.5),y));
    require(!g.playhead_active,"right click on the red line removes it");
    seek_playhead(2);handle_input_message(window,WM_LBUTTONDOWN,0,MAKELPARAM(px(.5),y));
    handle_input_message(window,WM_MOUSEMOVE,MK_LBUTTON,MAKELPARAM(px(.9),y));
    handle_input_message(window,WM_KEYDOWN,VK_ESCAPE,0);
    require(g.playhead_active && !g.playhead_dragging && g.playhead==2,"Escape during a timeline drag restores its previous position");
    g.overview.render_enabled=true;g.recording_rows=g.ds.rows();
    handle_input_message(window,WM_LBUTTONDOWN,0,MAKELPARAM(px(.5),y));
    handle_input_message(window,WM_MOUSEMOVE,MK_LBUTTON,MAKELPARAM(px(.8),y));
    handle_input_message(window,WM_CAPTURECHANGED,0,0);
    require(!g.playhead_dragging && g.playhead==2,"losing capture cancels timeline dragging in the source renderer");
    if(GetCapture()==window)ReleaseCapture();
    handle_commands_message(window,WM_COMMAND,IDM_STOP_PLAYBACK,0);
    require(!g.playhead_active && !g.playing && g.numerical_revision==numerical,
        "the menu resets playback without changing the numerical input");
    g.overview.render_enabled=false;
    g.ds.time={0,1,2,102,103,104};g.ds.channels={{0,1,2,3,4,5}};g.data_t1=g.win_end=104;
    g.stitch_time_gaps=true;invalidate_stitched_time_cache();g.vx0=0;g.vx1=5;g.vvalid=true;
    seek_playhead(103);handle_input_message(window,WM_LBUTTONDOWN,0,MAKELPARAM(px(.8),y));
    handle_input_message(window,WM_MOUSEMOVE,MK_LBUTTON,MAKELPARAM(px(.2),y));
    handle_input_message(window,WM_LBUTTONUP,0,MAKELPARAM(px(.2),y));
    require(std::fabs(g.playhead-1)<.01,"dragging a stitched timeline preserves raw acquisition coordinates");
    start_play();set_mode(AnalysisMode::FFT);
    require(!g.playing && !g.playhead_dragging && !g.playhead_selected,"changing analysis mode cancels timeline interaction and its timer");
}

void routed_window_messages() {
    reset_document({"A", "B"}, {0,1,2,3}, {{1,2,3,4},{4,3,2,1}});
    struct TestWindow {
        HWND handle = CreateWindowExW(0, L"STATIC", L"Message routing regression", 0, 0, 0, 0, 0,
                                      HWND_MESSAGE, nullptr, GetModuleHandleW(nullptr), nullptr);
        ~TestWindow() { g.main = nullptr; if (handle) DestroyWindow(handle); }
    } window;
    require(window.handle != nullptr, "message routing test window");
    g.main = window.handle;
    WndProc(g.main, WM_COMMAND, IDC_HIDE_ALL, 0);
    require(g.visible == std::vector<char>{0,0} && g_undo.size() == 1,
            "command routing hides channels and records undo");
    WndProc(g.main, WM_COMMAND, IDC_SHOW_ALL, 0);
    require(g.visible == std::vector<char>{1,1} && g_undo.size() == 2,
            "command routing restores channel visibility");
    WndProc(g.main, WM_COMMAND, IDM_ADD_MARKER, 0);
    require(g.pending_marker, "command routing arms marker placement");
    WndProc(g.main, WM_KEYDOWN, VK_ESCAPE, 0);
    require(!g.pending_marker, "input routing cancels pending marker placement");
    for (int command : {IDC_MEASURE, IDM_ADD_MARKER, IDM_ADD_VLINE, IDM_ADD_HLINE}) {
        WndProc(g.main, WM_COMMAND, command, 0);
        WndProc(g.main, WM_COMMAND, IDC_CURSOR_TOOL, 0);
        require(!g.measure_mode && !g.pending_marker && g.pending_line == 0,
                "cursor tool cancels every annotation placement mode");
    }
    for(AnalysisMode mode:{AnalysisMode::Time,AnalysisMode::FFT,AnalysisMode::FRF}) {
        g.mode=mode;
        WndProc(g.main,WM_COMMAND,IDM_ADD_VLINE,0);
        const bool snap_before=g.snap_to_data;
        const auto revision=g.numerical_revision;
        WndProc(g.main,WM_COMMAND,IDC_MAGNET_TOOL,0);
        require(g.snap_to_data!=snap_before && g.pending_line==1 && g.numerical_revision==revision,
            "shared magnet toggles independently of the Points tab without disarming lines or changing numerical inputs");
        pop_undo();require(g.snap_to_data==snap_before,"Undo restores the shared magnet state in every analysis mode");
        pop_redo();require(g.snap_to_data!=snap_before,"Redo restores the shared magnet toggle in every analysis mode");
        WndProc(g.main,WM_COMMAND,IDC_MAGNET_TOOL,0);
        WndProc(g.main,WM_COMMAND,IDC_CURSOR_TOOL,0);
    }
    g.mode=AnalysisMode::Time;
    require(!is_side_toggle_id(IDC_MAGNET_TOOL),"the shared magnet is not a Points sidebar checkbox");
    for(const auto* language:{&kRu,&kEn}) {
        g_str=language;
        require(std::wstring(magnet_button_text())==(language==&kEn ? L"Magnet" : L"Магнит"),
            "the shared magnet retains an accessible localized name behind its icon in both languages");
    }
    g_str=&kEn;
    PointGroup annotation_group;
    annotation_group.points={{1.0,2.0}};
    g.point_groups={annotation_group};
    g.annotation_selection_kind=App::AnnotationSelectionKind::Point;
    g.annotation_selection_index=0;
    g.annotation_selection_point_index=0;
    require(delete_selected_annotation() && g.point_groups.empty(),
            "Delete removes the selected measurement point and its empty group");
    pop_undo();
    require(g.point_groups[0].points.size()==1,"Undo restores a deleted measurement point");
    pop_redo();
    require(g.point_groups.empty(),"Redo removes the measurement point and its empty group again");
    g.guides={{true,1.0,AnalysisMode::Time}};
    g.annotation_selection_kind=App::AnnotationSelectionKind::Guide;
    g.annotation_selection_index=0;
    require(delete_selected_annotation() && g.guides.empty(),"Delete removes the selected guide");
    pop_undo();
    require(g.guides.size()==1,"Undo restores a deleted guide");
    g.markers={{1.0,2.0,L"M1",false,AnalysisMode::Time,false,-1}};
    g.annotation_selection_kind=App::AnnotationSelectionKind::Marker;
    g.annotation_selection_index=0;
    require(delete_selected_annotation() && g.markers.empty(),"Delete removes the selected marker");
    pop_undo();
    require(g.markers.size()==1,"Undo restores a deleted marker");
    g.annotations_locked=true;
    g.annotation_selection_kind=App::AnnotationSelectionKind::Marker;
    g.annotation_selection_index=0;
    require(!delete_selected_annotation() && g.markers.size()==1,"annotation lock also prevents deletion");
    g.annotations_locked=false;
    MINMAXINFO limits{};
    WndProc(g.main, WM_GETMINMAXINFO, 0, reinterpret_cast<LPARAM>(&limits));
    require(limits.ptMinTrackSize.x == 980 && limits.ptMinTrackSize.y == 560,
            "window routing preserves minimum window size");
    require(WndProc(g.main, WM_ERASEBKGND, 0, 0) == 1, "window routing preserves background erase handling");
    g.async_load_token = 17;
    g.async_load_stage = AsyncLoadStage::LoadingFile;
    auto result = std::make_unique<AsyncLoadResult>();
    result->token = 17; result->cancelled = true;
    WndProc(g.main, WM_APP_ASYNC_LOAD_DONE, 0, reinterpret_cast<LPARAM>(result.release()));
    require(g.async_load_stage == AsyncLoadStage::None && g.ds.rows() == 4,
            "loading routing consumes cancelled results without replacing the document");
}

void display_load_budget() {
    constexpr std::uint64_t gib=1024ULL*1024*1024;
    require(display_load_memory_budget(24*gib,24*gib)==(24*gib-24*gib/5)/3,
            "large resident loads scale above the former two-GiB ceiling");
    require(display_load_memory_budget(4*gib,8*gib)==(4*gib-4*gib/5)/3,
            "display loading reserves physical memory for processing and other documents");
    require(display_load_memory_budget(24*gib,gib)==gib/6,
            "low available commit restricts loading despite ample physical memory");
    require(display_load_memory_budget(0,24*gib)==1 && display_load_memory_budget(24*gib,0)==1,
            "memory pressure never turns the display limit into an unbounded load");
}

void loading_window_ownership() {
    reset_document({"existing"},{0,1},{{7,8}});
    struct OwnerWindow {
        HWND handle=CreateWindowExW(0,L"STATIC",L"Loading owner regression",WS_OVERLAPPEDWINDOW,
                                   200,200,800,600,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
        ~OwnerWindow() { hide_loading();g.main=nullptr;if(handle)DestroyWindow(handle); }
    } owner;
    require(owner.handle!=nullptr,"loading regression creates a hidden top-level owner");
    g.main=owner.handle;
    const HWND foreground=GetForegroundWindow();
    g.async_load_cancel_flag=std::make_shared<std::atomic<bool>>(false);
    show_loading(L"Please wait",true);
    require(g_loading_wnd && GetWindow(g_loading_wnd,GW_OWNER)==g.main,
            "loading notice belongs to the AMSignal window");
    require((GetWindowLongPtrW(g_loading_wnd,GWL_EXSTYLE)&WS_EX_TOPMOST)==0,
            "loading notice is not globally topmost");
    require(!IsWindowVisible(g_loading_wnd) && GetForegroundWindow()==foreground,
            "a hidden owner does not show a notice over other applications or take focus");
    require(!IsWindowEnabled(g.main) && g_loading_cancel_btn,
            "loading still disables the owner and provides cancellation");
    SendMessageW(g_loading_wnd,WM_COMMAND,MAKEWPARAM(IDC_LOADING_CANCEL,BN_CLICKED),
                 reinterpret_cast<LPARAM>(g_loading_cancel_btn));
    require(g.async_load_cancel_flag->load(),"loading cancel button still cancels the worker");
    hide_loading();
    require(!g_loading_wnd && IsWindowEnabled(g.main) && GetForegroundWindow()==foreground,
            "closing a background loading notice re-enables its owner without taking focus");
    g.async_load_cancel_flag.reset();
}

void bounded_load_recovery() {
    reset_document({"existing"},{0,1},{{7,8}});
    const auto path=test_dir/"bounded_load.txt";
    {std::ofstream out(path);out<<"0\t1\n1\t2\n";}
    g.cached_scan_valid=false;
    AsyncLoadResult failed;failed.path=std::filesystem::absolute(path).wstring();
    failed.ds.time.assign(1024,0);failed.ds.resident_limit_exceeded=true;
    require(retry_load_as_source(failed),"bounded load recovery starts the complete source automatically");
    require(g.async_load_stage==AsyncLoadStage::ScanningRange,"bounded load recovery scans instead of retrying an unbounded full load");
    require(failed.ds.time.capacity()==0,"failed display arrays are freed before recovery");
    require(g.ds.channels==std::vector<std::vector<double>>{{7,8}},"bounded load recovery preserves the current document");
    request_async_load_cancel();if(g_load_worker.joinable())g_load_worker.join();
    g.async_load_stage=AsyncLoadStage::None;g.async_load_cancel_flag.reset();
}

void filter_bound_crossing() {
    reset_document({"signal"},{0,.001,.002,.003},{{1,0,-1,0}});
    HWND window=CreateWindowExW(0,L"STATIC",L"Filter bounds",WS_POPUP,0,0,400,240,
        nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    require(window!=nullptr,"filter bounds regression has a hidden control owner");g.main=window;
    const auto track=[&](int id,int y) {
        return CreateWindowExW(0,TRACKBAR_CLASSW,L"",WS_CHILD|TBS_HORZ,0,y,300,30,
            window,reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),GetModuleHandleW(nullptr),nullptr);
    };
    g.side_filter_low_track=track(IDC_SIDE_FILTER_LOW_TRACK,0);
    g.side_filter_high_track=track(IDC_SIDE_FILTER_HIGH_TRACK,60);
    g.side_filter_low_value=CreateWindowExW(0,L"STATIC",L"",WS_CHILD,0,30,300,20,window,nullptr,nullptr,nullptr);
    g.side_filter_high_value=CreateWindowExW(0,L"STATIC",L"",WS_CHILD,0,90,300,20,window,nullptr,nullptr,nullptr);
    struct Cleanup {HWND window;~Cleanup(){DestroyWindow(window);g.main=nullptr;
        g.side_filter_low_track=g.side_filter_high_track=g.side_filter_low_value=g.side_filter_high_value=nullptr;}
    } cleanup{window};
    require(g.side_filter_low_track && g.side_filter_high_track && g.side_filter_low_value && g.side_filter_high_value,
        "both native filter sliders and readouts are available");
    const auto text=[](HWND label){wchar_t value[64]{};GetWindowTextW(label,value,64);return std::wstring(value);};
    const auto drag=[&](bool low,int position,UINT notification) {
        HWND ctl=low ? g.side_filter_low_track : g.side_filter_high_track;
        SendMessageW(ctl,TBM_SETPOS,TRUE,position);
        handle_commands_message(window,WM_HSCROLL,MAKEWPARAM(notification,position),reinterpret_cast<LPARAM>(ctl));
    };
    for(const auto& change:{std::pair<bool,int>{false,400},{true,950},{true,500},{false,900},{false,0},{true,1000}}) {
        g.noise_threshold_min=100;g.noise_threshold_max=400;g.noise_threshold_enabled=true;
        g_undo.clear();g_redo.clear();g_filter_slider_before.reset();sync_filter_controls_from_state();
        const double value=filter_slider_to_frequency(change.second,500);
        const double expected_low=change.first ? value : std::min(100.0,value);
        const double expected_high=change.first ? std::max(400.0,value) : value;
        const auto revision=g.numerical_revision;
        // Crossing and then retreating must restore the untouched bound in the preview.
        drag(change.first,change.first ? 1000 : 0,TB_THUMBTRACK);
        drag(change.first,change.second,TB_THUMBTRACK);
        require(text(g.side_filter_low_value)==filter_frequency_text(expected_low) &&
            text(g.side_filter_high_value)==filter_frequency_text(expected_high),
            "drag preview displays the chosen cutoff and clamps only the other bound, including retreat from a crossing");
        require(SendMessageW(g.side_filter_low_track,TBM_GETPOS,0,0)==frequency_to_filter_slider(expected_low,500) &&
            SendMessageW(g.side_filter_high_track,TBM_GETPOS,0,0)==frequency_to_filter_slider(expected_high,500),
            "both slider positions agree with their preview readouts");
        require(g.noise_threshold_min==100 && g.noise_threshold_max==400 && g.numerical_revision==revision && g_undo.empty(),
            "coupled previews do not recompute filtering or create undo entries");
        drag(change.first,change.second,TB_THUMBPOSITION);
        near(g.noise_threshold_min,expected_low,"committed lower cutoff follows the edited bound without swapping");
        near(g.noise_threshold_max,expected_high,"committed upper cutoff follows the edited bound without swapping");
        drag(change.first,change.second,TB_ENDTRACK);
        require(g_undo.size()==1,"committing both filter bounds creates exactly one undo entry");
        pop_undo();
        require(g.noise_threshold_min==100 && g.noise_threshold_max==400,"Undo restores both original filter bounds");
        pop_redo();
        near(g.noise_threshold_min,expected_low,"Redo restores the corrected lower cutoff");
        near(g.noise_threshold_max,expected_high,"Redo restores the corrected upper cutoff");
    }
}

void resident_envelope_and_history() {
    reset_document({"gap"}, {0, 1, 2, 102, 103, 104}, {{0, 1, 2, 3, 4, 5}});
    g.stitch_time_gaps = true;
    invalidate_stitched_time_cache();
    near(stitched_time_at_index(0), 0, "stitched graph preserves first timestamp");
    near(stitched_time_from_raw(103), 4, "raw time maps to stitched graph axis");
    near(raw_time_from_stitched(4), 103, "stitched graph coordinate maps back to raw time");
    g.stitch_time_gaps = false;
    near(stitched_time_at_index(3), 102, "disabling stitched graph restores the original time axis");

    std::vector<double> time(300001), values(time.size(), 0);
    for (std::size_t i = 0; i < time.size(); ++i) time[i] = i * 0.001;
    values[11] = 100;
    reset_document({"impulse"}, time, {values});
    double low = 0, high = 0;
    require(current_time_yrange_window(0, time.size(), low, high) && high >= 100, "Light Mode auto Y includes a single-sample impulse");
    g.global_formula = L"2*x"; rebuild_formula_cache_from_state(); recompute_transforms_from_state();
    require(current_time_yrange_window(0, time.size(), low, high) && high >= 200, "envelope invalidates after formula changes");
    require(current_time_yrange_window(12, 100, low, high) && high < 10, "envelope query excludes an impulse outside the window");

    reset_document({"signal"}, {0,.001,.002,.003}, {{1,0,-1,0}});
    g.noise_threshold_enabled = true; g.noise_threshold_min = 10; g.noise_threshold_max = 400;
    PointGroup group; group.name = L"measurements"; group.points = {{0,1}};
    g.point_groups.push_back(group); g.active_point_group = g.time_active_point_group = 0;
    const auto serial = g.plot_analysis_serial;
    for (int position = 400; position < 600; ++position) apply_filter_slider_change(true, position, true);
    near(g.noise_threshold_min, 10, "drag previews do not change active filter");
    require(g_undo.empty() && g.plot_analysis_serial == serial, "drag previews avoid repeated FFT/filter invalidation and history copies");
    apply_filter_slider_change(true, 599, false);
    const double applied = g.noise_threshold_min;
    require(g_undo.size() == 1 && g.point_groups.empty(), "one filter drag creates one undo action and clears obsolete measurements");
    apply_filter_slider_change(true, 599, false);
    require(g_undo.size() == 1, "track end notification does not duplicate undo");
    pop_undo();
    near(g.noise_threshold_min, 10, "undo restores original cutoff");
    require(g.point_groups.size() == 1 && g.point_groups[0].points.size() == 1, "undo restores measurements removed by the filter change");
    pop_redo();
    near(g.noise_threshold_min, applied, "redo restores applied cutoff");
    require(g.point_groups.empty(), "redo clears obsolete measurements again");
    ensure_filtered_channel_cache(0);
    require(!g.filtered_channel_cache[0].empty(), "enabled filter produces a cache");
    g.noise_threshold_enabled = false; invalidate_filtered_channel_cache();
    require(g.filtered_channel_cache[0].capacity() == 0, "disabling filter releases stored filtered samples");

    g_undo.clear(); g_redo.clear();
    for (std::size_t i = 0; i < kUndoActionLimit + 20; ++i) {
        UndoAction action; action.type = UndoAction::ADD_LINE; action.line.value = static_cast<double>(i);
        push_undo(std::move(action));
    }
    require(g_undo.size() == kUndoActionLimit && g_undo.front().line.value == 20, "history discards oldest actions at the count limit");
    g_undo.clear();
    for (int i = 0; i < 10; ++i) {
        UndoAction action; action.type = UndoAction::CLEAR_POINTS;
        action.saved_point_groups.resize(1);
        action.saved_point_groups[0].points.resize(kUndoByteLimit / 8 / sizeof(std::pair<double,double>));
        push_undo(std::move(action));
    }
    require(history_stack_bytes(g_undo) <= kUndoByteLimit && g_undo.size() < 10, "history obeys memory limit for large measurement groups");
    g_undo.clear();
}

void frf_integration() {
    std::vector<double> t, x, y;
    for (int i=0;i<1024;++i) {
        t.push_back(i/1024.0);
        x.push_back(std::sin(2*std::acos(-1.0)*16*i/1024));
        y.push_back((i<512 ? 2 : 4)*x.back());
    }
    reset_document({"Input, special", "Output"}, t, {x,y});
    require(g.frf.inputs.empty() && g.frf.outputs.empty(), "FRF starts without preselected channel roles");
    require(!g.frf.logarithmic_frequency_axis, "new FRF views default to a linear frequency axis");
    require(set_frf_channels({0},{1}), "FRF accepts the first selected support and response");
    g.frf.options.estimator=lvm::FrfEstimator::Direct;
    set_fft_window(t[0],t[511]);
    g.visible={0,0};
    set_mode(AnalysisMode::FRF);
    require(g.mode==AnalysisMode::FRF && g.frf.result.ok, "FRF is a third mode independent of channel visibility");
    require(g.frf.result.common().sample_count==512 && g.frf.from_selection, "FRF uses one shared selected interval");
    near(lvm::frf_dynamic_coefficient(g.frf.result.common(),8),2,"selected FRF excludes the different response outside the selection");
    require(g.frf.result.common().valid[8] && !g.frf.result.common().valid[80], "weak input bins are masked in GUI result");
    require(g.frf.result.common().reference_amplitude_valid[8] &&
            g.frf.result.common().reference_amplitude[8]>0,"GUI receives the averaged Reference amplitude graph");
    g.frf.logarithmic_frequency_axis=true;
    sync_frf_frequency_limits();
    require(set_frf_frequency_range(4,64),"valid FRF frequency limits accepted");
    near(frf_frequency_at_fraction(.5),16,"log-frequency midpoint is geometric");
    near(frf_frequency_fraction(16),.5,"frequency-to-pixel inverse matches log mapping");
    g.frf.logarithmic_frequency_axis=false;
    sync_frf_frequency_limits();
    near(frf_frequency_at_fraction(.5),34,"linear-frequency midpoint is arithmetic");
    near(frf_frequency_fraction(34),.5,"frequency-to-pixel inverse matches linear mapping");
    zoom_at(.5,.5);
    near(frf_frequency_at_fraction(.5),34,"linear FRF zoom preserves frequency at cursor");
    g.frf.logarithmic_frequency_axis=true;
    sync_frf_frequency_limits();
    require(set_frf_frequency_range(4,64),"restore logarithmic range after linear navigation");
    const auto generation=g.frf.generation;
    const auto transfer=g.frf.result.common().transfer;
    zoom_at(.5,.5);
    near(frf_frequency_at_fraction(.5),16,"FRF zoom preserves frequency at cursor");
    require(g.frf.generation==generation && g.frf.result.common().transfer==transfer,"view zoom does not recalculate FRF");
    require(!set_frf_frequency_range(0,64) && !set_frf_frequency_range(64,4) && !set_frf_frequency_range(1,1000),
            "invalid logarithmic ranges rejected");
    require(set_frf_frequency_range(4,64),"restore test export range");
    const auto path=test_dir / std::filesystem::u8path(u8"ачх_測定.csv");
    require(save_frf_csv(path.wstring()),"FRF CSV supports Unicode paths");
    ExportOptions frf_options; frf_options.format=ExportFileFormat::Csv;
    require(save_tabular_export((test_dir/"frf_generic.csv").wstring(),frf_options),
            "generic CSV exporter dispatches to FRF in the third mode");
    require(!save_lvm_export((test_dir/"invalid_frf.lvm").wstring(),frf_options),
            "time-domain LVM export is unavailable in FRF");
    std::ifstream input(path);
    std::string text((std::istreambuf_iterator<char>(input)),{});
    require(text.find("data_kind=frf")!=std::string::npos && text.find("window=hann_periodic")!=std::string::npos &&
            text.find("frequency_hz,dynamic_coefficient,h_real,h_imag,valid")!=std::string::npos,
            "FRF CSV contains schema, window, complex transfer, and validity");
    require(text.find("input_name=Input%2C special")!=std::string::npos &&
            text.find(",,,0")!=std::string::npos,"FRF CSV escapes labels and leaves invalid ratios empty");
    require(!lvm::read_lvm_file(path).ok,"FRF CSV cannot silently reopen as a time signal");
    g.frf.pending=true;
    require(!save_frf_csv(path.wstring()),"pending FRF export rejected");
    std::ifstream preserved(path);
    require(std::string((std::istreambuf_iterator<char>(preserved)),{})==text,"failed FRF export preserves existing file");
    g.frf.pending=false;
    const double view_start=g.frf.log_start, view_end=g.frf.log_end;
    set_mode(AnalysisMode::Time);
    require(g.win_start==t.front() && g.win_end==t.back(),"FRF navigation leaves time view unchanged");
    set_mode(AnalysisMode::FRF);
    near(g.frf.log_start,view_start,"FRF view preserved on mode switch");
    near(g.frf.log_end,view_end,"FRF frequency limits preserved on return");
    g.pending_marker=false;
    WndProc(nullptr,WM_COMMAND,IDM_ADD_MARKER,0);
    require(g.pending_marker && frf_command_supported(IDM_ADD_MARKER),"FRF accepts the common marker tool");
    g.pending_marker=false;
    WndProc(nullptr,WM_COMMAND,IDM_ADD_VLINE,0);
    require(g.pending_line==1 && frf_command_supported(IDC_MEASURE),"FRF reuses the standard point and line tools");
    add_guide_line(true,16);
    add_guide_line(false,2);
    require(g.guides.size()>=2 && g.guides[g.guides.size()-2].mode==AnalysisMode::FRF &&
            g.guides.back().mode==AnalysisMode::FRF,"FRF lines use the common annotation collection");
    clear_fft_window();
    g.win_start=t[512]; g.win_end=t.back();
    ensure_current_frf();
    require(g.frf.result.ok && g.frf.result.common().sample_count==t.size(),"FRF falls back to the entire recording independently of zoom");
    require(change_analysis_range(lvm::AnalysisRange::selected(g.win_start,g.win_end)),"a visible interval can be explicitly chosen for both analyses");
    ensure_current_frf();
    near(lvm::frf_dynamic_coefficient(g.frf.result.common(),8),4,"FRF explicitly chosen interval updates both channels");
    g.frf.apply_processing=true;
    g.channel_formulas[1]=L"3*x"; rebuild_formula_cache_from_state();
    on_frf_processing_changed();
    near(lvm::frf_dynamic_coefficient(g.frf.result.common(),8),12,"FRF can explicitly use channel processing");
    g.frf.apply_processing=false; invalidate_frf(); ensure_current_frf();
    near(lvm::frf_dynamic_coefficient(g.frf.result.common(),8),4,"raw FRF ignores display processing");
    {
        // Start with no annotations so the following placement/drag sequence
        // exercises its own marker and guide deterministically.
        g.guides.clear();
        g.markers.clear();
        clear_measure_point_groups();
        Gdiplus::GdiplusStartupInput startup;
        ULONG_PTR token=0;
        require(Gdiplus::GdiplusStartup(&token,&startup,nullptr)==Gdiplus::Ok,"GDI+ starts for FRF PNG test");
        struct Window {
            HWND hwnd=CreateWindowExW(0,L"STATIC",L"FRF rendering test",WS_POPUP|WS_CLIPCHILDREN,
                0,0,980,500,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
            ~Window() { g.main=nullptr; if(hwnd) DestroyWindow(hwnd); }
        } window;
        require(window.hwnd!=nullptr,"hidden FRF rendering window");
        g.main=window.hwnd;
        g.ui_font=reinterpret_cast<HFONT>(GetStockObject(DEFAULT_GUI_FONT));
        update_theme_brushes();
        create_frequency_view_controls(g.main,GetModuleHandleW(nullptr));
        create_frf_panel(g.main,GetModuleHandleW(nullptr));
        layout();
        require(g.frf_panel!=nullptr,"FRF panel is embedded in the existing main window");
        require(!GetDlgItem(g.frf_panel,7113) && !GetDlgItem(g.frf_panel,7114) && !GetDlgItem(g.frf_panel,7115),
                "FRF panel omits Calculate, CSV and PNG buttons");
        double frf_low=0, frf_high=0; frf_y_range(frf_low,frf_high);
        const RECT chart=plot_rect();
        g.vvalid=true; g.vrect=chart; g.vx0=g.frf.log_start; g.vx1=g.frf.log_end;
        g.vy0=frf_low; g.vy1=frf_high;
        const int point_x=(chart.left+chart.right)/2, point_y=(chart.top+chart.bottom)/2;
        g.measure_mode=false; g.pending_line=0; g.pending_marker=false;
        const RECT reference_chart=frf_reference_plot_rect(chart);
        const int reference_x=(reference_chart.left+reference_chart.right)/2;
        const int reference_y=(reference_chart.top+reference_chart.bottom)/2;
        // Leave horizontal room on both sides so the drag verifies the shared
        // frequency pan rather than clamping at the full-range boundary.
        zoom_at(.5,.8);
        POINT wheel{reference_x,reference_y};ClientToScreen(g.main,&wheel);
        const auto wheel_position=MAKELPARAM(wheel.x,wheel.y);
        const auto generation_before_wheel=g.frf.generation;
        const bool logarithmic_before_wheel=g.frf.logarithmic_frequency_axis;
        const double low_before_wheel=g.frf.frequency_start,high_before_wheel=g.frf.frequency_end;
        const double log_low_before_wheel=g.frf.log_start,log_high_before_wheel=g.frf.log_end;
        for(bool logarithmic:{false,true}) {
            g.frf.logarithmic_frequency_axis=logarithmic;
            double *lo=nullptr,*hi=nullptr,minb=0,maxb=0,minw=0;
            require(active_axis(lo,hi,minb,maxb,minw),"FRF wheel check has a ready frequency axis");
            *lo=minb+(maxb-minb)*.25;*hi=minb+(maxb-minb)*.75;
            sync_frf_frequency_limits();
            const double before=logarithmic ? g.frf.log_start : g.frf.frequency_start;
            const double width=logarithmic ? g.frf.log_end-g.frf.log_start : g.frf.frequency_end-g.frf.frequency_start;
            WndProc(g.main,WM_MOUSEWHEEL,MAKEWPARAM(MK_SHIFT,WHEEL_DELTA),wheel_position);
            near(logarithmic ? g.frf.log_start : g.frf.frequency_start,before-width*.1,
                "Shift wheel pans the shared FRF axis over Reference in linear and log views");
            WndProc(g.main,WM_MOUSEHWHEEL,MAKEWPARAM(0,WHEEL_DELTA),wheel_position);
            near(logarithmic ? g.frf.log_start : g.frf.frequency_start,before,
                "native horizontal wheel returns the FRF axis without changing its scale");
        }
        g.frf.logarithmic_frequency_axis=logarithmic_before_wheel;
        g.frf.frequency_start=low_before_wheel;g.frf.frequency_end=high_before_wheel;
        g.frf.log_start=log_low_before_wheel;g.frf.log_end=log_high_before_wheel;
        require(g.frf.generation==generation_before_wheel,"FRF wheel navigation does not recalculate the result");
        const double frequency_start_before_reference_drag=g.frf.frequency_start;
        const double frequency_end_before_reference_drag=g.frf.frequency_end;
        const double log_start_before_reference_drag=g.frf.log_start;
        const double log_end_before_reference_drag=g.frf.log_end;
        double reference_before_low=0, reference_before_high=0;
        frf_reference_y_range(reference_before_low,reference_before_high);
        handle_frf_input(g.main,WM_LBUTTONDOWN,0,MAKELPARAM(reference_x,reference_y));
        handle_frf_input(g.main,WM_MOUSEMOVE,0,MAKELPARAM(reference_x+20,reference_y+12));
        handle_frf_input(g.main,WM_LBUTTONUP,0,MAKELPARAM(reference_x+20,reference_y+12));
        double reference_after_low=0, reference_after_high=0;
        frf_reference_y_range(reference_after_low,reference_after_high);
        require(!g.frf.reference_auto_y && reference_after_low==0.0 &&
                reference_after_high>reference_before_high,
                "dragging averaged Reference adjusts its scale from a zero baseline like KD");
        require(g.frf.frequency_start!=frequency_start_before_reference_drag ||
                g.frf.frequency_end!=frequency_end_before_reference_drag ||
                g.frf.log_start!=log_start_before_reference_drag ||
                g.frf.log_end!=log_end_before_reference_drag,
                "dragging averaged Reference pans the shared frequency view with KD");
        const bool vertical_pan_before_reference_drag=g.vertical_pan;
        const bool snap_before_reference_drag=g.snap_to_data;
        const bool coefficient_auto_before_reference_drag=g.frf.auto_y;
        const double coefficient_min_before_reference_drag=g.frf.y_min;
        const double coefficient_max_before_reference_drag=g.frf.y_max;
        for(bool logarithmic:{false,true})for(bool snap:{false,true}) {
            g.frf.logarithmic_frequency_axis=logarithmic;g.snap_to_data=snap;g.vertical_pan=snap;
            double *lo=nullptr,*hi=nullptr,minb=0,maxb=0,minw=0;
            require(active_axis(lo,hi,minb,maxb,minw),"point-mode Reference drag has a valid frequency axis");
            *lo=minb+(maxb-minb)*.25;*hi=minb+(maxb-minb)*.75;sync_frf_frequency_limits();
            const double start=*lo,end=*hi;
            g.frf.reference_auto_y=true;g.measure_mode=true;
            double initial_low=0,initial_high=1;frf_reference_y_range(initial_low,initial_high);
            const auto group_count=g.point_groups.size(),undo_count=g_undo.size();
            const auto generation=g.frf.generation;
            handle_frf_input(g.main,WM_LBUTTONDOWN,0,MAKELPARAM(reference_x,reference_y));
            require(g.point_click_pending && g.point_click_reference_axis,
                "Reference starts a deferred point click on its own amplitude axis");
            handle_frf_input(g.main,WM_MOUSEMOVE,MK_LBUTTON,MAKELPARAM(reference_x+2,reference_y+2));
            require(g.point_click_pending && g.frf.reference_auto_y,
                "small point-mode mouse jitter does not change the Reference scale");
            handle_frf_input(g.main,WM_MOUSEMOVE,MK_LBUTTON,MAKELPARAM(reference_x,reference_y+12));
            near(g.frf.reference_y_max,initial_high+12.0/(reference_chart.bottom-reference_chart.top)*(initial_high-initial_low),
                "the first point-mode drag movement immediately scales Reference using its own height and initial Y range");
            require(*lo==start && *hi==end && !g.frf.reference_auto_y && g.frf.reference_y_min==0,
                "a purely vertical Reference gesture retains the shared frequency window and zero baseline");
            handle_frf_input(g.main,WM_MOUSEMOVE,MK_LBUTTON,MAKELPARAM(reference_x+20,reference_y+20));
            near(g.frf.reference_y_max,initial_high+20.0/(reference_chart.bottom-reference_chart.top)*(initial_high-initial_low),
                "continued point-mode motion uses the same Reference drag snapshot");
            require(*lo!=start && *hi!=end,"point-mode Reference dragging also pans the shared frequency window");
            handle_frf_input(g.main,WM_LBUTTONUP,0,MAKELPARAM(reference_x+20,reference_y+20));
            require(g.measure_mode && !g.point_click_pending && !g.point_click_reference_axis && !g.dragging && GetCapture()!=g.main &&
                g.point_groups.size()==group_count && g_undo.size()==undo_count,
                "Reference navigation keeps point mode enabled without inserting points or adding annotation history");
            require(g.frf.auto_y==coefficient_auto_before_reference_drag && g.frf.y_min==coefficient_min_before_reference_drag &&
                g.frf.y_max==coefficient_max_before_reference_drag && g.frf.generation==generation,
                "point-mode Reference navigation leaves the upper FRF Y scale and numerical result unchanged");
            const double released_max=g.frf.reference_y_max;
            handle_frf_input(g.main,WM_MOUSEMOVE,0,MAKELPARAM(reference_x,reference_y));
            require(g.frf.reference_y_max==released_max,"releasing the mouse ends the Reference drag");
        }
        g.measure_mode=false;g.vertical_pan=vertical_pan_before_reference_drag;g.snap_to_data=snap_before_reference_drag;
        g.frf.logarithmic_frequency_axis=logarithmic_before_wheel;
        // The following annotation scenarios use the original centered view.
        // Restore it after this navigation-specific assertion so they remain
        // independent from the drag test.
        g.frf.frequency_start=frequency_start_before_reference_drag;
        g.frf.frequency_end=frequency_end_before_reference_drag;
        g.frf.log_start=log_start_before_reference_drag;
        g.frf.log_end=log_end_before_reference_drag;
        g.frf.auto_y=true;
        WndProc(g.main,WM_COMMAND,IDC_AUTOY,0);
        require(g.frf.auto_y && g.frf.reference_auto_y,
                "FRF Auto-scale restores both automatic Y ranges after manual Reference navigation");
        WndProc(g.main,WM_COMMAND,IDM_ADD_MARKER,0);
        require(g.pending_marker,"FRF marker command remains armed in the rendered window");
        handle_frf_input(g.main,WM_LBUTTONDOWN,0,MAKELPARAM(point_x,point_y));
        handle_frf_input(g.main,WM_LBUTTONUP,0,MAKELPARAM(point_x,point_y));
        require(!g.markers.empty() && g.markers.back().mode==AnalysisMode::FRF && g.pending_marker,
                "FRF marker uses frequency and dynamic-coefficient coordinates and stays armed");
        WndProc(g.main,WM_COMMAND,IDM_ADD_VLINE,0);
        handle_frf_input(g.main,WM_LBUTTONDOWN,0,MAKELPARAM(point_x+40,point_y));
        handle_frf_input(g.main,WM_LBUTTONUP,0,MAKELPARAM(point_x+40,point_y));
        require(!g.guides.empty() && g.guides.back().mode==AnalysisMode::FRF && g.pending_line==1,
                "FRF line stays armed just like the marker tool");
        handle_frf_input(g.main,WM_KEYDOWN,VK_ESCAPE,0);
        require(!g.pending_marker && g.pending_line==0,"Esc exits the active FRF annotation tool");
        const auto marker_before_drag=g.markers.back();
        const std::size_t undo_before_drag=g_undo.size();
        handle_frf_input(g.main,WM_LBUTTONDOWN,0,MAKELPARAM(point_x,point_y));
        handle_frf_input(g.main,WM_MOUSEMOVE,0,MAKELPARAM(point_x+20,point_y));
        handle_frf_input(g.main,WM_LBUTTONUP,0,MAKELPARAM(point_x+20,point_y));
        require(g.markers.back().x!=marker_before_drag.x && g_undo.size()==undo_before_drag+1,
                "dragging an FRF marker changes it in one undo action");
        pop_undo();
        require(g.markers.back().x==marker_before_drag.x,"Undo restores the dragged FRF marker");
        pop_redo();
        require(g.markers.back().x!=marker_before_drag.x,"Redo reapplies the dragged FRF marker");
        WndProc(g.main,WM_COMMAND,IDC_LOCK_ANNOTATIONS,0);
        const std::size_t locked_marker_count=g.markers.size();
        WndProc(g.main,WM_COMMAND,IDM_ADD_MARKER,0);
        handle_frf_input(g.main,WM_LBUTTONDOWN,0,MAKELPARAM(point_x+120,point_y));
        require(g.annotations_locked && g.markers.size()==locked_marker_count,
                "annotation lock prevents new FRF annotations");
        WndProc(g.main,WM_COMMAND,IDC_LOCK_ANNOTATIONS,0);
        WndProc(g.main,WM_COMMAND,IDC_MEASURE,0);
        handle_frf_input(g.main,WM_LBUTTONDOWN,0,MAKELPARAM(point_x+80,point_y));
        handle_frf_input(g.main,WM_LBUTTONUP,0,MAKELPARAM(point_x+80,point_y));
        require(!g.point_groups.empty() && g.point_groups.back().mode==PointGroupMode::FRF &&
                !g.point_groups.back().points.empty(),"FRF measurement point uses its dedicated point group");
        const double snapped_frequency=g.point_groups.back().points.back().first;
        require(std::find(g.frf.result.common().frequencies.begin(),g.frf.result.common().frequencies.end(),snapped_frequency) !=
                g.frf.result.common().frequencies.end(),"FRF point snapping selects an actual response-frequency bin");
        handle_frf_input(g.main,WM_LBUTTONDOWN,0,MAKELPARAM(reference_x,reference_y));
        handle_frf_input(g.main,WM_LBUTTONUP,0,MAKELPARAM(reference_x,reference_y));
        require(!g.point_groups.empty() && g.point_groups.back().mode==PointGroupMode::FRF &&
                g.point_groups.back().frf_reference_axis && !g.point_groups.back().points.empty(),
                "FRF averaged Reference accepts measurement points in a separate amplitude group");
        const auto& reference_point=g.point_groups.back().points.back();
        require(reference_point.second>=0.0 && std::isfinite(reference_point.second),
                "FRF averaged Reference point uses its physical amplitude axis");
        g.measure_mode=false;
        wchar_t input_text[128]{};
        GetWindowTextW(GetDlgItem(g.frf_panel,7101),input_text,128);
        require(std::wstring(input_text).find(L"Input, special")!=std::wstring::npos,
                "FRF Input button displays the selected channel");
        SendMessageW(g.frf_panel,WM_COMMAND,MAKEWPARAM(7101,BN_CLICKED),0);
        HWND role_menu=FindWindowW(L"AMSignalFrfRoleMenu",nullptr);
        require(role_menu!=nullptr && IsWindowVisible(role_menu),"FRF roles open in one persistent menu");
        SendMessageW(role_menu,WM_LBUTTONUP,0,MAKELPARAM(10,GetSystemMetrics(SM_CYMENU)+3));
        require(IsWindow(role_menu) && IsWindow(GetDlgItem(g.frf_panel,7111)) &&
                g.frf.inputs==std::vector<int>{0},
            "FRF role menu remains open and leaves panel controls visible after a choice");
        SendMessageW(g.frf_panel,WM_COMMAND,MAKEWPARAM(7101,BN_CLICKED),0);
        require(!IsWindow(role_menu),"the same FRF role control closes its menu");
        g_theme=&kDarkTheme;
        update_theme_brushes();
        SendMessageW(g.frf_panel,WM_COMMAND,MAKEWPARAM(7101,BN_CLICKED),0);
        role_menu=FindWindowW(L"AMSignalFrfRoleMenu",nullptr);
        require(role_menu!=nullptr && IsWindowVisible(role_menu),"FRF role menu opens in the dark theme");
        RedrawWindow(role_menu,nullptr,nullptr,RDW_INVALIDATE|RDW_UPDATENOW);
        HDC role_dc=GetDC(role_menu);
        const int row_height=std::max(GetSystemMetrics(SM_CYMENU),20);
        const int check_top=2+row_height+(row_height-16)/2;
        int check_left=30,check_right=-1,check_bottom=-1,check_first_y=check_top+16;
        for(int y=2+row_height;y<2+2*row_height;++y)for(int x=3;x<26;++x)
            if(GetPixel(role_dc,x,y)==g_theme->frame) {
                check_left=std::min(check_left,x);check_right=std::max(check_right,x);
                check_first_y=std::min(check_first_y,y);check_bottom=std::max(check_bottom,y);
            }
        ReleaseDC(role_menu,role_dc);
        require(check_right-check_left+1==16 && check_bottom-check_first_y+1==16 && check_first_y==check_top,
            "FRF role checkboxes render as compact 16 px squares centered in their rows");
        SendMessageW(g.frf_panel,WM_COMMAND,MAKEWPARAM(7101,BN_CLICKED),0);
        require(!IsWindow(role_menu),"the dark FRF role menu also closes on a repeated control click");
        g_theme=&kLightTheme;
        update_theme_brushes();
        wchar_t range_text[80]{};
        require(GetWindowTextW(g.side_frequency_low,range_text,80)>0,"shared FRF range edit displays calculated limit");
        RECT panel; GetClientRect(g.frf_panel,&panel);
        require(panel.right==kRightPanel && panel.bottom>=354,"FRF controls fit below the FRF tab strip");
        SendMessageW(GetDlgItem(g.frf_panel,7122),CB_SETCURSEL,0,0);
        SendMessageW(g.frf_panel,WM_COMMAND,MAKEWPARAM(7122,CBN_SELCHANGE),0);
        require(g.frf.display_smoothing_octaves==0,"FRF display smoothing can be disabled without recalculation");
        SendMessageW(GetDlgItem(g.frf_panel,7122),CB_SETCURSEL,2,0);
        SendMessageW(g.frf_panel,WM_COMMAND,MAKEWPARAM(7122,CBN_SELCHANGE),0);
        require(std::abs(g.frf.display_smoothing_octaves-1.0/12.0)<1e-12,"FRF display smoothing can select one twelfth octave");
        const auto png=test_dir / "frf_plot.png";
        require(save_png(png.wstring()),"FRF saves graph through the existing PNG exporter");
        g.frf.show_reference_amplitude = false;
        require(save_png((test_dir / "frf_no_reference.png").wstring()), "FRF outer axis names with hidden reference graph");
        g.frf.show_reference_amplitude = true;
        const double saved_frequency_start = g.frf.frequency_start;
        const double saved_frequency_end = g.frf.frequency_end;
        const bool saved_logarithmic_axis = g.frf.logarithmic_frequency_axis;
        g.frf.logarithmic_frequency_axis = false;
        g.frf.frequency_start = 0;
        g.frf.frequency_end = 1234567;
        require(save_png((test_dir / "frf_long_edge_ticks.png").wstring()), "FRF linear frequency endpoints fit inside the plot width");
        g.frf.frequency_start = saved_frequency_start;
        g.frf.frequency_end = saved_frequency_end;
        g.frf.logarithmic_frequency_axis = saved_logarithmic_axis;
        {
            Gdiplus::Bitmap bitmap(png.c_str());
            require(bitmap.GetLastStatus()==Gdiplus::Ok && bitmap.GetWidth()>=400 && bitmap.GetHeight()>=240,
                    "exported FRF PNG is a readable image");
        }
        // Render the real controls into an artifact for layout inspection.
        HDC screen=GetDC(g.main), dc=CreateCompatibleDC(screen);
        HBITMAP bmp=CreateCompatibleBitmap(screen,panel.right,panel.bottom);
        HGDIOBJ previous=SelectObject(dc,bmp);
        FillRect(dc,&panel,g_panel_brush);
        SendMessageW(g.frf_panel,WM_PRINT,reinterpret_cast<WPARAM>(dc),PRF_CLIENT|PRF_CHILDREN|PRF_ERASEBKGND);
        SelectObject(dc,previous);
        {
            Gdiplus::Bitmap image(bmp,nullptr); CLSID encoder;
            require(png_encoder_clsid(&encoder)>=0 &&
                image.Save((test_dir/"frf_panel.png").c_str(),&encoder,nullptr)==Gdiplus::Ok,"FRF control layout artifact");
        }
        DeleteObject(bmp); DeleteDC(dc); ReleaseDC(g.main,screen);
        // A control change schedules a new pair; polling accepts only its generation.
        require(!set_frf_channels({1},{1}) && g.frf.result.ok,"same-channel choice is rejected without discarding valid results");
        require(set_frf_channels({1},{0}) && set_frf_channels({0},{1}),"valid pair changes are accepted");
        require(g.frf.pending,"valid channel change runs FRF in the background");
        const auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(10);
        while(g.frf.pending && std::chrono::steady_clock::now()<deadline) {
            WndProc(g.main,WM_TIMER,2,0);
            if(g.frf.pending) std::this_thread::sleep_for(std::chrono::milliseconds(5));
        }
        require(g.frf.result.ok && !g.frf.pending,"main-window timer accepts the FRF worker result");
        SetWindowTextW(GetDlgItem(g.frf_panel,7120),L"128");
        SendMessageW(GetDlgItem(g.frf_panel,7120),WM_KEYDOWN,VK_RETURN,0);
        require(g.frf.options.segment_length==128 && g.frf.pending,
                "Enter in L applies the length and schedules FRF without a Calculate button");
        SendMessageW(GetDlgItem(g.frf_panel,7118),CB_SETCURSEL,0,0);
        SendMessageW(g.frf_panel,WM_COMMAND,MAKEWPARAM(7118,CBN_SELCHANGE),0);
        const auto h1_deadline=std::chrono::steady_clock::now()+std::chrono::seconds(10);
        while(g.frf.pending && std::chrono::steady_clock::now()<h1_deadline) {
            poll_frf_result();
            if(g.frf.pending) std::this_thread::sleep_for(std::chrono::milliseconds(5));
        }
        require(g.frf.result.ok && g.frf.result.options.estimator==lvm::FrfEstimator::H1 &&
                g.frf.result.common().segment_length==128 && g.frf.result.common().averages==7 && g.frf.result.common().overlap_samples==64,
                "panel switches to H1 with explicit L and recalculates actual averaging count");
        near(g.frf.result.common().coherence[2],1,"GUI H1 exposes coherence from the same FFT averages");
        near(lvm::frf_dynamic_coefficient(g.frf.result.common(),2),4,"H1 dynamic coefficient preserves known gain");
        wchar_t details[256]{};
        GetWindowTextW(GetDlgItem(g.frf_panel,7111),details,256);
        const std::wstring actual=details;
        require(actual.find(L"L=128")!=std::wstring::npos && actual.find(L"K=7")!=std::wstring::npos &&
                actual.find(L"Δf=8")!=std::wstring::npos && actual.find(L"overlap=50%")!=std::wstring::npos,
                "FRF panel reports actual L, K, delta f and overlap");
        const auto h1_csv=test_dir/"frf_h1.csv";
        require(save_frf_csv(h1_csv.wstring()),"H1 CSV saves");
        std::ifstream h1_file(h1_csv);
        const std::string h1_text((std::istreambuf_iterator<char>(h1_file)),{});
        require(h1_text.find("estimator=h1_welch")!=std::string::npos &&
                h1_text.find("segment_length=128")!=std::string::npos && h1_text.find("averages=7")!=std::string::npos &&
                h1_text.find("valid,coherence,coherence_valid")!=std::string::npos &&
                h1_text.find("dynamic_coefficient_scale=linear_abs_h")!=std::string::npos &&
                h1_text.find("reference_amplitude_scale=linear_one_sided")!=std::string::npos,
                "H1 CSV records estimator, actual parameters, linear KD, Reference amplitude, and coherence");
        require(save_png((test_dir/"frf_h1.png").wstring()),"H1 graph reuses PNG export");
        Gdiplus::GdiplusShutdown(token);
    }
    g.ds.frequency_axis=true;
    set_mode(AnalysisMode::FFT);
    set_mode(AnalysisMode::FRF);
    require(g.mode==AnalysisMode::FFT,"stored magnitude spectrum cannot enter FRF");
}

void frf_multi_channels() {
    std::vector<double> time,x,ref2,y1,y2,y3;
    for(int i=0;i<2048;++i) {
        time.push_back(i/1024.0+(i>=1024 ? 10 : 0));
        x.push_back(std::sin(2*std::acos(-1.0)*16*i/1024));
        ref2.push_back(3*x.back());
        y1.push_back((i>=512 && i<1536 ? 6 : 100)*x.back());
        y2.push_back(-2*x.back()); y3.push_back(10*x.back());
    }
    reset_document({"R1","R2","Y, one","Y two","Y three"},time,{x,ref2,y1,y2,y3});
    set_fft_window(time[512],time[1535]);
    g.visible={0,0,0,0,0};
    require(set_frf_channels({0,1},{2,3,4}),"multi Reference and Response selected independently of visibility");
    g.frf.options.segment_length=256;
    set_mode(AnalysisMode::FRF);
    require(g.frf.result.ok && g.frf.result.responses.size()==3 && g.frf.result.common().sample_count==1024,
            "all responses share the same selected rows");
    require(g.frf.result.common().gaps_ignored && g.frf.result.common().averages==7,"multi-channel batch preserves gaps ignored and Welch parameters");
    near(lvm::frf_dynamic_coefficient(g.frf.result.responses[0],4),3,"GUI averages Reference samples before H1");
    near(lvm::frf_dynamic_coefficient(g.frf.result.responses[1],4),1,"second GUI response has independent gain");
    near(lvm::frf_dynamic_coefficient(g.frf.result.responses[2],4),5,"third GUI response has independent gain");
    require(frf_curve_label(0)==L"Y, one / AVG(R1, R2)" && frf_curve_label(2)==L"Y three / AVG(R1, R2)","legend labels identify averaged reference and each response");
    const auto generation=g.frf.generation;
    require(!set_frf_channels({0,1},{1,2}) && !set_frf_channels({},{2}) && !set_frf_channels({0,0},{2}) &&
            !set_frf_channels({0},{9}) && g.frf.generation==generation,"invalid roles, empty lists, duplicates and indices cannot change selection");
    g.frf.apply_processing=true; g.channel_formulas[0]=L"3*x"; rebuild_formula_cache_from_state(); on_frf_processing_changed();
    near(lvm::frf_dynamic_coefficient(g.frf.result.responses[0],4),2,"each reference is processed before averaging");
    g.frf.apply_processing=false; invalidate_frf(); ensure_current_frf();
    require(set_frf_frequency_range(4,64),"multi-FRF has one frequency range");
    const auto csv_path=test_dir/"frf_multi.csv";
    require(save_frf_csv(csv_path.wstring()),"multi-FRF CSV export");
    std::ifstream csv(csv_path); const std::string csv_text((std::istreambuf_iterator<char>(csv)),{});
    require(csv_text.find("reference_average=arithmetic_samples")!=std::string::npos &&
            csv_text.find("reference_1_index=1")!=std::string::npos && csv_text.find("response_2_index=4")!=std::string::npos &&
            csv_text.find("response_index,response_name,frequency_hz")!=std::string::npos &&
            csv_text.find("2,\"Y, one\",")!=std::string::npos && csv_text.find("4,\"Y three\",")!=std::string::npos,
            "CSV contains all series and complete reference membership with quoted names");
    double low,high; frf_y_range(low,high);
    require(low==0 && high>5,"Auto Y starts at zero and includes every linear dynamic-coefficient curve");
    const RECT full_plot{70,72,900,560};
    const RECT coefficient_plot=frf_coefficient_plot_rect(full_plot);
    const RECT reference_plot=frf_reference_plot_rect(full_plot);
    require(coefficient_plot.bottom<reference_plot.top && reference_plot.bottom==full_plot.bottom,
            "averaged Reference uses a separate graph below KD");
    g.frf.reference_height_fraction=.5;
    const RECT balanced_coefficient_plot=frf_coefficient_plot_rect(full_plot);
    const RECT balanced_reference_plot=frf_reference_plot_rect(full_plot);
    require(std::abs((balanced_coefficient_plot.bottom-balanced_coefficient_plot.top)-
                     (balanced_reference_plot.bottom-balanced_reference_plot.top))<=30,
            "FRF divider allows KD and averaged Reference plots to have nearly equal heights");
    g.frf.reference_height_fraction=.25;
    const double reference_auto_max=frf_reference_y_max();
    g.frf.reference_auto_y=false; g.frf.reference_y_min=-reference_auto_max*.25; g.frf.reference_y_max=reference_auto_max*.5;
    double reference_low=0, reference_high=0;
    frf_reference_y_range(reference_low,reference_high);
    near(reference_low,-reference_auto_max*.25,"Reference graph can pan independently below zero");
    near(reference_high,reference_auto_max*.5,"Reference graph has an independent vertical scale");
    g.frf.show_reference_amplitude=false;
    require(frf_coefficient_plot_rect(full_plot).bottom==full_plot.bottom &&
            frf_reference_plot_rect(full_plot).top==full_plot.bottom,
            "Reference graph can be hidden without changing KD data");
    g.frf.show_reference_amplitude=true; g.frf.reference_auto_y=true;
    const SettingsSnapshot before_symbols=capture_settings_snapshot();
    g.distinguish_curves=true;
    require(record_settings_change(before_symbols),"grayscale curve symbols participate in settings history");
    pop_undo();
    require(!g.distinguish_curves,"curve-symbol mode is undoable");
    pop_redo();
    require(g.distinguish_curves,"curve-symbol mode is redoable");
    Gdiplus::GdiplusStartupInput startup; ULONG_PTR token=0;
    require(Gdiplus::GdiplusStartup(&token,&startup,nullptr)==Gdiplus::Ok,"multi-FRF PNG startup");
    struct Window {
        HWND hwnd=CreateWindowExW(0,L"STATIC",L"Multi FRF",WS_POPUP|WS_CLIPCHILDREN,0,0,1100,650,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
        ~Window() { g.main=nullptr; if(hwnd) DestroyWindow(hwnd); }
    } window;
    require(window.hwnd!=nullptr,"multi-FRF hidden rendering window");
    g.main=window.hwnd; g.ui_font=reinterpret_cast<HFONT>(GetStockObject(DEFAULT_GUI_FONT)); update_theme_brushes();
    create_frf_panel(g.main,GetModuleHandleW(nullptr)); layout();
    require(save_png((test_dir/"frf_multi.png").wstring()),"all FRF curves export to one PNG");
    require(g_legend_items.empty(),"FRF plot omits the overlay legend");
    require(channel_color(2)!=channel_color(3) && channel_color(3)!=channel_color(4),"responses have distinct colors");
    Gdiplus::GdiplusShutdown(token);
    g.main=nullptr;
    g.ds.channels[2][700]=std::nan(""); invalidate_frf(); ensure_current_frf();
    require(g.frf.result.ok && !g.frf.result.responses[0].ok && g.frf.result.responses[1].ok,
            "one failed response does not hide the other GUI curves");
    require(frf_status_text().find(L"Y, one")!=std::wstring::npos,"partial batch error identifies the failed response");
    require(save_frf_csv((test_dir/"frf_multi_partial.csv").wstring()),"partial batch exports valid curves and error metadata");
}

void frf_gap_stitching() {
    std::vector<double> t, x, y;
    for (int i=0;i<1024;++i) {
        t.push_back(i/1024.0 + (i>=512 ? 10 : 0));
        x.push_back(std::sin(2*std::acos(-1.0)*16*i/1024));
        y.push_back(2*x.back());
    }
    reset_document({"Input","Output"},t,{x,y});
    require(set_frf_channels({0},{1}),"FRF gap test selects both channel roles");
    set_fft_window(t[256],t[767]);
    g.frf.options.segment_length=512;
    set_mode(AnalysisMode::FRF);
    require(g.frf.result.ok && g.frf.result.common().gaps_ignored && !g.stitch_time_gaps,"FRF ignores gaps even when display stitching is disabled");
    require(frf_status_text().find(L"Gaps ignored")!=std::wstring::npos,"FRF status warns about ignored gaps");
    const auto generation=g.frf.generation;
    const auto transfer=g.frf.result.common().transfer;
    struct Window {
        HWND hwnd=CreateWindowExW(0,L"STATIC",L"Settings test",WS_POPUP,0,0,400,400,
                                  nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
        ~Window() { g_frf_worker.cancel(); g.main=nullptr; if(hwnd) DestroyWindow(hwnd); }
    } window;
    require(window.hwnd!=nullptr,"hidden settings test window");
    g.main=window.hwnd;
    HWND toggle=CreateWindowExW(0,L"BUTTON",L"Stitch",WS_CHILD|BS_OWNERDRAW,0,0,100,25,
        window.hwnd,reinterpret_cast<HMENU>(IDC_SIDE_STITCH_GAPS),GetModuleHandleW(nullptr),nullptr);
    g.side_stitch_gaps=toggle;
    require(toggle!=nullptr && is_side_toggle_id(IDC_SIDE_STITCH_GAPS),"time stitching control belongs to Channels");
    const auto click = [&] {
        handle_commands_message(window.hwnd,WM_COMMAND,MAKEWPARAM(IDC_SIDE_STITCH_GAPS,BN_CLICKED),
                     reinterpret_cast<LPARAM>(toggle));
    };
    click();
    require(g.stitch_time_gaps && g.frf.result.ok && g.frf.result.common().gaps_ignored &&
            g.frf.result.common().sample_count==512,"display stitching toggle preserves the FRF pair");
    require(g.frf.result.common().segment_length==512 && g.frf.result.common().averages==1,"GUI H1 allows L larger than each 256-sample fragment");
    near(g.frf.result.common().frequencies[8],16,"FRF with ignored gaps retains physical frequency scale");
    near(lvm::frf_dynamic_coefficient(g.frf.result.common(),8),2,"FRF gain with ignored gaps");
    require(g.ds.time==t && g.frf.result.common().source_start==t[256] && g.frf.result.common().source_end==t[767],
            "GUI stitching preserves raw selection coordinates");
    const auto path=test_dir/"frf_stitched.csv";
    require(save_frf_csv(path.wstring()),"stitched FRF exports CSV");
    std::ifstream csv(path);
    const std::string text((std::istreambuf_iterator<char>(csv)),{});
    require(text.find("gap_policy=ignore_gaps_uniform_sample_sequence")!=std::string::npos && text.find("gaps_ignored=1")!=std::string::npos &&
            text.find("resampled=0")!=std::string::npos,"CSV records ignored gaps without interpolation");
    click();
    require(!g.stitch_time_gaps && g.frf.result.ok && !g.frf.pending,"disabling display stitching keeps FRF available");
    click(); click();
    require(g.frf.generation==generation && g.frf.result.common().transfer==transfer,"display stitching does not recalculate or change FRF");
    g.side_stitch_gaps=nullptr;g.main=nullptr;
    g.stitch_time_gaps=true;
    require(ensure_current_frf() && g.frf.generation==generation,"FRF cache is independent of display stitching");
    g.frf.options.segment_length=1024;
    require(!ensure_current_frf() && g.frf.result.error==lvm::FrfError::TooShort,"GUI reports insufficient selected samples for L");
}

void frf_loaded_document_defaults() {
    reset_document({"Old support","Old response"},{0,1,2,3},{{1,2,3,4},{4,3,2,1}});
    g.frf.inputs={0}; g.frf.outputs={1};
    lvm::Dataset loaded;
    loaded.ok=true;
    loaded.names={"Loaded support","Loaded response"};
    loaded.time={0,1,2,3}; loaded.raw_time=loaded.time;
    loaded.channels={{1,0,-1,0},{2,0,-2,0}};
    apply_loaded_dataset(std::move(loaded),L"loaded.lvm",false,0,false);
    require(g.frf.inputs.empty() && g.frf.outputs.empty(),
        "opening a file clears preselected FRF channel roles");
    require(set_frf_channels({0},{1}),"FRF clear test selects both roles");
    clear_frf_channel_selection(true);
    require(g.frf.inputs.empty() && g.frf.outputs==std::vector<int>{1},
        "FRF Clear removes only the selected role");
}

void reopen_spectrum() {
    const auto path = test_dir / "recovered_fft.csv";
    const auto original = lvm::read_lvm_file(path);
    require(original.ok && original.frequency_axis, "Frequency column identifies an exported spectrum");
    reopen(path, true);
    set_mode(AnalysisMode::FFT);
    require(g.spec_valid && g.spec.imported && g.spec.freqs == original.time && g.spec.amp == original.channels,
            "opening spectrum preserves all bins and amplitudes without a second FFT");
    near(g.spec.source_start, 0, "reopened spectrum preserves source interval");
    require(g.spec.resampled && g.spec.gaps_ignored, "reopened spectrum preserves sampling provenance");
    set_mode(AnalysisMode::Time);
    require((g.mode == AnalysisMode::FFT) && current_filter_nyquist() == 0, "stored spectrum cannot enter time mode or use a time-domain filter");
    ExportOptions opts; opts.include_hidden_channels = true; opts.selected_range = ExportRangeMode::Whole;
    const auto second_path = test_dir / "spectrum_second_roundtrip.csv";
    require(save_tabular_export(second_path.wstring(), opts), "stored spectrum exports again");
    const auto second = lvm::read_lvm_file(second_path);
    require(second.ok && second.frequency_axis && second.time == original.time && second.channels == original.channels,
            "repeated spectrum export preserves exact numeric values");
    reset_document({"signal"},{0,.1,.2,.3,.4,.5,.6,.7},{{1,0,-1,0,1,0,-1,0}});
    g.global_formula = L"3*x"; rebuild_formula_cache_from_state(); set_mode(AnalysisMode::FFT);
    opts.apply_processing_to_data = false;
    require(save_tabular_export(second_path.wstring(), opts), "raw spectrum export stores processing recipe");
    reopen(second_path); set_mode(AnalysisMode::FFT);
    require(g.spec_valid && g.spec.imported, "raw spectrum reopens directly");
    const auto peaks = lvm::find_peaks(g.spec.freqs, g.spec.amp[0], 1);
    require(!peaks.empty(), "reopened raw spectrum retains peak");
    near(peaks[0].amp, 1, "time-domain recipe is never reapplied to imported FFT amplitudes");
}

void save_hotkeys() {
    const auto bindings = default_hotkeys();
    auto find = [&](int command) -> const HotkeyBinding* {
        for (const auto& binding : bindings) if (binding.command == command) return &binding;
        return nullptr;
    };
    const auto* project = find(IDC_SAVE_PROJECT);
    const auto* save_as = find(IDC_SAVECSV);
    const auto* png = find(IDC_SAVEPNG);
    require(find(IDM_MODE_FRF) && find(IDM_MODE_FRF)->key=='R' && find(IDM_MODE_FRF)->fvirt==FVIRTKEY,
            "FRF defaults to plain R");
    require(find(IDM_MODE_TIME) && find(IDM_MODE_TIME)->key=='S' && find(IDM_MODE_TIME)->fvirt==FVIRTKEY,
            "Signal defaults to plain S");
    require(find(IDM_MODE_FREQ) && find(IDM_MODE_FREQ)->key=='F' && find(IDM_MODE_FREQ)->fvirt==FVIRTKEY,
            "FFT keeps plain F");
    require(project && project->fvirt == (FVIRTKEY | FCONTROL) && project->key == 'S',
            "Ctrl+S saves the project");
    require(save_as && save_as->fvirt == (FVIRTKEY | FCONTROL | FSHIFT) && save_as->key == 'S',
            "Ctrl+Shift+S opens Save as");
    require(png && png->fvirt == (FVIRTKEY | FCONTROL | FALT) && png->key == 'S',
            "Ctrl+Alt+S saves PNG");
}

LRESULT CALLBACK shortcut_test_proc(HWND hwnd,UINT message,WPARAM wp,LPARAM lp,UINT_PTR,DWORD_PTR) {
    if(message==WM_COMMAND)return WndProc(hwnd,message,wp,lp);
    return DefSubclassProc(hwnd,message,wp,lp);
}
void additional_mode_hotkeys() {
    reset_document({"A"},{0,.01,.02,.03},{{1,2,3,4}});
    const auto defaults=default_hotkeys();const auto order=hotkey_command_order();
    std::set<int> commands;
    std::set<std::pair<BYTE,WORD>> shortcuts;
    for(const auto& a:defaults) {
        require(a.key!=0 && std::count(order.begin(),order.end(),a.command)==1,"every default is listed once in shortcut settings");
        commands.insert(a.command);
        shortcuts.emplace(a.fvirt,a.key);
    }
    require(commands.size()==defaults.size(),"default shortcut command IDs are unique");
    require(shortcuts.size()==defaults.size(),"default key and modifier combinations are unique");
    g.hotkeys=defaults;
    for(const auto* language:{&kRu,&kEn}) {
        g_str=language;const auto help=hotkeys_body_text();
        for(const auto& binding:defaults)require(command_name(binding.command)!=L"?" && help.find(command_name(binding.command))!=std::wstring::npos,
            "default shortcuts have localized settings and help entries");
    }
    g_str=&kEn;HACCEL accel=make_accelerators();
    const int count=CopyAcceleratorTableW(accel,nullptr,0);std::vector<ACCEL> table(count);
    CopyAcceleratorTableW(accel,table.data(),count);DestroyAcceleratorTable(accel);
    require(count==static_cast<int>(defaults.size()),"native accelerator table includes every default");
    for(const auto& binding:defaults)require(std::count_if(table.begin(),table.end(),[&](const ACCEL& a){
        return a.cmd==binding.command && a.key==binding.key && (a.fVirt&~FNOINVERT)==binding.fvirt;})==1,
        "native accelerator preserves its command and modifiers");
    g.hotkeys={{IDM_MODE_TIME,FVIRTKEY,'T'}};ensure_hotkeys_initialized();
    require(find_hotkey_binding(IDM_MODE_TIME)->key=='S',"old Signal default migrates to S");
    g.hotkeys={{IDM_MODE_TIME,FVIRTKEY,'T'},{IDC_CURSOR_TOOL,FVIRTKEY,'S'}};ensure_hotkeys_initialized();
    require(find_hotkey_binding(IDM_MODE_TIME)->key=='T' && find_hotkey_binding(IDC_CURSOR_TOOL)->key=='S',
        "Signal migration preserves an existing custom S assignment");
    g.hotkeys={{IDM_MODE_FRF,FVIRTKEY|FCONTROL,'R'}};ensure_hotkeys_initialized();
    require(find_hotkey_binding(IDM_MODE_FRF)->fvirt==FVIRTKEY,"old FRF default migrates to plain R");
    g.hotkeys={{IDM_MODE_FRF,FVIRTKEY|FCONTROL,'R'},{IDC_CURSOR_TOOL,FVIRTKEY,'R'}};ensure_hotkeys_initialized();
    require(find_hotkey_binding(IDM_MODE_FRF)->fvirt==(FVIRTKEY|FCONTROL) && find_hotkey_binding(IDC_CURSOR_TOOL)->key=='R',
        "FRF migration preserves an existing custom R assignment");
    g.hotkeys={{IDM_MODE_TIME,FVIRTKEY,'G'},{IDC_CURSOR_TOOL,FVIRTKEY,0}};ensure_hotkeys_initialized();
    require(find_hotkey_binding(IDC_MAGNET_TOOL)->key==0 && find_hotkey_binding(IDM_MODE_TIME)->key=='G',"new defaults do not steal custom assignments");
    require(find_hotkey_binding(IDC_CURSOR_TOOL)->key==0 && find_hotkey_binding(IDC_LOCK_ANNOTATIONS)->key=='L',"migration preserves disabled commands and adds free defaults");
    const auto config_before=g_config_path;g_config_path=(test_dir/"new-mode-hotkeys.ini").wstring();
    save_runtime_settings_now();g.hotkeys.clear();load_runtime_settings();
    require(find_hotkey_binding(IDC_MAGNET_TOOL)->key==0 && find_hotkey_binding(IDC_CURSOR_TOOL)->key==0 &&
        find_hotkey_binding(IDM_MODE_TIME)->key=='G',"custom and disabled shortcuts survive INI reload");
    WritePrivateProfileStringW(L"hotkeys",nullptr,nullptr,g_config_path.c_str());
    WritePrivateProfileStringW(L"hotkeys",L"cmd_1700",L"1,71",g_config_path.c_str());load_runtime_settings();
    require(find_hotkey_binding(IDM_MODE_TIME)->key=='G' && find_hotkey_binding(IDC_MAGNET_TOOL)->key==0 &&
        find_hotkey_binding(IDC_CURSOR_TOOL)->key=='N',"old INI custom assignments take precedence over new defaults");
    g_config_path=config_before;g.hotkeys=defaults;
    struct Window {
        HWND hwnd=CreateWindowExW(0,L"STATIC",L"Mode shortcuts",WS_POPUP,0,0,980,650,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
        ~Window(){g.main=nullptr;if(hwnd)DestroyWindow(hwnd);}
    } window;
    require(window.hwnd!=nullptr,"mode shortcut test window");g.main=window.hwnd;SetWindowSubclass(g.main,shortcut_test_proc,1,0);
    const auto invoke=[&](int command){SendMessageW(g.main,WM_COMMAND,MAKEWPARAM(command,1),0);};
    g.measure_mode=true;g.pending_line=1;g.pending_marker=true;invoke(IDC_CURSOR_TOOL);
    require(!g.measure_mode && !g.pending_line && !g.pending_marker,"cursor accelerator restores navigation");
    const bool snap=g.snap_to_data;invoke(IDC_MAGNET_TOOL);require(g.snap_to_data!=snap,"magnet accelerator toggles snapping");
    invoke(IDC_LOCK_ANNOTATIONS);require(g.annotations_locked,"lock accelerator locks annotations");
    invoke(IDC_LOCK_ANNOTATIONS);require(!g.annotations_locked,"lock accelerator unlocks annotations");
    for(int tab=0;tab<3;++tab) {g.side_panel_visible=false;invoke(IDC_SIDE_TAB_CHANNELS+tab);
        require(g.side_panel_visible && g.side_panel_tab==tab,"panel accelerator reveals the requested hidden tab");}
    invoke(IDC_SIDEPANEL);require(!g.side_panel_visible,"panel accelerator hides the panel");
    const bool filter=g.noise_threshold_enabled;invoke(IDC_SIDE_FILTER_ENABLE);
    require(g.noise_threshold_enabled!=filter,"filter accelerator toggles state without a checkbox HWND");
    invoke(IDC_SIDE_FILTER_ENABLE);require(g.noise_threshold_enabled==filter,"filter accelerator restores its state");
    const bool stitch=g.stitch_time_gaps;invoke(IDC_SIDE_STITCH_GAPS);require(g.stitch_time_gaps!=stitch,"gap accelerator toggles hidden gaps");
    const bool values=g.show_marker_values;invoke(IDM_MARKER_VALUES);require(g.show_marker_values!=values,"marker accelerator toggles readouts");
    const bool legend=g.show_channel_legend;invoke(IDM_CHANNEL_LEGEND);require(g.show_channel_legend!=legend,"legend accelerator toggles legend");
    const bool symbols=g.distinguish_curves;invoke(IDM_CURVE_SYMBOLS);require(g.distinguish_curves!=symbols,"symbol accelerator toggles curve symbols");
    g.win_start=.01;g.win_end=.02;invoke(IDM_ANALYSIS_VISIBLE);require(has_fft_window(),"analysis accelerator selects the visible interval");
    near(g.fft_window_start,.01,"visible analysis interval lower bound");near(g.fft_window_end,.02,"visible analysis interval upper bound");
    invoke(IDM_ANALYSIS_ENTIRE);require(!has_fft_window(),"entire-recording accelerator clears the analysis selection");
}

void channel_coefficient_fields() {
    reset_document({"A", "B"}, {0, 1}, {{1, 2}, {3, 4}});
    g.channel_formulas = {L"2.5*x", L"x+7"};
    rebuild_formula_cache_from_state();
    require(channel_coefficient_text(0) == L"2.5", "multiplier field shows the channel coefficient");
    require(channel_coefficient_text(1).empty(), "non-multiplicative legacy formula does not pretend to be a coefficient");
}

void point_display_defaults() {
    reset_document({"A"}, {0, 1}, {{1, 2}});
    g.pdisp = {false, true, false, true, false, true, true};
    clear_all_measure_point_groups();
    const int index = create_point_group(g.marker_color);
    require(index == 0, "first point group is created from point display defaults");
    const PointDisplay& display = g.point_groups[0].display;
    require(!display.number && display.x && !display.y && display.dx && !display.dy && display.inv_dt && display.dist,
            "first point group inherits display choices set before any point exists");
}

void status_bar_text() {
    reset_document({"A"}, {0, 1}, {{1, 2}});
    g.mode = AnalysisMode::Time;
    g.auto_y = true;
    set_status();
    require(g.status_text.find(L"Signal: 1 channels, 2 samples, 0–1 s | Y scale: auto") != std::wstring::npos,
            "time status uses a separated, correctly named Y-scale segment");
    require(g.status_tooltip_text == g.status_text,
            "status tooltip retains the complete untruncated status text");
}

void mode_button_text() {
    g_str = &kEn;
    require(std::wstring(mode_time_text()) == L"Signal" && std::wstring(mode_spectrum_text()) == L"Spectrum" &&
                std::wstring(mode_frf_text()) == L"FRF",
            "English mode buttons use compact labels rather than status format templates");
    g_str = &kRu;
    require(std::wstring(mode_time_text()) == L"Сигнал" && std::wstring(mode_spectrum_text()) == L"Спектр" &&
                std::wstring(mode_frf_text()) == L"АЧХ",
            "Russian mode buttons use compact labels rather than status format templates");
    g_str = &kEn;
}

LRESULT CALLBACK frequency_test_proc(HWND hwnd,UINT message,WPARAM wp,LPARAM lp,UINT_PTR,DWORD_PTR) {
    if(message==WM_COMMAND && handle_frequency_view_command(hwnd,wp))return 0;
    return DefSubclassProc(hwnd,message,wp,lp);
}
void frequency_view_controls() {
    std::vector<double> t,x,y;
    for(int i=0;i<256;++i) {t.push_back(i/256.0);x.push_back(std::sin(2*std::acos(-1.0)*16*t.back()));y.push_back(2*x.back());}
    reset_document({"Reference","Response"},t,{x,y});
    compute_spectrum_for_window(t.front(),t.back(),false);g.mode=AnalysisMode::FFT;
    require(g.spec_valid && g.spec.ok,"frequency view fixture has a real spectrum");
    g.freq_start=0;g.freq_end=g.spec.nyquist;
    struct Window {
        HWND hwnd=CreateWindowExW(0,L"STATIC",L"Frequency view",WS_POPUP,0,0,980,650,
            nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
        ~Window(){g.main=nullptr;if(hwnd)DestroyWindow(hwnd);}
    } window;
    require(window.hwnd!=nullptr,"frequency view test window");
    g.main=window.hwnd;g.side_panel_visible=true;
    g.ui_font=reinterpret_cast<HFONT>(GetStockObject(DEFAULT_GUI_FONT));
    SetWindowSubclass(g.main,frequency_test_proc,1,0);
    create_frequency_view_controls(g.main,GetModuleHandleW(nullptr));
    create_frf_panel(g.main,GetModuleHandleW(nullptr));
    const auto shown=[](HWND h){return (GetWindowLongPtrW(h,GWL_STYLE)&WS_VISIBLE)!=0;};
    const auto label=[](HWND h){wchar_t value[160]{};GetWindowTextW(h,value,160);return std::wstring(value);};
    const auto generation=g.spec_generation,revision=g.numerical_revision;
    const auto bins=g.spec.bin_count();
    for(int tab:{0,1}) {
        set_side_panel_tab(tab);layout();
        g.side_scroll_y=g.side_scroll_max;layout();
        require(shown(g.side_frequency_apply)==(tab==0) && IsWindowEnabled(g.side_frequency_apply),"spectrum range is available only on Channels");
    }
    set_side_panel_tab(0);
    require(!(GetWindowLongPtrW(g.side_frequency_low,GWL_EXSTYLE)&WS_EX_CLIENTEDGE),"frequency edits use the application's compact border");
    SetWindowTextW(g.side_frequency_low,L"8");SetWindowTextW(g.side_frequency_high,L"64");
    g.freq_start=2;set_status();
    require(label(g.side_frequency_low)==L"8","status refresh preserves a pending frequency edit");
    SendMessageW(g.side_frequency_low,WM_KEYDOWN,VK_RETURN,0);
    near(g.freq_start,8,"Enter applies spectrum view start");near(g.freq_end,64,"Enter applies spectrum view end");
    require(g.spec_generation==generation && g.numerical_revision==revision && g.spec.bin_count()==bins && g_undo.empty(),
        "view range leaves FFT data, numerical revision and annotation history unchanged");
    require(!set_visible_frequency_range(64,8) && !set_visible_frequency_range(-1,64) && !set_visible_frequency_range(0,1000) &&
        !set_visible_frequency_range(0,std::numeric_limits<double>::quiet_NaN()),"spectrum view rejects reversed, unavailable and nonfinite ranges");
    require(set_visible_frequency_range(0,128),"spectrum view includes DC and Nyquist");
    g.spec_pending=true;sync_frequency_view_controls();
    require(!IsWindowEnabled(g.side_frequency_apply) && !set_visible_frequency_range(8,64),"pending spectrum cannot change a stale range");
    g.spec_pending=false;
    set_side_panel_tab(2);layout();require(!shown(g.side_frequency_apply),"Filter hides the frequency view block");
    g.mode=AnalysisMode::Time;set_side_panel_tab(0);g.side_scroll_y=g.side_scroll_max;layout();
    require(shown(g.side_frequency_apply) && label(g.side_frequency_low_label)==L"From, s","Signal uses the same bottom block with time units");
    const auto time_generation=g.spec_generation,time_revision=g.numerical_revision;
    const bool selected_before=has_fft_window();g.stitch_time_gaps=true;
    SetWindowTextW(g.side_frequency_low,L"0.1");SetWindowTextW(g.side_frequency_high,L"0.8");
    SendMessageW(g.side_frequency_high,WM_KEYDOWN,VK_RETURN,0);
    near(g.win_start,.1,"Signal view accepts the original-time lower endpoint");near(g.win_end,.8,"Signal view accepts the original-time upper endpoint");
    require(g.spec_generation==time_generation && g.numerical_revision==time_revision && has_fft_window()==selected_before && g_undo.empty(),
        "Signal viewport changes preserve analysis selection, computed data and history");
    require(!set_visible_frequency_range(-1,.8) && !set_visible_frequency_range(.1,2),"Signal view rejects endpoints outside the recording");
    g.stitch_time_gaps=false;
    require(set_frf_channels({0},{1}),"frequency view selects real FRF roles");
    // A real main HWND selects the asynchronous worker path; prepare this small fixture synchronously.
    g.frf.options.estimator=lvm::FrfEstimator::Direct;g.main=nullptr;set_mode(AnalysisMode::FRF);g.main=window.hwnd;
    require(g.frf.result.ok,"frequency view fixture has a real FRF");
    const auto frf_generation=g.frf.generation;const auto transfer=g.frf.result.common().transfer;
    set_side_panel_tab(0);layout();
    g.side_scroll_y=g.side_scroll_max;layout();
    require(shown(g.side_frequency_apply) && shown(g.frf_panel),"FRF Channels exposes the range below its calculation panel");
    SetWindowTextW(g.side_frequency_low,L"4");SetWindowTextW(g.side_frequency_high,L"32");
    SendMessageW(g.side_frequency_apply,BM_CLICK,0,0);
    near(g.frf.frequency_start,4,"Channels changes the shared FRF view start");near(g.frf.frequency_end,32,"Channels changes the shared FRF view end");
    require(g.frf.generation==frf_generation && g.frf.result.common().transfer==transfer,"FRF view range preserves calculated transfer values");
    require(!set_visible_frequency_range(0,32),"FRF range preserves the non-DC lower limit");
    for(const Strings* language:{&kRu,&kEn}) {
        g_str=language;refresh_frf_controls();set_side_panel_tab(0);layout();g.side_scroll_y=g.side_scroll_max;layout();
        require(shown(g.frf_panel) && shown(g.side_frequency_apply),"FRF Channels uses the same bottom range block");
        require(!GetDlgItem(g.frf_panel,7110) && label(g.side_frequency_apply)==frequency_view_apply_text(),"FRF has no duplicate native range controls");
        require(label(g.side_frequency_title)==(language==&kRu ? L"Видимый диапазон" : L"Visible range"),"common range heading is localized");
    }
    for(AnalysisMode mode:{AnalysisMode::Time,AnalysisMode::FFT,AnalysisMode::FRF}) {
        g.mode=mode;set_side_panel_tab(1);g.side_scroll_y=g.side_scroll_max;refresh_side_panel_controls();
        for(HWND control:g.side_frequency_controls)require(!shown(control),"Points hides the entire range block in every mode, including after scroll/refresh");
    }
    g.side_panel_visible=false;layout();
    require(!shown(g.side_frequency_apply),"hiding the side panel hides the common range controls");
    g_str=&kEn;
}

LRESULT CALLBACK channel_panel_test_proc(HWND hwnd,UINT message,WPARAM wp,LPARAM lp) {
    if(message==WM_NCCREATE)g.main=hwnd;
    // Keep production creation/painting, but avoid exit persistence and WM_QUIT in this fixture.
    if(message==WM_DESTROY) {KillTimer(hwnd,2);KillTimer(hwnd,3);return 0;}
    return WndProc(hwnd,message,wp,lp);
}
LRESULT CALLBACK observe_track_paint(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp,UINT_PTR,DWORD_PTR data) {
    if(msg==WM_PAINT)++*reinterpret_cast<int*>(data);
    return DefSubclassProc(hwnd,msg,wp,lp);
}
void verify_filter_slider_paint(HWND window) {
    Gdiplus::GdiplusStartupInput startup;ULONG_PTR token=0;
    require(Gdiplus::GdiplusStartup(&token,&startup,nullptr)==Gdiplus::Ok,"GDI+ starts for complete filter slider paint checks");
    RECT owner_rect{};GetWindowRect(window,&owner_rect);const bool owner_visible=IsWindowVisible(window)!=FALSE;
    SetWindowPos(window,nullptr,-16000,-16000,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);
    ShowWindow(window,SW_SHOWNOACTIVATE);
    HDC dc=CreateCompatibleDC(nullptr);BITMAPINFO info{};info.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
    info.bmiHeader.biWidth=320;info.bmiHeader.biHeight=-24;info.bmiHeader.biPlanes=1;info.bmiHeader.biBitCount=32;info.bmiHeader.biCompression=BI_RGB;
    void* pixels=nullptr;HBITMAP bitmap=CreateDIBSection(dc,&info,DIB_RGB_COLORS,&pixels,nullptr,0);const auto old=SelectObject(dc,bitmap);
    const auto theme_before=g_theme;
    set_side_panel_tab(2);g.noise_threshold_enabled=true;
    for(const auto* theme:{&kLightTheme,&kDarkTheme}) {
        g_theme=theme;update_theme_brushes();
        for(int mode:{FilterModeLowPass,FilterModeHighPass,FilterModeBandPass,FilterModeBandStop}) {
            SendMessageW(g.side_filter_mode,CB_SETCURSEL,mode,0);
            WndProc(window,WM_COMMAND,MAKEWPARAM(IDC_SIDE_FILTER_MODE,CBN_SELCHANGE),reinterpret_cast<LPARAM>(g.side_filter_mode));
            for(int position:{0,310,1000,680})for(HWND track:{g.side_filter_low_track,g.side_filter_high_track}) {
                SendMessageW(track,TBM_SETPOS,TRUE,position);
                WndProc(window,WM_HSCROLL,MAKEWPARAM(TB_THUMBPOSITION,position),reinterpret_cast<LPARAM>(track));
                refresh_side_panel_controls();
                require((GetWindowLongPtrW(track,GWL_STYLE)&WS_VISIBLE)!=0,"filter track remains visible after cutoff commit and panel refresh");
                RECT rail{},thumb{};SendMessageW(track,TBM_GETCHANNELRECT,0,reinterpret_cast<LPARAM>(&rail));
                SendMessageW(track,TBM_GETTHUMBRECT,0,reinterpret_cast<LPARAM>(&thumb));
                const int center=(thumb.top+thumb.bottom)/2;
                const int x=(thumb.left+thumb.right)<(rail.left+rail.right) ? (thumb.right+rail.right)/2 : (rail.left+thumb.left)/2;
                RECT canvas{0,0,320,24};FillRect(dc,&canvas,g_panel_brush);
                NMCUSTOMDRAW draw{};draw.hdr.hwndFrom=track;draw.hdr.code=NM_CUSTOMDRAW;draw.hdc=dc;draw.dwDrawStage=CDDS_PREPAINT;
                require(draw_themed_trackbar(draw)==CDRF_SKIPDEFAULT,"one prepaint stage paints the entire slider without native cached-item callbacks");
                GdiFlush();
                require(GetPixel(dc,x,center)!=theme->bg_panel && GetPixel(dc,(thumb.left+thumb.right)/2,thumb.top+1)!=theme->bg_panel,
                    "both channel and thumb survive each cutoff change in both themes");
                FillRect(dc,&canvas,g_panel_brush);
                SendMessageW(track,WM_PRINTCLIENT,reinterpret_cast<WPARAM>(dc),PRF_CLIENT|PRF_ERASEBKGND);GdiFlush();
                require(GetPixel(dc,x,center)!=theme->bg_panel,"native slider printing routes the complete themed channel after updates");
            }
            for(HWND track:{g.side_filter_low_track,g.side_filter_high_track}) {
                int paints=0;SetWindowSubclass(track,observe_track_paint,0x5041494e,reinterpret_cast<DWORD_PTR>(&paints));
                struct CaptureCleanup {HWND track;~CaptureCleanup(){
                    if(GetCapture()==track)ReleaseCapture();
                    RemoveWindowSubclass(track,observe_track_paint,0x5041494e);}
                } capture_cleanup{track};
                RECT thumb{},client{};SendMessageW(track,TBM_GETTHUMBRECT,0,reinterpret_cast<LPARAM>(&thumb));GetClientRect(track,&client);
                const auto revision=g.numerical_revision;const auto undo_count=g_undo.size();
                const double low=g.noise_threshold_min,high=g.noise_threshold_max;
                const int y=(thumb.top+thumb.bottom)/2;
                SendMessageW(track,WM_LBUTTONDOWN,MK_LBUTTON,MAKELPARAM((thumb.left+thumb.right)/2,y));
                require(GetCapture()==track,"native filter slider captures a held thumb drag");
                // Two round trips retain abrupt jumps, reversals and repeated
                // repainting while capture is held, without 16 redundant moves.
                for(int step=0;step<4;++step) {
                    const int before=paints;
                    const int x=step%2 ? 15+step : client.right-15-step;
                    SendMessageW(track,WM_MOUSEMOVE,MK_LBUTTON,MAKELPARAM(x,y));
                    require(GetCapture()==track && paints>before,"each abrupt held move finishes a synchronous slider paint before release");
                    require(g.noise_threshold_min==low && g.noise_threshold_max==high && g.numerical_revision==revision && g_undo.size()==undo_count,
                        "rapid held slider previews do not apply filtering or add history");
                    for(HWND displayed:{g.side_filter_low_track,g.side_filter_high_track}) {
                        RECT rail{},current{};SendMessageW(displayed,TBM_GETCHANNELRECT,0,reinterpret_cast<LPARAM>(&rail));
                        SendMessageW(displayed,TBM_GETTHUMBRECT,0,reinterpret_cast<LPARAM>(&current));
                        RECT canvas{0,0,320,24};FillRect(dc,&canvas,g_panel_brush);
                        SendMessageW(displayed,WM_PRINTCLIENT,reinterpret_cast<WPARAM>(dc),PRF_CLIENT);GdiFlush();
                        const int cy=(current.top+current.bottom)/2;
                        const COLORREF rail_color=GetPixel(dc,rail.right-5,cy);
                        bool clean=true;
                        for(int px=current.right+4;px<rail.right-4;++px)if(GetPixel(dc,px,cy)!=rail_color){clean=false;break;}
                        require(clean,"both sliders have a continuous unfilled rail without old blue segments while capture is held");
                    }
                }
                SendMessageW(track,WM_LBUTTONUP,0,MAKELPARAM(30,y));
                require(GetCapture()!=track,"native filter slider releases capture after the final move");
            }
        }
    }
    ShowWindow(window,owner_visible ? SW_SHOWNOACTIVATE : SW_HIDE);
    SetWindowPos(window,nullptr,owner_rect.left,owner_rect.top,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOREDRAW);
    g_theme=theme_before;update_theme_brushes();SelectObject(dc,old);DeleteObject(bitmap);DeleteDC(dc);Gdiplus::GdiplusShutdown(token);
}

void channel_panel_layout_regression() {
    reset_document({"X","Y","Z"},{0,.01,.02,.03},{{1,2,3,4},{2,3,4,5},{3,4,5,6}});
    compute_spectrum_for_window(0,.03,false);
    WNDCLASSW cls{};cls.lpfnWndProc=channel_panel_test_proc;cls.hInstance=GetModuleHandleW(nullptr);cls.lpszClassName=L"ChannelPanelRegression";
    RegisterClassW(&cls);
    struct Window {
        HWND hwnd=CreateWindowExW(0,L"ChannelPanelRegression",L"Channel panel regression",WS_POPUP|WS_CLIPCHILDREN,
            0,0,1000,650,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
        ~Window(){DestroyWindow(hwnd);release_backbuffer();
            for(HFONT font:{g.ui_font,g.menu_font,g.bold_font,g.title_font,g.axis_font})if(font)DeleteObject(font);
            g.main=nullptr;}
    } window;
    require(window.hwnd!=nullptr,"channel regression creates all production panel controls");
    rebuild_checks();g.side_panel_visible=true;g.side_panel_tab=0;
    const auto shown=[](HWND h){return h && (GetWindowLongPtrW(h,GWL_STYLE)&WS_VISIBLE)!=0;};
    const auto bounds=[&](HWND h){RECT r{};GetWindowRect(h,&r);MapWindowPoints(nullptr,window.hwnd,reinterpret_cast<POINT*>(&r),2);return r;};
    const auto validate=[&] {
        RECT client{};GetClientRect(window.hwnd,&client);
        std::vector<HWND> controls=g.side_channel_controls;
        controls.insert(controls.end(),g.side_frequency_controls.begin(),g.side_frequency_controls.end());
        controls.insert(controls.end(),g.checks.begin(),g.checks.end());controls.insert(controls.end(),g.check_labels.begin(),g.check_labels.end());
        controls.insert(controls.end(),g.channel_coefficient_edits.begin(),g.channel_coefficient_edits.end());
        std::vector<RECT> visible;
        for(HWND h:controls)if(shown(h)) {
            const RECT r=bounds(h);
            require(r.top>=kTopBar+78 && r.bottom<=client.bottom-kBottomBar-6,"visible Channels controls stay inside the scrolling viewport");
            for(const auto& other:visible){RECT intersection{};require(!IntersectRect(&intersection,&r,&other),"channel labels, frequency fields and formula controls never overlap");}
            visible.push_back(r);
        }
    };
    for(AnalysisMode mode:{AnalysisMode::FFT,AnalysisMode::Time,AnalysisMode::FFT}) {
        g.mode=mode;g.side_scroll_y=0;refresh_side_panel_controls();validate();
        require(bounds(g.side_frequency_title).top>bounds(g.side_channel_color).bottom,"visible range is below the channel list and channel settings in every mode");
        require(bounds(g.check_labels.front()).top>=bounds(g.side_channel_formula_label).bottom,"channel rows are below the formula heading");
        for(int offset:{17,g.side_scroll_max}) {
            scroll_side_panel(offset);validate();refresh_side_panel_controls();validate();
        }
    }
    // A shorter mode and a taller window both reduce the old scroll limit.
    g.mode=AnalysisMode::Time;refresh_side_panel_controls();validate();
    MoveWindow(window.hwnd,0,0,1000,420,FALSE);g.side_scroll_y=g.side_scroll_max;layout();refresh_side_panel_controls();validate();
    MoveWindow(window.hwnd,0,0,1000,850,FALSE);refresh_side_panel_controls();validate();
    g.mode=AnalysisMode::FRF;
    for(int height:{420,650,850}) {
        MoveWindow(window.hwnd,0,0,1000,height,FALSE);g.side_scroll_y=0;set_side_panel_tab(0);
        g.side_scroll_y=g.side_scroll_max;layout();
        require(shown(g.side_frequency_apply),"FRF bottom range remains reachable at every window height");
        const RECT range=bounds(g.side_frequency_title),frf=bounds(g.frf_panel),apply=bounds(g.side_frequency_apply);
        require(range.top>=frf.bottom+12 && apply.bottom<=height-kBottomBar-6,"FRF settings and common bottom range never overlap");
        HRGN clip=CreateRectRgn(0,0,0,0);RECT region{};
        require(GetWindowRgn(g.frf_panel,clip)!=ERROR && GetRgnBox(clip,&region)!=ERROR && frf.top+region.top>=kTopBar+44,
            "scrolling FRF clips its native settings below the tabs");DeleteObject(clip);
    }
    g.mode=AnalysisMode::Time;g.side_scroll_y=0;refresh_side_panel_controls();
    verify_filter_slider_paint(window.hwnd);
    for(int tab:{1,2}) {set_side_panel_tab(tab);for(HWND h:g.side_channel_controls)require(!shown(h),"other tabs hide channel controls");}
    set_side_panel_tab(0);g.side_panel_visible=false;refresh_side_panel_controls();
    for(HWND h:g.side_channel_controls)require(!shown(h),"hidden panel does not expose channel controls during refresh");
}

void frf_filter_tab() {
    reset_document({"Reference", "Response"}, {0, .01, .02, .03}, {{1,2,3,4},{2,4,6,8}});
    struct Window {
        HWND hwnd=CreateWindowExW(0,L"STATIC",L"FRF tabs",WS_POPUP|WS_CLIPCHILDREN,
            0,0,980,500,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
        ~Window() { g.main=nullptr; if(hwnd) DestroyWindow(hwnd); }
    } window;
    require(window.hwnd!=nullptr,"FRF filter tab test window");
    g.main=window.hwnd;
    g.side_panel_visible=true;
    g.ui_font=reinterpret_cast<HFONT>(GetStockObject(DEFAULT_GUI_FONT));
    const auto child=[&](const wchar_t* cls,int id) {
        return CreateWindowExW(0,cls,L"",WS_CHILD,0,0,10,10,g.main,
            reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),GetModuleHandleW(nullptr),nullptr);
    };
    g.side_tab_channels=child(L"BUTTON",IDC_SIDE_TAB_CHANNELS);
    g.side_tab_points=child(L"BUTTON",IDC_SIDE_TAB_POINTS);
    g.side_tab_filter=child(L"BUTTON",IDC_SIDE_TAB_FILTER);
    g.side_filter_enable=child(L"BUTTON",IDC_SIDE_FILTER_ENABLE);
    g.side_filter_controls.push_back(g.side_filter_enable);
    HWND point_control=child(L"STATIC",IDC_SIDE_PT_NUM);
    g.side_point_controls.push_back(point_control);
    create_frf_panel(g.main,GetModuleHandleW(nullptr));
    const auto shown=[](HWND h) { return (GetWindowLongPtrW(h,GWL_STYLE)&WS_VISIBLE)!=0; };
    // No roles are selected, so changing modes/settings does not launch a worker.
    g.side_panel_visible=false;
    g.side_panel_tab=2;
    set_mode(AnalysisMode::FRF);
    require(g.side_panel_visible && g.side_panel_tab==0 && shown(g.frf_panel),
        "FRF opens Channels when channel roles have not been selected");
    WndProc(g.main,WM_COMMAND,IDC_SIDE_TAB_FILTER,0);
    require(shown(g.side_filter_enable) && !shown(g.frf_panel),"filter tab shows document controls without the FRF panel");
    RECT channels{},points{},filter{};
    GetWindowRect(g.side_tab_channels,&channels); GetWindowRect(g.side_tab_points,&points); GetWindowRect(g.side_tab_filter,&filter);
    require(channels.right<=points.left && points.right<=filter.left && channels.top==filter.top,
        "three FRF tabs occupy one nonoverlapping row");
    WndProc(g.main,WM_COMMAND,MAKEWPARAM(IDC_SIDE_FILTER_ENABLE,BN_CLICKED),0);
    require(g.noise_threshold_enabled,"FRF filter control changes the shared document filter");
    pop_undo();
    require(!g.noise_threshold_enabled,"document filter changes from FRF are undoable");
    WndProc(g.main,WM_COMMAND,IDC_SIDE_TAB_POINTS,0);
    require(shown(point_control) && !shown(g.side_filter_enable) && !shown(g.frf_panel),
        "FRF points tab hides both filter and calculation controls");
    WndProc(g.main,WM_COMMAND,IDC_SIDE_TAB_CHANNELS,0);
    require(shown(g.frf_panel) && !shown(point_control) && !shown(g.side_filter_enable),
        "FRF channels tab restores only the calculation panel");
    WndProc(g.main,WM_COMMAND,IDC_SIDE_TAB_FILTER,0);
    require(g.side_panel_tab==2 && shown(g.side_filter_enable) && !shown(g.frf_panel),
        "filter tab opens after visiting the other FRF tabs");
    MoveWindow(g.main,0,0,980,220,FALSE); layout();
    require(g.side_scroll_max>0,"FRF filter panel can scroll in a short window");
    g.side_panel_visible=false; layout();
    require(!shown(g.side_tab_filter) && !shown(g.side_filter_enable) && !shown(g.frf_panel),
        "hiding the side panel also hides the FRF filter tab and controls");
}

void measurement_label_units() {
    reset_document({"A"}, {0,1}, {{1,2}});
    PointGroup group;
    group.mode=PointGroupMode::Frequency;
    group.display={}; group.display.inv_dt=true;
    require(point_difference_text(group,4,0).find(L"1/Δf=0.25 s")!=std::wstring::npos,
            "reciprocal frequency separation is in seconds");
    require(point_difference_text(group,0,0).find(L"1/Δf=—")!=std::wstring::npos,
            "coincident frequencies have no finite reciprocal separation");
    group.mode=PointGroupMode::Time;
    require(point_difference_text(group,4,0).find(L"1/Δt=0.25 Hz")!=std::wstring::npos,
            "reciprocal time separation is in hertz");
    group.mode=PointGroupMode::FRF; group.frf_reference_axis=true;
    group.display.inv_dt=false; group.display.dy=true;
    g.axis_y_label=L"m/s²";
    require(point_difference_text(group,4,2).find(L"ΔA=2 m/s²")!=std::wstring::npos,
            "reference differences retain physical amplitude units");
    group.frf_reference_axis=false;
    require(point_difference_text(group,4,2).find(L"Δ|H|=2")!=std::wstring::npos,
            "upper FRF differences describe magnitude");
    g_str=&kRu; group.display.inv_dt=true;
    require(point_difference_text(group,4,2).find(L"1/Δf=0.25 с")!=std::wstring::npos,
            "Russian reciprocal frequency units use seconds");
    g_str=&kEn;
}

void streamed_frf_file_and_invalidation() {
    const auto path=test_dir/"streamed-recording.txt";
    {
        std::ofstream out(path);out.precision(17);out<<"Time\tR\tY\n";
        for(int i=0;i<16384;++i) {const double x=std::sin(.13*i);out<<i/1024.<<'\t'<<x<<'\t'<<3*x<<'\n';}
    }
    auto index=std::make_shared<lvm::ScanIndex>();double low,high;std::string error;
    require(lvm::scan_time_bounds(path,low,high,error,nullptr,index.get()),"streaming file builds an ordinary ScanIndex");
    lvm::LoadOptions load;load.use_time_window=true;load.time_start=2;load.time_end=4;load.scan_index=index;
    auto ds=lvm::read_lvm_file(path,load);require(ds.ok,"Light Mode display fragment loads normally");
    reset_document(ds.names,ds.time,ds.channels);g.ds.source_columns=ds.source_columns;
    g.source_path=std::filesystem::absolute(path).wstring();g.source_scan_index=index;g.current_file_partial=true;
    g.loaded_source_stamp_valid=true;g.loaded_source_size=std::filesystem::file_size(path);g.loaded_source_modified=std::filesystem::last_write_time(path);
    g.main=CreateWindowExW(0,L"STATIC",L"Streaming FRF",WS_POPUP,0,0,1000,600,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    require(g.main!=nullptr,"streaming integration has a hidden main window");
    g.frf.inputs={0};g.frf.outputs={1};g.frf.options.segment_length=2048;g.mode=AnalysisMode::FRF;
    const auto wait=[&] {
        const auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(10);
        while(g.frf.pending && std::chrono::steady_clock::now()<deadline) {
            poll_frf_result();if(g.frf.pending)std::this_thread::sleep_for(std::chrono::milliseconds(2));
        }
        require(!g.frf.pending && g.frf.result.ok,"streaming worker result reaches the active document");
    };
    handle_commands_message(g.main,WM_COMMAND,IDM_ANALYSIS_ENTIRE,0);wait();
    require(g.frf.result.common().sample_count==16384 && g.ds.rows()<16384,"entire-file FRF does not replace or expand the display fragment");
    require(!g.fft_window_active,"entire-recording FRF preserves the independent FFT selection");
    const auto generation=g.frf.generation;
    g.frf.display_smoothing_octaves=0;g.frf.logarithmic_frequency_axis=!g.frf.logarithmic_frequency_axis;
    require(ensure_current_frf() && g.frf.generation==generation,"display changes preserve the numerical input and result");
    const auto cosmetic=capture_settings_snapshot();const auto revision=g.numerical_revision;
    const auto original_label=channel_display_label(1);
    g.channel_labels[1]=L"Renamed";g.show_channel_legend=!g.show_channel_legend;
    apply_settings_snapshot(cosmetic);
    require(g.numerical_revision==revision && g.frf.generation==generation && g.frf.result.ok && !g.frf.pending,
            "restoring cosmetic history preserves the full-record numerical result and input revision");
    require(g.frf.output_names[0]==original_label,"cosmetic history refreshes FRF curve names without a numerical recalculation");
    g.frf.options.segment_length=1000;ensure_current_frf();wait();
    require(g.frf.result.common().segment_length==1000,"changed L recomputes the cached full-record input");
    g.frf.options.remove_mean=false;ensure_current_frf();wait();
    require(!g.frf.result.common().options.remove_mean,"changed mean removal recomputes the cached input");
    const auto full_samples=lvm::read_lvm_file(path);
    for(bool affine_global:{true,false}) {
        g.global_formula=affine_global ? L"3*x+2*x" : L"sin(x)";g.global_formula_rpn.clear();
        g.channel_formulas.assign(2,affine_global ? L"sin(x)" : L"x");g.channel_formula_rpn.assign(2,{});
        invalidate_formula_runtime();ensure_channel_formula_vectors();
        on_frf_processing_changed();wait();
        lvm::FrfBatchInput expected_input;expected_input.time=full_samples.time;
        expected_input.references.resize(1);expected_input.responses.resize(1);
        for(std::size_t i=0;i<full_samples.rows();++i) {
            expected_input.references[0].push_back(transform_channel_value(0,full_samples.channels[0][i]));
            expected_input.responses[0].push_back(transform_channel_value(1,full_samples.channels[1][i]));
        }
        const auto expected=lvm::analyze_frf_batch(std::move(expected_input),g.frf.options);
        const auto& a=g.frf.result.common();const auto& b=expected.common();
        const auto same=[](const std::vector<double>& x,const std::vector<double>& y) {
            if(x.size()!=y.size())return false;
            for(std::size_t i=0;i<x.size();++i)if(x[i]!=y[i] && !(std::isnan(x[i]) && std::isnan(y[i])))return false;
            return true;
        };
        require(a.ok && b.ok && a.frequencies==b.frequencies && a.transfer==b.transfer &&
                a.valid==b.valid && a.coherence_valid==b.coherence_valid && a.reference_amplitude_valid==b.reference_amplitude_valid &&
                same(a.coherence,b.coherence) && same(a.reference_amplitude,b.reference_amplitude),
                "streamed complex formulas preserve GUI affine/identity arithmetic and all numerical arrays");
    }
    g.noise_threshold_enabled=true;g.noise_threshold_min=10;g.noise_threshold_max=100;
    on_frf_processing_changed();wait();
    require(g.frf.result.common().sample_count==16384,"processed full-record FRF retains every original sample across the filter cadence pass");
    lvm::FrfBatchInput filtered_input;filtered_input.time=full_samples.time;
    std::vector<std::vector<double>> filtered_channels;
    for(std::size_t c=0;c<2;++c) {
        std::vector<double> values;
        for(auto x:full_samples.channels[c])values.push_back(transform_channel_value(c,x));
        filtered_channels.push_back(filter_signal(full_samples.time,values,
            {g.noise_threshold_mode,g.noise_threshold_topology,g.noise_threshold_min,g.noise_threshold_max,1./1024}));
    }
    filtered_input.references.push_back(std::move(filtered_channels[0]));
    filtered_input.responses.push_back(std::move(filtered_channels[1]));
    const auto filtered_expected=lvm::analyze_frf_batch(std::move(filtered_input),g.frf.options);
    const auto& filtered_actual=g.frf.result.common();
    const auto scalar_equal=[](double a,double b){return a==b || (std::isnan(a) && std::isnan(b));};
    const auto arrays_equal=[&](const auto& a,const auto& b) {
        if(a.size()!=b.size())return false;
        for(std::size_t i=0;i<a.size();++i)if(!scalar_equal(a[i],b[i]))return false;
        return true;
    };
    bool complex_equal=filtered_actual.transfer.size()==filtered_expected.common().transfer.size();
    if(complex_equal)for(std::size_t i=0;i<filtered_actual.transfer.size();++i) {
        const auto a=filtered_actual.transfer[i],b=filtered_expected.common().transfer[i];
        complex_equal &= scalar_equal(a.real(),b.real()) && scalar_equal(a.imag(),b.imag());
    }
    require(filtered_expected.ok && filtered_actual.ok && filtered_actual.error==filtered_expected.common().error &&
            filtered_actual.sample_dt==filtered_expected.common().sample_dt &&
            filtered_actual.sample_count==filtered_expected.common().sample_count &&
            filtered_actual.source_start==filtered_expected.common().source_start && filtered_actual.source_end==filtered_expected.common().source_end &&
            filtered_actual.segment_length==filtered_expected.common().segment_length &&
            filtered_actual.averages==filtered_expected.common().averages && filtered_actual.overlap_samples==filtered_expected.common().overlap_samples &&
            filtered_actual.gaps_ignored==filtered_expected.common().gaps_ignored &&
            filtered_actual.frequencies==filtered_expected.common().frequencies &&
            complex_equal && filtered_actual.valid==filtered_expected.common().valid &&
            arrays_equal(filtered_actual.reference_amplitude,filtered_expected.common().reference_amplitude) &&
            filtered_actual.reference_amplitude_valid==filtered_expected.common().reference_amplitude_valid &&
            arrays_equal(filtered_actual.coherence,filtered_expected.common().coherence) &&
            filtered_actual.coherence_valid==filtered_expected.common().coherence_valid,
            "recording reader retains exact H1, coherence, masks and reference spectrum after the filter cadence pass");
    g.frf.apply_processing=false;compute_frf_from_current_source();wait();
    require(g.frf.processing_description==L"raw","raw/processed change selects a different numerical input");
    {
        std::ofstream changed(path,std::ios::app);changed<<"# changed\n";
    }
    require(!ensure_current_frf() && g.frf.result.error==lvm::FrfError::SourceChanged,"changed file invalidates both completed results and prepared input");
    g_frf_worker.cancel();DestroyWindow(g.main);g.main=nullptr;
}
void bounded_formula_cache_selection() {
    std::vector<double> time(8400000),values(8400000,.5);
    for(std::size_t i=0;i<time.size();++i)time[i]=static_cast<double>(i);
    reset_document({"large"},time,{values});
    g.channel_formulas={L"sin(x)"};g.channel_formula_rpn.assign(1,{});
    invalidate_formula_runtime();ensure_channel_formula_vectors();
    lvm::Dataset selection;build_time_window_dataset(g.ds,2,5,selection);
    require(selection.rows()==4 && selection.channel_count()==1,"small selection can use a formula whose full cache exceeds its budget");
    require(g.transformed_channel_cache[0].empty(),"formula does not allocate an oversized full-record cache");
    near(selection.channels[0][0],std::sin(.5),"uncached selection preserves formula values");
}

void document_source_and_resources() {
    const auto path=test_dir/"document_source.lvm";
    {std::ofstream f(path);f<<"Time\tA\tB\n0\t4\t7\n1\t5\t8\n2\t6\t9\n";}
    reset_document({"old"},{0,1},{{1,2}});
    auto loaded=lvm::read_lvm_file(path);lvm::drop_duplicate_time_channels(loaded,loaded.raw_time);
    require(apply_loaded_dataset(std::move(loaded),path.wstring(),false,0,false),"valid load publishes a document source");
    const auto source=current_recording_source();const auto samples=g.ds.time.data();
    require(source==g.recording_source && source==current_recording_source(),"repeated jobs share the document descriptor without copying samples");
    const auto occupied=document_data_memory_bytes();
    require(occupied>=g.ds.time.capacity()*sizeof(double)+g.ds.raw_time.capacity()*sizeof(double),"resource account includes actual time capacities");
    DocumentState other;other.ds.ok=true;other.ds.time={0,1};other.ds.channels={{2,3}};other.file_name=L"other";
    g.inactive_documents.push_back(std::move(other));
    require(document_data_memory_bytes()>occupied,"resource account includes inactive documents");
    require(switch_to_document(g.inactive_documents.size()) && switch_to_document(g.inactive_documents.size()),"document source survives a document round trip");
    require(g.recording_source==source && g.ds.time.data()==samples,"document switching moves source and samples without duplication");
    const auto before=g.numerical_revision;const auto count=open_document_count();
    const auto old_stamp=*source->stamp();
    {std::ofstream f(path,std::ios::app);f<<"# changed\n";}
    auto replacement=lvm::read_lvm_file(path);lvm::drop_duplicate_time_channels(replacement,replacement.raw_time);
    require(!apply_loaded_dataset(std::move(replacement),path.wstring(),false,0,false,old_stamp) &&
        g.ds.time.data()==samples && open_document_count()==count,"stale publication rejects before replacing the active document");
    bool stale=false;try{current_recording_source();}catch(const lvm::RecordingFailure& e){stale=e.error==lvm::RecordingError::SourceChanged;}
    require(stale,"shared source detects changed files after document switching");
    require(set_resource_policy(false,1024) && g.numerical_revision==before,"manual resource policy does not invalidate numerical input");
    save_runtime_settings_now();g.resource_policy={true,2048};load_runtime_settings();
    require(!g.resource_policy.automatic && g.resource_policy.manual_mib==1024,"manual memory limit persists in INI");
    require(set_disk_cache_policy(false,4096) && g.numerical_revision==before,
        "disk cache policy is independent of RAM and numerical inputs");
    save_runtime_settings_now();g.disk_cache_mib=2048;load_runtime_settings();
    require(!g.disk_cache_unlimited && g.disk_cache_mib==4096 && !g.resource_policy.automatic &&
        g.resource_policy.manual_mib==1024,"independent RAM and disk preferences survive INI reload");
    require(set_disk_cache_policy(true,4096),"disk cache can use no fixed byte limit");
    save_runtime_settings_now();g.disk_cache_unlimited=false;load_runtime_settings();
    require(g.disk_cache_unlimited && g.disk_cache_mib==4096,"unlimited disk mode retains the manual value across reload");
    require(!set_disk_cache_policy(false,0) && g.disk_cache_unlimited,"zero disk quota is rejected without changing the policy");
    require(set_disk_cache_policy(false,2048),"default disk quota can be restored");
    WritePrivateProfileStringW(L"ui",L"stitch_time_gaps",L"1",g_config_path.c_str());
    WritePrivateProfileStringW(L"ui",L"light_mode",L"1",g_config_path.c_str());load_runtime_settings();
    require(!g.stitch_time_gaps,"legacy global INI stitching does not override the active document");
    save_runtime_settings_now();
    require(read_ini_int(L"ui",L"light_mode",-1)==-1 && !g.resource_policy.automatic,"legacy Light Mode preference is retired without losing the data budget");
    require(read_ini_int(L"ui",L"stitch_time_gaps",-1)==-1,"runtime settings retire the global stitching key while projects retain it");
    require(!set_resource_policy(false,0) && g.resource_policy.manual_mib==1024,"invalid manual limit cannot enable unlimited loading");
    require(set_resource_policy(true,1024),"user can return to Auto without losing their manual value");
    save_runtime_settings_now();
    WritePrivateProfileStringW(L"resources",L"manual_mib",L"-1",g_config_path.c_str());load_runtime_settings();
    require(g.resource_policy.automatic && g.resource_policy.manual_mib==2048,"invalid saved memory policy falls back to Auto");
    const auto gpu_before=lvm::gpu_fft_status().attempted;
    const auto revision=g.numerical_revision;
    g.menu=make_menu();
    for(const auto mode:{lvm::ComputeBackend::Cpu,lvm::ComputeBackend::Gpu,lvm::ComputeBackend::Auto}) {
        const auto command=mode==lvm::ComputeBackend::Cpu ? IDM_COMPUTE_CPU :
            mode==lvm::ComputeBackend::Gpu ? IDM_COMPUTE_GPU : IDM_COMPUTE_AUTO;
        handle_commands_message(g.main,WM_COMMAND,command,0);
        require(lvm::compute_backend()==mode && (GetMenuState(g.menu,command,MF_BYCOMMAND)&MF_CHECKED),
                "computation preference command updates the checked menu item");
        save_runtime_settings_now();lvm::set_compute_backend(lvm::ComputeBackend::Cpu);load_runtime_settings();
        require(lvm::compute_backend()==mode,"computation preference persists through INI reload");
    }
    require(g.numerical_revision==revision && lvm::gpu_fft_status().attempted==gpu_before,
            "computation preference does not alter numerical input or initialize a GPU on the UI thread");
    WritePrivateProfileStringW(L"resources",L"compute_backend",L"99",g_config_path.c_str());load_runtime_settings();
    require(lvm::compute_backend()==lvm::ComputeBackend::Auto,"invalid saved computation preference falls back to Auto");
    DestroyMenu(g.menu);g.menu=nullptr;lvm::set_compute_backend(lvm::ComputeBackend::Cpu);save_runtime_settings_now();
    // A request retains a descriptor after the document itself is closed.
    auto independent=lvm::RecordingSource::from_file(path,{0,2},{1,2});
    g.recording_source=independent;std::weak_ptr<const lvm::RecordingSource> weak=independent;
    close_active_document();
    lvm::RecordingReadRequest request;request.channels={0};std::size_t rows=0;
    independent->replay(request,[&](const auto& t,const auto&){rows+=t.size();});
    require(rows==3 && !weak.expired(),"closing a document leaves an owned background source readable");
    independent.reset();require(weak.expired(),"source is released after both document and task owners finish");
}

void background_document_overview() {
    const auto path=test_dir/"overview-document.txt",cache=test_dir/"overview-document.bin";
    {std::ofstream out(path);out<<"Time\tA\tB\n";
     for(int i=0;i<12000;++i)out<<i<<'\t'<<i%17<<'\t'<<i%23<<'\n';}
    reset_document({"A","B"},{0,1,2},{{4,5,6},{7,8,9}});
    g.recording_source=lvm::RecordingSource::from_file(path,{0,11999},{1,2});
    const auto source=g.recording_source;const auto samples=g.ds.time.data();const auto revision=g.numerical_revision;
    const auto budget=refresh_load_memory_budget();const auto baseline=budget->reserved();
    const auto wait=[&] {
        const auto start=std::chrono::steady_clock::now();
        while(g.overview.pending && std::chrono::steady_clock::now()-start<std::chrono::seconds(10)) {
            poll_recording_overview();Sleep(1);
        }
    };
    require(request_recording_overview(cache,lvm::AnalysisRange::entire(),{1,0},4),"GUI starts a background overview independently of its small Dataset");wait();
    if(g.overview.error)std::cerr<<"Background overview error="<<static_cast<int>(*g.overview.error)<<std::endl;
    require(!g.overview.pending && !g.overview.error && g.overview.view && g.overview.view->sample_count==12000,
            "complete source overview is published in the owning document");
    require(g.overview.channels==std::vector<std::size_t>({1,0}) && g.overview.index->source()==source,
            "overview publication preserves logical channel mapping and source identity");
    require(g.ds.time.data()==samples && g.ds.rows()==3 && g.numerical_revision==revision,
            "overview never substitutes aggregate values for Dataset or changes numerical revision");
    const auto view=g.overview.view;const auto index=g.overview.index;
    require(budget->reserved()>baseline,"published GUI overview retains its own admission without double-counting document arrays");
    DocumentState other;other.ds.ok=true;other.ds.time={0,1};other.ds.channels={{1,2}};
    g.inactive_documents.push_back(std::move(other));
    require(request_recording_overview(cache,lvm::AnalysisRange::selected(100,110),{0},500) && switch_to_document(1),
            "switching a document cancels its pending background view");
    Sleep(20);require(!poll_recording_overview() && !g.overview.view,"cancelled result cannot replace the other document's view");
    require(switch_to_document(1) && !g.overview.pending && g.overview.view==view && g.overview.index==index,
            "returning restores the completed immutable overview without copying buckets");
    require(request_recording_overview(cache,lvm::AnalysisRange::selected(200,210),{0},500),"indexed GUI zoom can be requested again");wait();
    require(!g.overview.error && g.overview.view->sample_count==11 && g.overview.view->buckets.front().channels[0].first.value==200%17,
            "background zoom returns original samples outside the loaded Dataset");
    require(request_recording_overview(cache,lvm::AnalysisRange::selected(300,310),{1},500),"GUI can queue a subsequent viewport");
    const auto started=std::chrono::steady_clock::now();
    while(g_overview_worker.progress().phase!=lvm::OverviewWorker::Phase::Idle &&
          std::chrono::steady_clock::now()-started<std::chrono::seconds(10))Sleep(1);
    {std::ofstream out(path,std::ios::app);out<<"# changed after worker finished\n";}
    require(poll_recording_overview() && g.overview.error==lvm::RecordingError::SourceChanged && !g.overview.view && !g.overview.index,
            "GUI revalidates source at publication even when the file changes after completion");
    require(g.ds.time.data()==samples && g.numerical_revision==revision,"failed overview leaves resident samples and numerical input untouched");
    cancel_recording_overview();g.inactive_documents.clear();
    require(close_active_document() && !g.overview.pending && !g.overview.view,"closing the last document discards its overview state");
}

void analysis_preempts_background_overview() {
    const auto path=test_dir/"analysis-overview-priority.txt";
    const auto cache=test_dir/"analysis-overview-priority.bin";
    {std::ofstream out(path);out<<"Time\tA\tB\n";
     for(int i=0;i<256;++i)out<<i<<'\t'<<i%17<<'\t'<<i%23<<'\n';}
    reset_document({"A","B"},{0,255},{{0,0},{0,0}});
    g.main=CreateWindowExW(WS_EX_NOACTIVATE,L"STATIC",L"Analysis priority test",WS_POPUP,
        -10000,-10000,1000,650,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    require(g.main!=nullptr,"analysis priority fixture creates a hidden GUI owner");
    struct Cleanup {HWND window;~Cleanup(){DestroyWindow(window);g.main=nullptr;}} cleanup{g.main};
    g.source_path=path.wstring();g.ds.source_columns={1,2};
    g.recording_source=lvm::RecordingSource::from_file(path,{0,255},{1,2});
    g.recording_rows=256;g.overview.render_enabled=true;
    g.frf.inputs={0};g.frf.outputs={1};g.frf.options.segment_length=64;
    const auto source=g.recording_source;const auto revision=g.numerical_revision;
    const auto wait=[&] {
        const auto start=std::chrono::steady_clock::now();
        while(g.overview.pending && std::chrono::steady_clock::now()-start<std::chrono::seconds(10)) {
            poll_recording_overview();Sleep(1);
        }
        require(!g.overview.pending && !g.overview.error,"mode-switch overview completes");
    };
    require(request_recording_overview(cache,lvm::AnalysisRange::entire(),{0,1},4,true),
            "mode-switch fixture prepares a reusable source overview");wait();
    std::size_t pixels=4;
    for(const auto mode:{AnalysisMode::FFT,AnalysisMode::FRF}) {
        const auto index=g.overview.index;const auto view=g.overview.view;
        pixels*=2;
        require(request_recording_overview(cache,lvm::AnalysisRange::entire(),{0,1},pixels,true) && g.overview.pending,
                "a different density can be pending while the old view remains usable");
        const auto generation=g.overview.generation;
        set_mode(mode);
        require(!g.overview.pending && g.overview.generation!=generation,
                "entering FFT or FRF cancels pending Signal refinement");
        require(g.overview.index==index && g.overview.view==view && g.recording_source==source,
                "analysis retains the ready overview and original source");
        require(!poll_recording_overview() && g.overview.view==view,
                "a cancelled overview cannot publish a late replacement in analysis mode");
        require(g.numerical_revision==revision && g_undo.empty() && g_redo.empty(),
                "overview cancellation changes neither numerical input nor history");
        const auto analysis_start=std::chrono::steady_clock::now();
        while((mode==AnalysisMode::FFT ? g.spec_pending : g.frf.pending) &&
              std::chrono::steady_clock::now()-analysis_start<std::chrono::seconds(10)) {
            if(mode==AnalysisMode::FFT) {
                if(auto result=g_spectrum_worker.take_result())apply_spectrum_result(std::move(result->spectrum));
            } else poll_frf_result();
            Sleep(1);
        }
        if(mode==AnalysisMode::FFT)
            require(g.spec_valid && g.spec.n==256,"FFT still analyses every original sample after overview cancellation");
        else
            require(g.frf.result.ok && !g.frf.result.responses.empty() && g.frf.result.responses[0].sample_count==256,
                    "FRF still analyses every original sample after overview cancellation");
        set_mode(AnalysisMode::Time);
        require(synchronize_overview_viewport(pixels),
                "returning to Signal resubmits cancelled density even when the old range matches");wait();
        require(g.overview.index==index && g.overview.view!=view && g.overview.view->pixel_columns==pixels,
                "the same worker and index produce the requested view after returning");
    }
    const auto generation=g.overview.generation;const auto view=g.overview.view;
    require(!synchronize_overview_viewport(pixels) && g.overview.generation==generation && g.overview.view==view,
            "a completed matching Signal view is reused without another request");
    set_mode(AnalysisMode::FFT);set_mode(AnalysisMode::Time);
    require(g.overview.view==view && !synchronize_overview_viewport(pixels),
            "leaving and returning with no pending refinement reuses the completed view");
    for(const auto mode:{AnalysisMode::FFT,AnalysisMode::FRF}) {
        cancel_recording_overview();g.overview={};g.overview.render_enabled=true;
        require(request_recording_overview(cache,lvm::AnalysisRange::entire(),{0,1},32,true),
                "a first overview can be pending before any index is published");
        require(!g.overview.index && !g.overview.view,"the pending first overview has no published aggregates");
        set_mode(mode);
        require(!g.overview.pending && !g.overview.index && !g.overview.view && !poll_recording_overview(),
                "entering analysis cancels an unpublished first overview without publishing partial state");
        set_mode(AnalysisMode::Time);
        require(synchronize_overview_viewport(32),"returning to Signal restarts the cancelled first overview");wait();
        require(g.overview.index && g.overview.view && g.overview.view->sample_count==256 &&
                g.overview.index->source()==source && g.numerical_revision==revision,
                "the reusable worker restores a complete source view after first-build cancellation");
    }
    cancel_recording_overview();g_overview_worker.trim_cache(0);g.overview={};
}

void overview_renderer() {
    const auto path=test_dir/"renderer.txt",cache=test_dir/"renderer.bin";
    {std::ofstream out(path);out<<"Time\tA\tB\n"<<std::setprecision(17);
     for(int i=0;i<20001;++i) {
         const double t=i*.001+(i>=9000 ? .5 : 0);
         out<<t<<'\t';if(i==6666)out<<"nan";else out<<(i==0 ? -0.0 : (i==4444 ? 100.0 : std::sin(i*.01)));
         out<<'\t'<<(i==12000 ? -7.0 : std::cos(i*.02))<<'\n';
     }}
    double start=0,end=0;std::string error;auto scan=std::make_shared<lvm::ScanIndex>();
    require(lvm::scan_time_bounds(path,start,end,error,nullptr,scan.get()),"overview renderer fixture scans");
    auto source=lvm::RecordingSource::from_file(path,{start,end},{1,2},scan);
    std::vector<double> time;std::vector<std::vector<double>> values(2);lvm::RecordingReadRequest raw;raw.channels={0,1};
    source->replay(raw,[&](const auto& t,const auto& v){time.insert(time.end(),t.begin(),t.end());
        for(int c=0;c<2;++c)values[c].insert(values[c].end(),v[c].begin(),v[c].end());});
    reset_document({"A","B"},{0,.001,.002},{{1000,1000,1000},{2000,2000,2000}});
    g.channel_colors={RGB(43,124,202),RGB(231,96,51)};
    g.main=CreateWindowExW(0,L"STATIC",L"Overview rendering regression",WS_OVERLAPPEDWINDOW,
                          0,0,1100,700,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    require(g.main!=nullptr,"overview PNG uses a hidden window with defined client bounds");
    g.recording_source=source;g.source_scan_index=scan;
    g.data_t0=g.win_start=start;g.data_t1=g.win_end=end;
    g.cached_global_gap_step=.001;g.cached_global_gap_step_ready=true;g.show_channel_legend=false;
    const auto resident=g.ds.time.data();const auto revision=g.numerical_revision;
    const auto wait=[&] {
        const auto started=std::chrono::steady_clock::now();
        while(g.overview.pending && std::chrono::steady_clock::now()-started<std::chrono::seconds(10)) {
            poll_recording_overview();Sleep(1);
        }
    };
    require(request_recording_overview(cache,lvm::AnalysisRange::entire(),{0,1},880,true),"display density is requested separately from the numerical source");wait();
    g.overview.render_enabled=true;
    require(!g.overview.error && overview_view_matches_viewport() && g.overview.view->sample_count==20001 &&
            g.overview.view->buckets.size()<=1762,"ready projection covers all original samples with bounded buckets");
    double low=0,high=0;
    require(current_time_yrange(low,high) && low< -7 && high>100 && high<110,
            "overview auto-Y uses original extrema outside the resident Dataset");
    bool exact=true,bridges=false;int count=0,breaks=0;
    for(std::size_t c=0;c<2;++c) {
        std::size_t previous=0;bool first=true;
        visit_overview_curve(c,.064,[&](OverviewCurvePoint point) {
            const auto at=std::lower_bound(time.begin(),time.end(),point.time);
            if(at==time.end() || *at!=point.time){exact=false;return;}
            const auto i=static_cast<std::size_t>(at-time.begin());exact=exact && point.value==values[c][i] &&
                (point.value!=0 || std::signbit(point.value)==std::signbit(values[c][i]));
            if(!point.connect)++breaks;
            else if(first || i<=previous)bridges=true;
            else for(auto k=previous+1;k<=i;++k)
                bridges=bridges || time[k]-time[k-1]>.064 || !std::isfinite(values[c][k]);
            previous=i;first=false;++count;
        });
    }
    require(exact && count>0 && breaks>=4 && !bridges,"overview strokes keep exact original coordinates and never bridge NaN/timing gaps");
    HDC dc=CreateCompatibleDC(nullptr);BITMAPINFO info{};info.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
    info.bmiHeader.biWidth=1000;info.bmiHeader.biHeight=-600;info.bmiHeader.biPlanes=1;info.bmiHeader.biBitCount=32;
    info.bmiHeader.biCompression=BI_RGB;void* pixels=nullptr;
    HBITMAP bitmap=CreateDIBSection(dc,&info,DIB_RGB_COLORS,&pixels,nullptr,0);const auto old=SelectObject(dc,bitmap);
    require(bitmap && pixels,"overview renderer has a real GDI surface");
    const RECT plot{60,40,940,520};const Theme* saved_theme=g_theme;
    for(const auto* theme:{&kLightTheme,&kDarkTheme}) {
        g_theme=theme;const RECT all{0,0,1000,600};HBRUSH background=CreateSolidBrush(theme->bg_plot);
        FillRect(dc,&all,background);DeleteObject(background);draw_chart(dc,plot);GdiFlush();
        require(g.vvalid && g.vx0==start && g.vx1==end && g.vy1>100,"both themes render full overview with correct axes");
        const auto generation=g.overview.generation;g.axis_x_label=L"Entire recording";g.channel_colors[0]=RGB(43,124,202);
        draw_chart(dc,plot);require(g.overview.generation==generation,"presentation changes do not reread numerical input or overview");
    }
    ULONG_PTR token=0;Gdiplus::GdiplusStartupInput startup;
    require(Gdiplus::GdiplusStartup(&token,&startup,nullptr)==Gdiplus::Ok,"overview PNG startup");
    g_theme=&kLightTheme;require(save_png((test_dir/"overview_light.png").wstring()),"overview uses the existing light PNG renderer");
    g_theme=&kDarkTheme;require(save_png((test_dir/"overview_dark.png").wstring()),"overview uses the existing dark PNG renderer");
    Gdiplus::GdiplusShutdown(token);wait();
    require(g.numerical_revision==revision && g.ds.time.data()==resident,
            "rendering, PNG and viewport jobs leave numerical revision and source arrays unchanged");
    g.channel_formulas[0]=L"-2*x+3";rebuild_formula_cache_from_state();
    require(overview_time_yrange(low,high) && low< -197 && high>5 && high<20,
            "negative affine coefficient reverses extrema correctly without recalculating the raw index");
    bool affine=true;
    visit_overview_curve(0,.064,[&](OverviewCurvePoint p){const auto at=std::lower_bound(time.begin(),time.end(),p.time);
        affine=affine && at!=time.end() && p.value==values[0][at-time.begin()]*(-2)+3;});
    require(affine,"affine curve values preserve the channel formula arithmetic");
    g.channel_formulas[0]=L"1e308*x";rebuild_formula_cache_from_state();draw_chart(dc,plot);
    require(!g.vvalid && !overview_time_yrange(low,high),"affine overflow cannot become an invalid GDI coordinate or a substituted raw curve");
    g.channel_formulas[0]=L"x";rebuild_formula_cache_from_state();
    g.win_start=time[7000];g.win_end=time[7030];
    require(synchronize_overview_viewport(880),"navigation queues a projection of the new viewport");
    require(!overview_view_matches_viewport(),"the old projection cannot impersonate a different viewport");
    draw_chart(dc,plot);
    require(g.vvalid && g.vx0==time[7000] && g.vx1==time[7030],"zoom retains a clipped previous projection while exact samples load");wait();
    require(g.overview.view->sample_count==31 && std::all_of(g.overview.view->buckets.begin(),g.overview.view->buckets.end(),
            [](const auto& b){return b.sample_count==1;}),"deep zoom shows original samples");
    g.visual_smooth=true;draw_chart(dc,plot);
    require(g.vvalid && g.vx0==time[7000] && g.vx1==time[7030],"original-sample smoothing keeps the requested time axis");
    require(!synchronize_overview_viewport(880),"a repeated paint of the same view does not submit another job");
    const auto navigation_revision=g.numerical_revision;
    g.resource_policy={false,64};
    require(synchronize_overview_viewport(880),"changing the resource policy retries the projection with a fresh admission");wait();
    require(!g.overview.error && g.numerical_revision==navigation_revision && g.overview.view->sample_count==31,
            "memory policy changes preserve the exact viewport and numerical input revision");
    double x=time[7005],y=.5;int channel=-1;
    require(!snap_to_nearest_target(x,y,&channel) && x==time[7005] && y==.5,
            "internal overview preview cannot snap to the unrelated resident Dataset");
    const auto wait_snap=[&] {
        const auto started=std::chrono::steady_clock::now();
        while(g.overview.snap_pending && std::chrono::steady_clock::now()-started<std::chrono::seconds(10)) {
            poll_overview_snap();Sleep(1);
        }
        require(!g.overview.snap_pending,"original Snap finishes without blocking the GUI thread");
    };
    int accepted=0;lvm::RecordingSnapResult picked;
    const auto accept=[&](const auto& p){++accepted;picked=p;};
    require(request_overview_snap(x,y,accept),"overview Snap submits original-source I/O separately from the resident Dataset");
    require(accepted==0,"original measurement is deferred until the UI polls a complete result");wait_snap();
    require(accepted==1 && picked.found && picked.time>=g.win_start && picked.time<=g.win_end &&
            picked.value==values[picked.channel][picked.sample] && std::abs(picked.value)<2 && !g.overview.snap_error,
            "published Snap is an original channel value outside the resident fragment");
    const auto saved_start=g.win_start;
    require(request_overview_snap(x,y,accept),"viewport invalidation fixture starts a Snap");g.win_start+=.001;wait_snap();g.win_start=saved_start;
    require(accepted==1,"changed viewport discards the completed original point");
    require(request_overview_snap(x,y,accept),"numerical revision invalidation fixture starts a Snap");++g.numerical_revision;wait_snap();
    require(accepted==1,"changed numerical input discards Snap without publishing an old formula value");
    require(request_overview_snap(x,y,accept),"visibility invalidation fixture starts a Snap");g.visible[1]=0;wait_snap();g.visible[1]=1;
    require(accepted==1,"new visible channel set invalidates the nearest-point result");
    require(request_overview_snap(x,y,accept),"annotation lock fixture starts a Snap");g.annotations_locked=true;wait_snap();g.annotations_locked=false;
    require(accepted==1,"locking annotations discards an in-flight placement");
    require(request_overview_snap(x,y,accept),"document identity invalidation fixture starts a Snap");
    g.recording_source=lvm::RecordingSource::from_file(path,{start,end},{1,2},scan);wait_snap();g.recording_source=source;
    require(accepted==1,"a different document source cannot receive the previous Snap result");
    g.inactive_documents.emplace_back();auto& other=g.inactive_documents.back();
    other.ds.ok=true;other.ds.names={"Other"};other.ds.time={0,1};other.ds.channels={{9,10}};
    other.visible={1};other.channel_labels={L"Other"};other.channel_formulas={L"x"};other.data_t0=other.win_start=0;other.data_t1=other.win_end=1;
    require(request_overview_snap(x,y,accept),"real document switch fixture starts a Snap");
    require(switch_to_document(1),"real document switch cancels original-source I/O");Sleep(10);poll_overview_snap();
    require(accepted==1 && !g.overview.snap_pending,"the new active document receives no pending measurement from the previous one");
    require(switch_to_document(1),"the preview document can be restored after Snap cancellation");g.inactive_documents.clear();draw_chart(dc,plot);
    require(g.recording_source==source && g.ds.time.data()==resident && !g.overview.snap_pending,
            "restored document keeps the source/view without reviving its cancelled Snap");
    require(request_overview_snap(x,y,accept),"cancel fixture starts a Snap");cancel_overview_snap();Sleep(10);poll_overview_snap();
    require(accepted==1 && !g.overview.snap_pending,"explicit cancellation never changes a measurement");
    require(request_overview_snap(x,y,accept),"replacement fixture starts an old Snap");
    require(request_overview_snap(time[7025],-.1,accept),"replacement fixture starts the latest Snap");wait_snap();
    require(accepted==2 && picked.sample>=7000 && picked.sample<=7030,"only the replacement Snap can invoke its publication callback");
    {
        const auto before_range=capture_settings_snapshot();const RECT before_rect=g.vrect;
        const RECT range_plot=plot_rect();g.vrect=range_plot;
        const int target_x=range_plot.left+(range_plot.right-range_plot.left)*2/5;
        const int target_y=(range_plot.top+range_plot.bottom)/2;
        double target_time=0,target_value=0;
        require(px_to_data(target_x,target_y,target_time,target_value),"range magnet has an exact source viewport mapping");
        lvm::RecordingSnapResult exact;
        g.annotations_locked=true;g.measure_mode=true;
        require(request_overview_snap(target_time,target_value,[&](const auto& point){exact=point;},true),
            "range snapping remains available when annotations are locked");wait_snap();
        require(exact.found && exact.time>time[7001] && exact.time<time[7029],
            "disk range snap finds a real sample outside the unrelated resident fragment");
        for(int edge:{1,2}) {
            set_fft_window(time[7001],time[7029]);g_undo.clear();g_redo.clear();
            const int edge_x=analysis_range_edge_x(edge==1 ? g.fft_window_start : g.fft_window_end,range_plot);
            require(begin_analysis_range_edge_drag(g.main,edge_x,target_y),"both disk-backed boundaries can begin a magnetic drag");
            handle_input_message(g.main,WM_MOUSEMOVE,MK_LBUTTON,MAKELPARAM(target_x,target_y));
            require(g.overview.snap_pending && g_undo.empty() && g.fft_window_start==time[7001] && g.fft_window_end==time[7029],
                "disk magnetic preview performs asynchronous source I/O without changing analysis input");wait_snap();
            require(g.fft_select_current_t==exact.time,"the disk-backed boundary preview uses the exact original sample time");
            handle_input_message(g.main,WM_LBUTTONUP,0,MAKELPARAM(target_x,target_y));
            require(g.overview.snap_pending && g_undo.empty(),"release waits for the final exact source point before committing");wait_snap();
            require((edge==1 ? g.fft_window_start : g.fft_window_end)==exact.time && g_undo.size()==1,
                "final disk range snap commits one exact boundary and one Undo entry");
            pop_undo();require(g.fft_window_start==time[7001] && g.fft_window_end==time[7029],"Undo restores the disk-backed interval");
            pop_redo();require((edge==1 ? g.fft_window_start : g.fft_window_end)==exact.time,"Redo restores the snapped disk-backed edge");
        }
        set_fft_window(time[7001],time[7029]);g_undo.clear();g_redo.clear();
        const int edge_x=analysis_range_edge_x(g.fft_window_start,range_plot);
        require(begin_analysis_range_edge_drag(g.main,edge_x,target_y),"disk cancellation starts a range drag");
        handle_input_message(g.main,WM_MOUSEMOVE,MK_LBUTTON,MAKELPARAM(target_x,target_y));
        handle_input_message(g.main,WM_LBUTTONUP,0,MAKELPARAM(target_x,target_y));
        handle_input_message(g.main,WM_KEYDOWN,VK_ESCAPE,0);wait_snap();
        require(g.fft_window_start==time[7001] && g.fft_window_end==time[7029] && g_undo.empty(),
            "Escape cancels a pending final disk range snap without changing the analysis interval");
        g.annotations_locked=false;apply_settings_snapshot(before_range);g.vrect=before_rect;
    }
    g.markers.clear();g.guides.clear();g.point_groups.clear();g_undo.clear();g_redo.clear();
    const auto click=[&](int px,int py) {
        g.point_click_pending=true;g.point_click_x=px;g.point_click_y=py;
        handle_input_message(g.main,WM_LBUTTONUP,0,MAKELPARAM(px,py));
    };
    const int px=plot.left+(plot.right-plot.left)/3,py=plot.top+(plot.bottom-plot.top)/2;
    const auto input_revision=g.numerical_revision;
    g.measure_mode=false;g.pending_line=0;g.pending_marker=true;click(px,py);
    require(g.markers.empty() && g_undo.empty() && g.overview.snap_pending,"marker click creates neither a free-coordinate fallback nor an early undo");wait_snap();
    require(g.markers.size()==1 && g.markers[0].snapped && g.markers[0].channel>=0 &&
            std::abs(g.markers[0].y)<2 && g_undo.size()==1,"marker placement commits the original channel and exactly one undo action");
    const auto marker=g.markers[0];pop_undo();require(g.markers.empty(),"Undo removes asynchronous marker placement");
    pop_redo();require(g.markers.size()==1 && g.markers[0].x==marker.x && g.markers[0].y==marker.y,"Redo restores the exact snapped marker");
    g.pending_marker=false;g.measure_mode=true;click(px,py);wait_snap();
    require(g.point_groups.size()==1 && g.point_groups[0].points.size()==1 &&
            g.point_groups[0].points[0]==std::make_pair(marker.x,marker.y),"measurement point uses the same original Snap as the marker");
    g.measure_mode=false;g.pending_line=1;click(px,py);wait_snap();
    require(g.guides.size()==1 && g.guides.back().vertical && g.guides.back().value==marker.x,"vertical line snaps to the original time");
    g.pending_line=2;click(px,py);wait_snap();
    require(g.guides.size()==2 && !g.guides.back().vertical && g.guides.back().value==marker.y,"horizontal line snaps to the original amplitude");
    g.pending_line=0;const auto actions=g_undo.size();
    g.annotation_drag_kind=App::AnnotationDragKind::Marker;g.annotation_drag_index=0;g.annotation_drag_marker_before=marker;
    update_annotation_drag(plot.right-8,py);finish_annotation_drag(true);
    require(g.markers[0].x==marker.x && g.markers[0].y==marker.y && g_undo.size()==actions,
            "released marker drag waits for the original point without transient unsnapped coordinates");wait_snap();
    require(g.markers[0].snapped && g.markers[0].x!=marker.x && g_undo.size()==actions+1,
            "asynchronous marker move creates exactly one undo action");
    pop_undo();require(g.markers[0].x==marker.x && g.markers[0].y==marker.y,"Undo restores the marker before the original-source drag");
    g.annotation_drag_kind=App::AnnotationDragKind::Point;g.annotation_drag_index=0;g.annotation_drag_point_index=0;
    g.annotation_drag_point_before=g.point_groups[0].points[0];const auto point_before=g.annotation_drag_point_before;
    update_annotation_drag(plot.right-8,py);finish_annotation_drag(true);wait_snap();
    require(g.point_groups[0].points[0]!=point_before && g_undo.back().type==UndoAction::MOVE_POINT,"original-source point drag uses the shared undo path");
    pop_undo();require(g.point_groups[0].points[0]==point_before,"Undo restores the original measurement point");
    g.annotation_drag_kind=App::AnnotationDragKind::Guide;g.annotation_drag_index=0;g.annotation_drag_guide_before=g.guides[0];
    update_annotation_drag(plot.right-8,py);finish_annotation_drag(true);wait_snap();
    require(g.guides[0].value!=marker.x && g_undo.back().type==UndoAction::MOVE_LINE,"original-source line drag stores the original sample time");
    pop_undo();require(g.guides[0].value==marker.x,"Undo restores the guide after original-source drag");
    g.pending_marker=true;click(px+80,py);handle_input_message(g.main,WM_KEYDOWN,VK_ESCAPE,0);Sleep(10);poll_overview_snap();
    require(g.markers.size()==1 && !g.overview.snap_pending,"Escape cancels a pending native marker click");
    g.pending_marker=false;
    require(g.numerical_revision==input_revision && g.ds.time.data()==resident,"asynchronous annotation I/O preserves numerical input and resident arrays");
    g.channel_formulas[0]=L"-2*x+3";rebuild_formula_cache_from_state();draw_chart(dc,plot);
    require(request_overview_snap(x,3,accept),"affine original-source Snap starts with the displayed amplitude metric");wait_snap();
    require(accepted==3 && picked.value==(picked.channel==0 ? values[0][picked.sample]*(-2)+3 : values[1][picked.sample]),
            "original-source Snap applies the same negative affine arithmetic as the displayed curve");
    g.channel_formulas[0]=L"x";rebuild_formula_cache_from_state();draw_chart(dc,plot);
    g.visible[1]=0;require(synchronize_overview_viewport(880),"visibility changes request only the visible channel projection");wait();
    require(g.overview.channels==std::vector<std::size_t>{0},"hidden channels are excluded from projected storage");
    g.show_channel_legend=true;draw_chart(dc,plot);
    require(g_legend_items.size()==2,"ready overview rebuilds the common clickable channel legend");
    g.noise_threshold_enabled=true;draw_chart(dc,plot);
    require(!g.vvalid && !g.overview.source->processing_identity().empty() && g_legend_items.empty() && IsRectEmpty(&g_legend_box),
            "filter requests a processed source and clears stale raw legend regions while pending");
    wait();draw_chart(dc,plot);
    require(g.vvalid && !g.overview.source->processing_identity().empty(),"filtered overview publishes its own processed index");
    g.noise_threshold_enabled=false;g.channel_formulas[0]=L"x*x";rebuild_formula_cache_from_state();draw_chart(dc,plot);
    require(!g.vvalid && !g.overview.source->processing_identity().empty(),"nonlinear formula requests original-sample processing rather than transforming raw extrema");
    wait();draw_chart(dc,plot);bool squared=true;
    visit_overview_curve(0,.064,[&](auto point){const auto at=std::lower_bound(time.begin(),time.end(),point.time)-time.begin();
        squared=squared && at<static_cast<std::ptrdiff_t>(time.size()) && point.value==values[0][at]*values[0][at];});
    require(g.vvalid && squared,"nonlinear overview extrema and original close-up match squared source samples");
    require(request_overview_snap(x,y,accept),"nonlinear overview Snap reads the processed source");wait_snap();
    require(accepted==4 && picked.channel==0 && picked.value==values[0][picked.sample]*values[0][picked.sample],"nonlinear Snap publishes an exact transformed original sample");
    g.channel_formulas[0]=L"x";rebuild_formula_cache_from_state();g.stitch_time_gaps=true;
    require(std::fabs(stitched_time_from_raw(time.back())-20)<1e-8 &&
            std::fabs(raw_time_from_stitched(stitched_time_from_raw(time[12000]))-time[12000])<1e-8,
            "file-backed stitching removes the outage and reversibly maps original coordinates");
    require(g.ds.time.data()==resident && g.ds.rows()==3 && g.recording_source==source && g.numerical_revision>revision,
            "resident samples survive rendering while formula changes invalidate the numerical input");
    g.stitch_time_gaps=false;draw_chart(dc,plot);wait();draw_chart(dc,plot);
    require(request_overview_snap(x,y,accept),"file mutation fixture starts an original-source Snap");
    {std::ofstream changed(path,std::ios::app);changed<<"# source modified after request\n";}
    wait_snap();
    require(accepted==4 && g.overview.snap_error==lvm::RecordingError::SourceChanged && !g.overview.view &&
            !g.overview.index && !g.vvalid,"changed file cannot publish an original point or retain the obsolete overview");
    g_theme=saved_theme;SelectObject(dc,old);DeleteObject(bitmap);DeleteDC(dc);
    cancel_recording_overview();g.overview={};DestroyWindow(g.main);g.main=nullptr;
}

void resource_settings_and_load_ownership() {
    reset_document({"existing"},{0,1},{{2,3}});
    const auto inst=GetModuleHandleW(nullptr);
    WNDCLASSW cls{};cls.lpfnWndProc=SettingsProc;cls.hInstance=inst;cls.lpszClassName=L"ResourceSettingsRegression";
    RegisterClassW(&cls);
    for(const auto* language:{&kEn,&kRu}) {
        g_str=language;
        g.settings_wnd=CreateWindowExW(WS_EX_TOOLWINDOW,cls.lpszClassName,L"",WS_POPUP,0,0,540,748,nullptr,nullptr,inst,nullptr);
        require(g.settings_wnd!=nullptr,"resource settings can be created in both languages without visible windows");
        require(!GetDlgItem(g.settings_wnd,1800),"obsolete Light Mode control is absent in both languages");
        refresh_settings_controls();
        require(is_toggle_checked(GetDlgItem(g.settings_wnd,IDC_SET_MEMORY_AUTO)),"Auto checkbox is visibly checked when policy is automatic");
        require(!IsWindowEnabled(GetDlgItem(g.settings_wnd,IDC_SET_MEMORY_EDIT)),"Auto disables manual input");
        SendMessageW(g.settings_wnd,WM_COMMAND,MAKEWPARAM(IDC_SET_MEMORY_AUTO,BN_CLICKED),0);
        require(IsWindowEnabled(GetDlgItem(g.settings_wnd,IDC_SET_MEMORY_EDIT)) && !g.resource_policy.automatic,"manual budget is available from settings");
        require(!is_toggle_checked(GetDlgItem(g.settings_wnd,IDC_SET_MEMORY_AUTO)),"Auto checkbox clears in manual mode");
        SetDlgItemTextW(g.settings_wnd,IDC_SET_MEMORY_EDIT,L"1536");
        SendDlgItemMessageW(g.settings_wnd,IDC_SET_MEMORY_EDIT,WM_KEYDOWN,VK_RETURN,0);
        require(g.resource_policy.manual_mib==1536,"Enter applies the manual memory limit");
        RECT memory_rect{},axis_rect{},hotkeys_rect{};
        GetWindowRect(GetDlgItem(g.settings_wnd,IDC_SET_MEMORY_EDIT),&memory_rect);
        GetWindowRect(GetDlgItem(g.settings_wnd,IDC_SET_FRF_AXIS_Y_EDIT),&axis_rect);
        GetWindowRect(GetDlgItem(g.settings_wnd,IDC_SET_GROUP_HOTKEYS),&hotkeys_rect);
        require(memory_rect.top>axis_rect.bottom && memory_rect.bottom<hotkeys_rect.top,"memory controls do not overlap axes or hotkeys");
        SendMessageW(g.settings_wnd,WM_COMMAND,MAKEWPARAM(IDC_SET_MEMORY_AUTO,BN_CLICKED),0);
        require(g.resource_policy.automatic && g.resource_policy.manual_mib==1536,"Auto restores automatic admission and retains manual preference");
        require(is_toggle_checked(GetDlgItem(g.settings_wnd,IDC_SET_MEMORY_AUTO)),"Auto checkbox returns after switching back");
        SetDlgItemTextW(g.settings_wnd,IDC_SET_DISK_EDIT,L"4096");
        SendDlgItemMessageW(g.settings_wnd,IDC_SET_DISK_EDIT,WM_KEYDOWN,VK_RETURN,0);
        require(!g.disk_cache_unlimited && g.disk_cache_mib==4096 && g.resource_policy.automatic,
            "Enter applies the disk quota independently of Auto RAM in both languages");
        SendMessageW(g.settings_wnd,WM_COMMAND,MAKEWPARAM(IDC_SET_DISK_UNLIMITED,BN_CLICKED),0);
        require(g.disk_cache_unlimited && is_toggle_checked(GetDlgItem(g.settings_wnd,IDC_SET_DISK_UNLIMITED)) &&
            !IsWindowEnabled(GetDlgItem(g.settings_wnd,IDC_SET_DISK_EDIT)),"unlimited disk mode checks its control and disables manual input");
        SendMessageW(g.settings_wnd,WM_COMMAND,MAKEWPARAM(IDC_SET_DISK_UNLIMITED,BN_CLICKED),0);
        require(!g.disk_cache_unlimited && g.disk_cache_mib==4096 && IsWindowEnabled(GetDlgItem(g.settings_wnd,IDC_SET_DISK_EDIT)),
            "switching back from unlimited disk mode restores the remembered manual quota");
        RECT disk_rect{};GetWindowRect(GetDlgItem(g.settings_wnd,IDC_SET_DISK_EDIT),&disk_rect);
        require(disk_rect.top>memory_rect.bottom && disk_rect.bottom<hotkeys_rect.top,
            "disk controls fit between RAM controls and hotkeys in both languages");
        HWND cursor_size=GetDlgItem(g.settings_wnd,IDC_SET_POINT_CURSOR_SIZE);
        require(SendMessageW(cursor_size,CB_GETCOUNT,0,0)==static_cast<LRESULT>(std::size(point_cursor_sizes)),
            "cursor settings expose the supported sizes in both languages");
        SendMessageW(cursor_size,CB_SETCURSEL,0,0);
        SendMessageW(g.settings_wnd,WM_COMMAND,MAKEWPARAM(IDC_SET_POINT_CURSOR_SIZE,CBN_SELCHANGE),reinterpret_cast<LPARAM>(cursor_size));
        require(g.point_cursor_size==17,"choosing a smaller cursor applies it immediately");
        SendMessageW(cursor_size,CB_SETCURSEL,std::size(point_cursor_sizes)-1,0);
        SendMessageW(g.settings_wnd,WM_COMMAND,MAKEWPARAM(IDC_SET_POINT_CURSOR_SIZE,CBN_SELCHANGE),reinterpret_cast<LPARAM>(cursor_size));
        require(g.point_cursor_size==63,"choosing the largest cursor applies it immediately");
        SendMessageW(g.settings_wnd,WM_COMMAND,MAKEWPARAM(IDC_SET_POINT_CURSOR_RESET,BN_CLICKED),0);
        require(g.point_cursor_size==21 && SendMessageW(cursor_size,CB_GETCURSEL,0,0)==1,
            "cursor reset restores the current 21 px default and its selected entry");
        RECT cursor_rect{},client{};GetWindowRect(cursor_size,&cursor_rect);GetClientRect(g.settings_wnd,&client);
        POINT bottom{cursor_rect.right,cursor_rect.bottom};ScreenToClient(g.settings_wnd,&bottom);
        require(cursor_rect.top>hotkeys_rect.bottom && bottom.y<client.bottom,
            "cursor size settings sit below hotkeys without clipping in either language");
        DestroyWindow(g.settings_wnd);
    }
    g_str=&kEn;
    require(set_disk_cache_policy(false,2048),"settings checks restore the default disk quota");
    const auto path=test_dir/"reserved_load.lvm";
    {std::ofstream f(path);f<<"Time\tA\n0\t4\n1\t5\n2\t6\n";}
    g.main=CreateWindowExW(0,L"STATIC",L"Reserved load",WS_POPUP,0,0,640,480,nullptr,nullptr,inst,nullptr);
    auto budget=refresh_load_memory_budget();
    require(start_async_load_task(path.wstring()) && budget->reserved()>0,"loader owns its admission reservation");
    request_async_load_cancel();g_load_worker.join();
    require(budget->reserved()>0,"finished cancelled worker retains reservation while its result is queued");
    MSG result{};
    require(PeekMessageW(&result,g.main,WM_APP_ASYNC_LOAD_DONE,WM_APP_ASYNC_LOAD_DONE,PM_REMOVE)!=FALSE,"cancelled load posts a result");
    handle_loading_message(g.main,result.message,result.wParam,result.lParam);
    require(budget->reserved()==0 && g.ds.channels[0][0]==2,"cancelled load releases memory after discarding samples and preserves current document");
    require(start_async_load_task(path.wstring()),"new request is accepted after cancellation");
    g_load_worker.join();
    require(PeekMessageW(&result,g.main,WM_APP_ASYNC_LOAD_DONE,WM_APP_ASYNC_LOAD_DONE,PM_REMOVE)!=FALSE,"successful load posts its result");
    handle_loading_message(g.main,result.message,result.wParam,result.lParam);
    require(budget->reserved()==0 && g.ds.rows()==3 && g.recording_source && g.ds.channels[0][0]==4,
        "successful publication transfers source and data before releasing reservation");
    auto stale=std::make_unique<AsyncLoadResult>();stale->token=g.async_load_token-1;
    refresh_load_memory_budget();stale->memory_reservation=budget->reserve(1024);stale->ds.time.assign(128,0);
    handle_loading_message(g.main,WM_APP_ASYNC_LOAD_DONE,0,reinterpret_cast<LPARAM>(stale.release()));
    require(budget->reserved()==0 && g.ds.rows()==3,"stale load result frees its owned buffers without replacing document");
    DestroyWindow(g.main);g.main=nullptr;
}

void configurable_point_cursor() {
    reset_document({"A"},{0,1},{{0,1}});
    HDC screen=GetDC(nullptr),dc=CreateCompatibleDC(screen);HBITMAP bitmap=CreateCompatibleBitmap(screen,64,64);
    ReleaseDC(nullptr,screen);const auto old=SelectObject(dc,bitmap);
    struct Cleanup {HDC dc;HBITMAP bitmap;HGDIOBJ old;~Cleanup(){SelectObject(dc,old);DeleteObject(bitmap);DeleteDC(dc);}} cleanup{dc,bitmap,old};
    const COLORREF background=RGB(63,92,117);HBRUSH brush=CreateSolidBrush(background);
    const auto previous_theme=g_theme;
    std::array<HCURSOR,std::size(point_cursor_sizes)> light_cursors{};
    for(const auto* theme:{&kLightTheme,&kDarkTheme,&kLightTheme}) {
    g_theme=theme;
    const COLORREF ink=theme==&kDarkTheme ? RGB(255,255,255) : RGB(0,0,0);
    const COLORREF outline=theme==&kDarkTheme ? RGB(0,0,0) : RGB(255,255,255);
    for(int size:point_cursor_sizes) {
        require(set_point_cursor_size(size),"every offered cursor size is accepted");
        HCURSOR cursor=point_placement_cursor();ICONINFO info{};
        require(cursor && cursor==point_placement_cursor() && GetIconInfo(cursor,&info),"each cursor size reuses its owned native handle");
        const auto index=static_cast<std::size_t>(std::find(std::begin(point_cursor_sizes),std::end(point_cursor_sizes),size)-std::begin(point_cursor_sizes));
        if(theme==&kLightTheme) {
            require(!light_cursors[index] || cursor==light_cursors[index],"switching back to light theme reuses its cursor");
            light_cursors[index]=cursor;
        } else require(cursor!=light_cursors[index],"dark theme owns a separate inverted cursor for every size");
        const int dimension=size<=31 ? 32 : 64,center=dimension/2;
        require(info.xHotspot==static_cast<DWORD>(center) && info.yHotspot==static_cast<DWORD>(center),
            "all cursor sizes keep the click hotspot at the exact center");
        if(info.hbmMask)DeleteObject(info.hbmMask);
        if(info.hbmColor)DeleteObject(info.hbmColor);
        RECT canvas{0,0,64,64};FillRect(dc,&canvas,brush);DrawIconEx(dc,0,0,cursor,dimension,dimension,0,nullptr,DI_NORMAL);
        bool center_filled=true;
        for(int y=center-1;y<=center+1;++y)for(int x=center-1;x<=center+1;++x)
            center_filled=center_filled && GetPixel(dc,x,y)==ink;
        require(center_filled && GetPixel(dc,center+3,center)==background,
            "the slightly larger 3x3 center retains an open gap around the target");
        const int arm=center+(size-1)/2-2;
        require(GetPixel(dc,center,arm)==ink && GetPixel(dc,center+1,arm)==outline &&
            GetPixel(dc,center+2,arm)==background,"cursor arms and outline invert with the theme and stay one pixel wide");
        int left=64,top=64,right=-1,bottom=-1;
        for(int y=0;y<dimension;++y)for(int x=0;x<dimension;++x)if(GetPixel(dc,x,y)!=background) {
            left=std::min(left,x);top=std::min(top,y);right=std::max(right,x);bottom=std::max(bottom,y);
        }
        require(right-left+1==size && bottom-top+1==size,"the selected size matches the actual visible cursor bounds");
    }
    }
    g_theme=previous_theme;
    DeleteObject(brush);
    require(!set_point_cursor_size(0) && !set_point_cursor_size(18) && g.point_cursor_size==63,
        "unsupported cursor sizes cannot replace the current choice");
    require(set_point_cursor_size(49),"a nondefault size can be saved");save_runtime_settings_now();
    g.point_cursor_size=21;load_runtime_settings();require(g.point_cursor_size==49,"cursor size persists in INI");
    WritePrivateProfileStringW(L"ui",L"point_cursor_size",L"18",g_config_path.c_str());load_runtime_settings();
    require(g.point_cursor_size==21,"invalid saved cursor sizes fall back to 21 px");
    WritePrivateProfileStringW(L"ui",L"point_cursor_size",nullptr,g_config_path.c_str());load_runtime_settings();
    require(g.point_cursor_size==21,"missing saved cursor size defaults to 21 px");
    set_point_cursor_size(21);
}

void analysis_admission_and_publication() {
    std::vector<double> time(4096),x(4096),y(4096);
    for(std::size_t i=0;i<time.size();++i){time[i]=i/1024.0;x[i]=std::sin(.03125*i);y[i]=2*x[i];}
    reset_document({"x","y"},time,{x,y});g_frf_worker.clear_cache();
    g.main=CreateWindowExW(0,L"STATIC",L"Analysis budget",WS_POPUP,0,0,640,480,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    const auto revision=g.numerical_revision;set_resource_policy(false,64);
    g.ds.time.reserve(9000000); // Account capacity, even when the selected range is short.
    compute_spectrum_for_window(0,3.999,true);
    require(!g.spec_pending && !g.spec_valid && g.spec.error.find("resources")!=std::string::npos && g.ds.rows()==4096,
        "FFT refuses snapshot admission before allocation when resident capacities exhaust the manual budget");
    g.frf.inputs={0};g.frf.outputs={1};g.frf.options.segment_length=1000;
    compute_frf_from_current_source();
    require(!g.frf.pending && g.frf.result.error==lvm::FrfError::ResourceLimit && g.frf.options.segment_length==1000,
        "FRF input admission returns ResourceLimit without changing the configured segment length");
    std::vector<double>(g.ds.time).swap(g.ds.time);set_resource_policy(false,256);
    auto budget=refresh_load_memory_budget();
    compute_spectrum_for_window(0,3.999,true);
    std::optional<lvm::SpectrumWorker::Result> fft;const auto started=std::chrono::steady_clock::now();
    while(!(fft=g_spectrum_worker.take_result()) && std::chrono::steady_clock::now()-started<std::chrono::seconds(5))Sleep(1);
    require(fft && fft->spectrum.ok && fft->spectrum.memory_reservation,"a retry after restoring memory publishes an accounted FFT result");
    if(fft)apply_spectrum_result(std::move(fft->spectrum));
    fft.reset();
    require(g.spec_valid && !g.spec.memory_reservation && g.numerical_revision==revision,
        "FFT publication transfers accounting to document capacities without changing numerical input");
    compute_frf_from_current_source();const auto frf_started=std::chrono::steady_clock::now();
    while(g.frf.pending && std::chrono::steady_clock::now()-frf_started<std::chrono::seconds(5)){poll_frf_result();Sleep(1);}
    require(g.frf.result.ok && !g.frf.result.memory_reservation && g.frf.result.common().segment_length==1000,
        "FRF retry publishes unchanged L and transfers result ownership to the document");
    const auto retained=budget->reserved();
    require(retained>0 && retained<2*1024*1024,"the GUI worker cache is included in the shared ledger after publication");
    require(close_active_document(),"closing the document discards its idle worker input cache");
    const auto cleared=std::chrono::steady_clock::now();
    while(budget->reserved()!=0 && std::chrono::steady_clock::now()-cleared<std::chrono::seconds(5))Sleep(1);
    require(budget->reserved()==0,"discarding the last GUI prepared input releases the remaining reservation");
    DestroyWindow(g.main);g.main=nullptr;
}

void persistent_recording_cache() {
    reset_document({"existing"},{0,1},{{2,3}});
    const auto root=std::filesystem::absolute(test_dir/"managed_cache");
    std::filesystem::remove_all(root);configure_recording_disk_cache(root,1024ULL*1024*1024);
    {
        auto cache=recording_disk_cache();
        auto pending=cache->begin_write("1122334455667788",lvm::CacheKind::Overview,128ULL*1024*1024);
        require(!set_disk_cache_policy(false,64) && g.disk_cache_mib==2048 && cache->used_bytes()==128ULL*1024*1024,
            "reducing the disk quota below a live reservation is rejected without invalidating its lease");
        require(set_disk_cache_policy(true,2048) && recording_disk_cache()==cache,
            "unlimited disk mode keeps the existing manager and active leases");
        auto larger=cache->begin_write("8877665544332211",lvm::CacheKind::Overview,96ULL*1024*1024);
        require(cache->used_bytes()==224ULL*1024*1024,"unlimited disk mode admits another bounded output reservation");
    }
    require(set_disk_cache_policy(false,64),"disk quota can shrink once pending outputs release their leases");
    {
        bool denied=false;
        try { recording_disk_cache()->begin_write("1122334455667788",lvm::CacheKind::Overview,65ULL*1024*1024); }
        catch(const lvm::RecordingFailure& e){denied=e.error==lvm::RecordingError::ResourceLimit;}
        require(denied,"the selected disk quota is enforced on actual cache admission");
    }
    require(set_disk_cache_policy(false,2048),"cache admission checks restore the default disk quota");
    const auto path=std::filesystem::absolute(test_dir/"cached_scan.lvm");
    {std::ofstream out(path);out<<"Time\tA\n";for(int i=0;i<10000;++i)out<<i<<'\t'<<i%17<<'\n';}
    g.main=CreateWindowExW(0,L"STATIC",L"Cached scan",WS_POPUP,0,0,640,480,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    const auto revision=g.numerical_revision;auto budget=refresh_load_memory_budget();
    const auto take_scan=[&] {
        g_load_worker.join();MSG message{};
        require(PeekMessageW(&message,g.main,WM_APP_ASYNC_SCAN_DONE,WM_APP_ASYNC_SCAN_DONE,PM_REMOVE)!=FALSE,"background scan posts a cache-aware result");
        hide_loading();g.async_load_stage=AsyncLoadStage::None;g.async_load_cancel_flag.reset();
        return std::unique_ptr<AsyncScanResult>(reinterpret_cast<AsyncScanResult*>(message.lParam));
    };
    require(start_async_scan_task(path.wstring()),"new asynchronous scan starts under the document memory budget");auto fresh=take_scan();
    require(fresh && fresh->ok && !fresh->index_from_disk_cache && fresh->index && fresh->index->memory_reservation,"first GUI scan persists an admitted index");
    require(start_async_scan_task(path.wstring()),"repeat GUI scan starts");auto hit=take_scan();
    require(hit && hit->ok && hit->index_from_disk_cache && hit->range_start==fresh->range_start && hit->range_end==fresh->range_end &&
        hit->index->checkpoints.back().offset==fresh->index->checkpoints.back().offset,"repeat GUI scan restores parser state and bounds from disk");
    const auto baseline=document_data_memory_bytes();g.source_scan_index=hit->index;
    require(document_data_memory_bytes()==baseline && budget->reserved()==fresh->index->memory_bytes()+hit->index->memory_bytes(),"admitted ScanIndex is counted through its reservation without duplicating resident accounting");
    g.recording_source=lvm::RecordingSource::from_file(path,{hit->range_start,hit->range_end},{1},hit->index);
    fresh.reset();hit.reset();require(budget->reserved()==g.source_scan_index->memory_bytes(),"GUI document and source retain one shared admission after queued scan results are discarded");
    require(request_recording_overview({},lvm::AnalysisRange::selected(9980,9999),{0},64),"internal overview without an explicit path uses the common managed cache");
    const auto wait=[&] {const auto start=std::chrono::steady_clock::now();while(g.overview.pending && std::chrono::steady_clock::now()-start<std::chrono::seconds(10)){poll_recording_overview();Sleep(1);}};
    wait();require(!g.overview.error && g.overview.index && g.overview.view && g.overview.view->sample_count==20,"managed background hierarchy publishes a close-up of original samples");
    const auto used=recording_disk_cache()->used_bytes();g.overview.index.reset();g.overview.view.reset();
    require(request_recording_overview({},lvm::AnalysisRange::selected(20,29),{0},64),"managed hierarchy can be requested again after discarding a view");wait();
    require(!g.overview.error && g.overview.view && g.overview.view->sample_count==10 && recording_disk_cache()->used_bytes()==used,"repeated GUI overview reuses the persisted hierarchy");
    require(g.numerical_revision==revision && g.ds.channels[0][0]==2,"cache and view requests preserve numerical revision and original active samples");
    cancel_recording_overview();g_overview_worker.trim_cache(0);g.overview={};g.recording_source.reset();g.source_scan_index.reset();
    require(budget->reserved()==0,"discarding managed GUI views, sources and idle cache releases all shared reservations");
    const auto bad_root=test_dir/"cache-as-file";{std::ofstream out(bad_root);out<<"not a directory";}
    configure_recording_disk_cache(bad_root,1024ULL*1024*1024);bool resource_error=false;
    try{recording_disk_cache();}catch(const lvm::RecordingFailure& e){resource_error=e.error==lvm::RecordingError::ResourceLimit;}
    require(resource_error,"unavailable managed cache directory has a typed resource error");
    require(start_async_scan_task(path.wstring()),"optional GUI persistence failure still permits bounded source scanning");auto fallback=take_scan();
    require(fallback && fallback->ok && !fallback->index_from_disk_cache && g.ds.channels[0][0]==2 && g.numerical_revision==revision,
        "unavailable disk cache preserves scan result and current numerical document");fallback.reset();
    require(budget->reserved()==0,"discarding a scan without persistence also releases index admission");
    g.recording_source=lvm::RecordingSource::from_file(path,{0,9999},{1});
    require(request_recording_overview({},lvm::AnalysisRange::selected(20,29),{0},64),"unavailable common cache falls back to a private bounded overview cache");wait();
    require(!g.overview.error && g.overview.view && g.overview.view->sample_count==10,"private fallback publishes original samples");
    const auto private_root=recording_overview_cache()->directory();
    require(recording_disk_cache()==recording_overview_cache(),"fallback scan indexes and overviews share one process disk quota");
    auto pinned=g.overview.index;cancel_recording_overview();g_overview_worker.trim_cache(0);g.overview={};
    configure_recording_disk_cache({},2ULL*1024*1024*1024);
    require(std::filesystem::exists(private_root),"temporary cache survives until the final index lease is released");
    pinned.reset();
    require(!std::filesystem::exists(private_root),"temporary cache removes owned files after the final lease without persistent accumulation");
    DestroyWindow(g.main);g.main=nullptr;configure_recording_disk_cache({},2ULL*1024*1024*1024);
}

void persistent_filter_continuations() {
    const auto path=std::filesystem::absolute(test_dir/"persistent-filter.txt");
    constexpr std::size_t count=30000;
    {std::ofstream out(path);out<<std::setprecision(17)<<"Time\tA\tB\n";
        for(std::size_t i=0;i<count;++i)out<<i*.001+(i>=15000 ? 2 : 0)<<'\t'
            <<(i==14000 ? std::numeric_limits<double>::quiet_NaN() : std::sin(i*.017))<<'\t'
            <<(i==14500 ? std::numeric_limits<double>::infinity() : std::cos(i*.021))<<'\n';}
    reset_document({"previous"},{0,1},{{1,2}});
    auto data=lvm::read_lvm_file(path);
    require(apply_loaded_dataset(std::move(data),path.wstring(),false,.001,true),"persistent filter source opens");
    configure_recording_disk_cache(std::filesystem::absolute(test_dir/"filter-state-cache"));
    g.noise_threshold_enabled=true;g.noise_threshold_mode=FilterModeBandPass;
    g.noise_threshold_topology=FilterTopologyLinkwitzRiley;g.noise_threshold_min=10;g.noise_threshold_max=100;
    FilterSettings settings{FilterModeBandPass,FilterTopologyLinkwitzRiley,10,100,.001};
    const auto expected_a=filter_signal(g.ds.time,g.ds.channels[0],settings);
    const auto expected_b=filter_signal(g.ds.time,g.ds.channels[1],settings);
    lvm::RecordingReadRequest read;read.channels={0,1};read.block_rows=17;
    auto source=processed_recording_source(true,.001,refresh_load_memory_budget());
    require(source->replay(read,[](const auto&,const auto&){})==count,"successful full replay creates continuation coverage");
    std::filesystem::path stored;
    for(const auto& entry:std::filesystem::directory_iterator(recording_disk_cache()->directory()))
        if(entry.path().extension()==".filter")stored=entry.path();
    require(!stored.empty() && std::filesystem::file_size(stored)<2ULL*1024*1024,"filter states persist within the shared disk allowance");
    read.range=lvm::AnalysisRange::selected(g.ds.time[13995],g.ds.time[15005]);read.channels={1,0};
    const auto verify=[&](const auto& candidate) {
        std::vector<double> a,b;candidate->replay(read,[&](const auto&,const auto& values){
            b.insert(b.end(),values[0].begin(),values[0].end());a.insert(a.end(),values[1].begin(),values[1].end());});
        bool same=a.size()==1011 && b.size()==1011;
        const auto equal=[](double x,double y){return x==y || (std::isnan(x) && std::isnan(y));};
        for(std::size_t i=0;same && i<a.size();++i)same=equal(a[i],expected_a[13995+i]) && equal(b[i],expected_b[13995+i]);
        require(same,"restored filter states preserve NaN/Inf, gap resets, reordered channels and block boundaries exactly");
    };
    g.processed_source.reset();g.processed_source_origin.reset();
    auto restored=processed_recording_source(true,.001,refresh_load_memory_budget());verify(restored);
    auto tiny_budget=std::make_shared<lvm::MemoryBudget>();tiny_budget->configure(1,0,1);
    g.processed_source.reset();g.processed_source_origin.reset();
    verify(processed_recording_source(true,.001,tiny_budget));
    // Test the artifact itself, so an unnoticed fallback cannot pass by merely
    // recalculating the same prefix. Include a checkpoint ending on NaN.
    {
        auto cache=std::make_shared<lvm::DiskCache>(std::filesystem::absolute(test_dir/"portable-filter-state-cache"));
        std::vector<FilterCheckpoint> saved;
        FilterCheckpoint state;state.time=g.ds.time[14000];state.channels={0,1};
        const std::vector<double> prefix(g.ds.time.begin(),g.ds.time.begin()+14001);
        for(const auto& channel:g.ds.channels) {
            FilterStream filter(settings);filter.process(prefix,std::vector<double>(channel.begin(),channel.begin()+14001));
            state.filters.push_back(std::move(filter));
        }
        saved.push_back(std::move(state));
        const auto raw=g.recording_source;
        save_filter_checkpoints(cache,raw,"portable-test",.001,saved,nullptr);
        auto unknown_cadence=settings;unknown_cadence.sample_step=0;std::vector<FilterCheckpoint> loaded;
        require(load_filter_checkpoints(cache,raw,"portable-test",unknown_cadence,512,nullptr,loaded) &&
            unknown_cadence.sample_step==.001 && loaded.size()==1 && loaded[0].channels==saved[0].channels &&
            loaded[0].filters[0].continuation()==saved[0].filters[0].continuation() &&
            loaded[0].filters[1].continuation()==saved[0].filters[1].continuation(),
            "portable cache restores exact biquads, reset state, previous time and previously unknown cadence");
        auto wrong_cadence=settings;wrong_cadence.sample_step=.002;
        require(!load_filter_checkpoints(cache,raw,"portable-test",wrong_cadence,512,nullptr,loaded),
            "cache cannot supply states from a different known filter cadence");
        save_filter_checkpoints(cache,raw,"portable-test",.001,saved,nullptr);
        std::atomic<bool> stop{true};bool cancelled_cache=false;
        try{load_filter_checkpoints(cache,raw,"portable-test",settings,512,&stop,loaded);}
        catch(const lvm::RecordingFailure& error){cancelled_cache=error.error==lvm::RecordingError::Cancelled;}
        require(cancelled_cache,"optional state-cache load propagates cancellation");
    }
    std::atomic<bool> cancelled{true};bool cancellation=false;
    try{restored->replay(read,[](const auto&,const auto&){},&cancelled);}catch(const lvm::RecordingFailure& error){cancellation=error.error==lvm::RecordingError::Cancelled;}
    require(cancellation,"cancelled filtered replay does not bypass cancellation via persistent states");
    // Corruption must fall back to the exact causal prefix, never bad samples.
    for(const auto& entry:std::filesystem::directory_iterator(recording_disk_cache()->directory()))
        if(entry.path().extension()==".filter")stored=entry.path();
    {std::fstream damaged(stored,std::ios::in|std::ios::out|std::ios::binary);damaged.seekp(24);damaged.put('\x7f');}
    g.processed_source.reset();g.processed_source_origin.reset();
    auto fallback=processed_recording_source(true,.001,refresh_load_memory_budget());verify(fallback);
    g.noise_threshold_max=150;rebuild_formula_cache_from_state();
    auto changed=processed_recording_source(true,.001,refresh_load_memory_budget());
    require(changed->processing_identity()!=fallback->processing_identity(),"a different filter recipe cannot reuse the previous continuation states");
    {std::ofstream append(path,std::ios::app);append<<"# changed source\n";}
    bool stale=false;try{restored->replay(read,[](const auto&,const auto&){});}catch(const lvm::RecordingFailure& error){stale=error.error==lvm::RecordingError::SourceChanged;}
    require(stale,"persistent continuation never makes a changed file appear current");
}

void background_filtered_resident_view() {
    const auto path=std::filesystem::absolute(test_dir/"resident-filter-view.txt");
    constexpr std::size_t rows=131073;
    {std::ofstream out(path);out<<std::setprecision(17)<<"Time\tA\tB\n";
        for(std::size_t i=0;i<rows;++i) {
            const double t=i ? i*.001+(i>=60000 ? 2 : 0) : -6.9388939039072284e-18;
            const double a=i==70000 ? std::numeric_limits<double>::quiet_NaN() : std::sin(i*.017);
            out<<t<<'\t'<<a<<'\t'<<(i==71000 ? std::numeric_limits<double>::infinity() : 2*a)<<'\n';
        }}
    reset_document({"previous"},{0,1},{{1,2}});
    g.main=CreateWindowExW(0,L"STATIC",L"Resident filter",WS_POPUP,0,0,1000,650,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    auto data=lvm::read_lvm_file(path);
    // Reopening after discovery must keep exactly the same endpoints, including
    // section-offset cancellation near zero as in the real test1.lvm.
    auto scan=std::make_shared<lvm::ScanIndex>();double low=0,high=0;std::string scan_error;
    require(lvm::scan_time_bounds(path,low,high,scan_error,nullptr,scan.get()),"near-zero resident filter fixture scans");
    g.cached_scan_path=path.wstring();g.cached_scan_index=scan;g.cached_scan_valid=true;
    require(low==data.time.front() && high==data.time.back(),"cached scan and resident filter endpoints agree exactly");
    // Deliberately distinct from the full-file median: the existing resident
    // renderer used this GUI cadence and the worker must preserve it.
    constexpr double step=.0008;
    require(apply_loaded_dataset(std::move(data),path.wstring(),false,step,true),"resident filter fixture opens a full replayable document");
    require(!g.overview.render_enabled && g.ds.rows()==rows,"unfiltered resident fixture keeps the immediate renderer");
    g.channel_formulas[1]=L"-2*x+1";rebuild_formula_cache_from_state();
    g.noise_threshold_enabled=true;g.noise_threshold_mode=FilterModeBandPass;
    g.noise_threshold_topology=FilterTopologyButterworth;g.noise_threshold_min=20;g.noise_threshold_max=100;
    FilterSettings settings{g.noise_threshold_mode,g.noise_threshold_topology,20,100,step};
    const auto expected_a=filter_signal(g.ds.time,g.ds.channels[0],settings);
    auto transformed=g.ds.channels[1];for(auto& v:transformed)v=-2*v+1;
    const auto expected_b=filter_signal(g.ds.time,transformed,settings);
    const auto original_time=g.ds.time;
    const auto* resident=g.ds.time.data();const auto numerical=g.numerical_revision;
    HDC dc=CreateCompatibleDC(nullptr);HBITMAP bitmap=CreateBitmap(1000,650,1,32,nullptr);const auto old=SelectObject(dc,bitmap);
    const RECT plot{60,40,940,570};draw_time(dc,plot);
    require(g.overview.render_enabled && g.overview.pending && !g.vvalid && g.recording_rows==rows,
        "large resident filter paint submits background processing and records the full sample count");
    require(g.filtered_channel_cache[0].empty() && g.filtered_channel_cache[1].empty(),
        "paint does not synchronously filter whole resident channels");
    const auto first_generation=g.overview.generation;draw_time(dc,plot);
    require(g.overview.generation==first_generation,"repainting a pending filter does not restart its build");
    const auto wait=[&] {const auto started=std::chrono::steady_clock::now();
        while(g.overview.pending && std::chrono::steady_clock::now()-started<std::chrono::seconds(15)){poll_recording_overview();Sleep(1);}
        require(!g.overview.pending && !g.overview.error,"background filtered view completes successfully");};
    wait();draw_time(dc,plot);
    const auto index=g.overview.index;const auto source=g.overview.source;const auto ready_generation=g.overview.generation;
    require(index->disk_bytes()==0,"admitted resident filtering builds a RAM hierarchy without a duplicate disk timeline");
    draw_time(dc,plot);
    require(g.vvalid && !g.overview.pending && g.overview.index==index && g.overview.generation==ready_generation,
        "ready filtered repaint reuses its index without another filtering job");
    require(processed_recording_source()==source,"resident display and numerical input reuse the same unchanged filter cadence recipe");
    g.win_start=original_time[rows-40];g.win_end=original_time.back();draw_time(dc,plot);wait();draw_time(dc,plot);
    require(g.overview.index==index && g.overview.source==source && g.overview.view->sample_count==40,
        "deep zoom reuses the processed hierarchy and requests exact original sample positions");
    bool exact=true;std::size_t samples=0;
    for(const auto& bucket:g.overview.view->buckets) {
        exact=exact && bucket.sample_count==1;
        if(bucket.sample_count!=1)continue;
        const auto i=static_cast<std::size_t>(bucket.first_sample);
        exact=exact && bucket.channels[0].first.value==expected_a[i] && bucket.channels[1].first.value==expected_b[i];++samples;
    }
    require(exact && samples==40,"asynchronous filtered Signal preserves resident Fs, affine formulas and gap resets exactly");
    lvm::RecordingReadRequest query;query.range=lvm::AnalysisRange::selected(original_time[69995],original_time[71005]);
    query.channels={1,0};query.block_rows=17;
    std::vector<double> replay_a,replay_b;
    source->replay(query,[&](const auto&,const auto& values){
        replay_b.insert(replay_b.end(),values[0].begin(),values[0].end());
        replay_a.insert(replay_a.end(),values[1].begin(),values[1].end());});
    bool continuation=replay_a.size()==1011 && replay_b.size()==1011;
    for(std::size_t i=0;continuation && i<replay_a.size();++i) {
        const auto equal=[](double a,double b){return a==b || (std::isnan(a) && std::isnan(b));};
        continuation=equal(replay_a[i],expected_a[69995+i]) && equal(replay_b[i],expected_b[69995+i]);
    }
    require(continuation,"filter checkpoints preserve NaN/Inf resets and exact values with reordered channels and 17-row blocks");
    const auto cache_budget=refresh_load_memory_budget();const auto before_trim=cache_budget->reserved();
    source->trim_processing_cache();
    require(before_trim>=cache_budget->reserved()+rows*2*8,
        "completed resident processing retains admitted values and explicit trim releases their full storage");
    auto full=query;full.range=lvm::AnalysisRange::entire();full.channels={0,1};full.block_rows=4096;
    const auto admitted_before_cancel=cache_budget->reserved();std::atomic<bool> cancel_cache{false};bool cancelled=false;
    try {source->replay(full,[&](const auto&,const auto&){cancel_cache.store(true);},&cancel_cache);}
    catch(const lvm::RecordingFailure& failure){cancelled=failure.error==lvm::RecordingError::Cancelled;}
    require(cancelled && cache_budget->reserved()==admitted_before_cancel,
        "cancelling a full resident filter pass publishes no partial RAM cache and releases its admission");
    bool trimmed_during_replay=false;std::size_t replayed_rows=0;
    source->replay(full,[&](const auto& time,const auto&){replayed_rows+=time.size();
        if(!trimmed_during_replay){source->trim_processing_cache();trimmed_during_replay=true;}});
    require(replayed_rows==rows && cache_budget->reserved()==admitted_before_cancel,
        "an active pass remains valid during trim and cannot repopulate an evicted RAM cache");
    auto constrained=std::make_shared<lvm::MemoryBudget>();constrained->configure(4ULL*1024*1024,0,4ULL*1024*1024);
    const auto saved_processed=g.processed_source,saved_overview_source=g.overview.source;
    g.processed_source.reset();g.overview.source.reset();
    const auto limited_source=processed_recording_source(true,step,constrained);
    g.processed_source=saved_processed;g.overview.source=saved_overview_source;
    bool limited_exact=true;std::size_t limited_rows=0;
    limited_source->replay(full,[&](const auto&,const auto& values) {
        for(std::size_t i=0;i<values[0].size();++i,++limited_rows) {
            const auto equal=[](double a,double b){return a==b || (std::isnan(a) && std::isnan(b));};
            limited_exact=limited_exact && equal(values[0][i],expected_a[limited_rows]) && equal(values[1][i],expected_b[limited_rows]);
        }
    });
    require(limited_exact && limited_rows==rows && constrained->reserved()==2ULL*1024*1024,
        "denying full processed RAM retention preserves every filtered value and holds only admitted continuation state");
    replay_a.clear();replay_b.clear();
    source->replay(query,[&](const auto&,const auto& values){
        replay_b.insert(replay_b.end(),values[0].begin(),values[0].end());
        replay_a.insert(replay_a.end(),values[1].begin(),values[1].end());});
    continuation=replay_a.size()==1011 && replay_b.size()==1011;
    for(std::size_t i=0;continuation && i<replay_a.size();++i) {
        const auto equal=[](double a,double b){return a==b || (std::isnan(a) && std::isnan(b));};
        continuation=equal(replay_a[i],expected_a[69995+i]) && equal(replay_b[i],expected_b[69995+i]);
    }
    require(continuation,"uncached continuation after RAM eviction matches cached filtered values across missing values and gaps");
    source->trim_processing_cache();
    std::promise<void> executor_entered,executor_release;auto released=executor_release.get_future().share();
    auto busy=std::async(std::launch::async,[&] {
        lvm::analysis_executor().run(1,1,[&](std::size_t){executor_entered.set_value();released.wait();});
    });
    executor_entered.get_future().wait();
    lvm::RecordingSource::ResidentColumns snapshot;
    try {snapshot=source->prepare_resident_columns();}
    catch(...) {executor_release.set_value();busy.get();throw;}
    executor_release.set_value();busy.get();
    bool prepared_exact=snapshot && snapshot->size()==2;
    for(std::size_t i=0;prepared_exact && i<rows;++i) {
        const auto equal=[](double a,double b){return a==b || (std::isnan(a) && std::isnan(b));};
        prepared_exact=equal((*snapshot)[0][i],expected_a[i]) && equal((*snapshot)[1][i],expected_b[i]);
    }
    require(prepared_exact,"busy shared executor uses exact sequential resident preparation with formulas, gaps and nonfinite input");
    const auto held_snapshot=cache_budget->reserved();source->trim_processing_cache();
    require(cache_budget->reserved()==held_snapshot,"an active resident snapshot retains its admission across cache eviction");
    snapshot.reset();require(cache_budget->reserved()+rows*2*8<=held_snapshot,
        "releasing the final resident snapshot frees the admitted channel arrays");
    std::atomic<bool> prepare_cancel{true};bool prepare_cancelled=false;
    try {source->prepare_resident_columns(&prepare_cancel);}catch(const lvm::RecordingFailure& e){prepare_cancelled=e.error==lvm::RecordingError::Cancelled;}
    require(prepare_cancelled,"resident preparation reports typed cancellation before allocating or publishing data");
    require(g.recording_source->resident_data() && g.recording_source->resident_data()->time.data()==resident &&
        g.ds.rows()==2 && g.numerical_revision==numerical &&
        g.filtered_channel_cache[0].empty() && g.filtered_channel_cache[1].empty(),
        "navigation retains original allocations in the immutable owner without synchronous filtered caches");
    // FFT/FRF must use complete RAM originals after the UI Dataset became seed.
    lvm::Dataset control;control.ok=true;control.names=g.ds.names;
    control.time.assign(original_time.begin()+2000,original_time.begin()+6096);
    control.channels.emplace_back(expected_a.begin()+2000,expected_a.begin()+6096);
    control.channels.emplace_back(expected_b.begin()+2000,expected_b.begin()+6096);
    const auto expected_spectrum=lvm::compute_spectrum(control,0);
    change_analysis_range(lvm::AnalysisRange::selected(control.time.front(),control.time.back()));
    set_mode(AnalysisMode::FFT);
    const auto finish_spectrum=std::chrono::steady_clock::now();
    while(g.spec_pending && std::chrono::steady_clock::now()-finish_spectrum<std::chrono::seconds(15)) {
        if(auto result=g_spectrum_worker.take_result())apply_spectrum_result(std::move(result->spectrum));else Sleep(1);
    }
    require(g.spec_valid && g.spec.n==4096 && !g.spec.disk && g.spec.freqs==expected_spectrum.freqs &&
        g.spec.amp==expected_spectrum.amp,"resident filtered FFT uses every original RAM sample and matches the old resident control exactly");
    g.frf.inputs={0};g.frf.outputs={1};g.frf.apply_processing=true;g.frf.options.segment_length=2048;
    lvm::FrfInput pair;pair.time=control.time;pair.reference=control.channels[0];pair.response=control.channels[1];
    const auto expected_frf=lvm::analyze_frf(pair,g.frf.options);
    g.mode=AnalysisMode::FRF;compute_frf_from_current_source();
    const auto finish_frf=std::chrono::steady_clock::now();
    while(g.frf.pending && std::chrono::steady_clock::now()-finish_frf<std::chrono::seconds(15)){poll_frf_result();Sleep(1);}
    require(!g.frf.pending && g.frf.result.ok && g.frf.result.common().sample_count==4096,
        "resident filtered FRF completes the full selected region after ownership transfer");
    const auto& actual=g.frf.result.common();bool matching=actual.frequencies==expected_frf.frequencies &&
        actual.valid==expected_frf.valid && actual.coherence_valid==expected_frf.coherence_valid &&
        actual.reference_amplitude_valid==expected_frf.reference_amplitude_valid;
    for(std::size_t i=0;matching && i<actual.valid.size();++i) {
        if(actual.valid[i])matching=actual.transfer[i]==expected_frf.transfer[i];
        if(actual.coherence_valid[i])matching=matching && actual.coherence[i]==expected_frf.coherence[i];
        if(actual.reference_amplitude_valid[i])matching=matching && actual.reference_amplitude[i]==expected_frf.reference_amplitude[i];
    }
    require(matching,"filtered RAM H1, coherence, reference spectrum, grids and masks exactly match the resident method");
    set_mode(AnalysisMode::Time);
    g.noise_threshold_max=200;recompute_transforms_from_state();draw_time(dc,plot);
    require(g.overview.pending && g.overview.source!=source && !g.vvalid,
        "new filter recipe invalidates the old filtered display before publication");
    cancel_recording_overview();Sleep(10);poll_recording_overview();
    require(!g.overview.pending && !g.vvalid,"cancelling a replacement filter never publishes an outdated graph");
    g.noise_threshold_enabled=false;recompute_transforms_from_state();draw_time(dc,plot);wait();draw_time(dc,plot);
    require(g.vvalid && g.overview.source==g.recording_source && g.recording_source->resident_backed() && g.recording_rows==rows,
        "disabling the filter restores the original overview without discarding the resident recording");
    require(move_resident_recordings_to_disk() && g.ds.rows()==2 && g.recording_rows==rows,
        "a resident document using the background renderer can still release original arrays under memory pressure");
    draw_time(dc,plot);wait();draw_time(dc,plot);
    require(g.vvalid && g.overview.source==g.recording_source && current_filter_sample_step()==step,
        "storage demotion preserves cadence and rebinds the asynchronous renderer to the new source");
    cancel_recording_overview();g_overview_worker.trim_cache(0);g.overview={};
    SelectObject(dc,old);DeleteObject(bitmap);DeleteDC(dc);DestroyWindow(g.main);g.main=nullptr;
}

void adaptive_opening_and_cache() {
    reset_document({"previous"},{0,1},{{7,8}});
    const auto path=std::filesystem::absolute(test_dir/"adaptive-open.txt");
    {std::ofstream out(path);out<<std::setprecision(17)<<"Time\tCopy\tA\tB\n";
        for(int i=0;i<131072;++i){const auto t=i/2048.;const double a=std::sin(i*.07);out<<t<<'\t'<<t<<'\t'<<a<<'\t'<<2*a<<'\n';}}
    g.main=CreateWindowExW(0,L"STATIC",L"Adaptive opening",WS_POPUP,0,0,1000,650,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    const auto receive=[&]{g_load_worker.join();MSG message{};
        require(PeekMessageW(&message,g.main,WM_APP_ASYNC_SCAN_DONE,WM_APP_ASYNC_SCAN_DONE,PM_REMOVE),"adaptive metadata result arrives");
        handle_loading_message(g.main,message.message,message.wParam,message.lParam);};
    require(set_resource_policy(false,512) && start_async_scan_task(path.wstring(),true),"adaptive discovery can retain original samples under sufficient budget");receive();
    require(g.ds.rows()==131072 && g.ds.channel_count()==2 && !g.overview.render_enabled && g.recording_source,
        "adaptive discovery publishes a complete resident document and drops the full-record time duplicate");
    const auto control=g.ds.time;const auto channel=g.ds.channels[0];
    auto resources=current_analysis_resources();
    require(resources.memory_bytes>384ULL*1024*1024 && resources.cache_memory_bytes>64ULL*1024*1024,
        "manual resources expand numerical admission and input retention above historical caps");
    g_frf_worker.clear_cache();
    const auto numerical_before=g.numerical_revision;
    const auto cadence_before=current_filter_sample_step();
    g.ds.time.reserve(9000000);
    require(set_resource_policy(false,64) && g.overview.render_enabled && g.ds.rows()==2 && g.recording_rows==131072,
        "lowering budget demotes a valid full resident recording instead of blocking subsequent disk analysis");
    require(g.numerical_revision==numerical_before && current_filter_sample_step()==cadence_before,
        "storage demotion preserves numerical revision and the original filter cadence");
    require(set_resource_policy(false,64) && start_async_scan_task(path.wstring(),true),"same adaptive discovery accepts a constrained policy");receive();
    // This small recording still fits. Explicit source discovery exercises the
    // complementary storage path without manufacturing huge test data.
    require(g.ds.time==control && g.ds.channels[0]==channel,"adaptive opening leaves every source value unchanged");
    require(start_async_scan_task(path.wstring(),false),"bounded source discovery remains available internally");receive();
    require(g.ds.rows()==2 && g.overview.render_enabled && g.recording_rows==131072,"source opening retains exact N independently of its seed");
    const auto wait=[&]{const auto begin=std::chrono::steady_clock::now();while(g.overview.pending && std::chrono::steady_clock::now()-begin<std::chrono::seconds(20)){poll_recording_overview();Sleep(1);}require(!g.overview.pending && !g.overview.error,"cached source projection finishes");};
    wait();g.win_start=10;g.win_end=12;synchronize_overview_viewport(300);wait();const auto first=g.overview.view;
    g.win_start=20;g.win_end=22;synchronize_overview_viewport(300);wait();
    g.win_start=10;g.win_end=12;synchronize_overview_viewport(300);wait();
    require(g.overview.view==first,"revisited viewport reuses the immutable cached view without reading original leaves again");
    const auto revision=g.numerical_revision;set_resource_policy(false,64);
    require(g.numerical_revision==revision,"resource changes do not become numerical input revisions");
    lvm::Spectrum stale;stale.ok=true;stale.recording_source=g.recording_source;
    {std::ofstream out(path,std::ios::app);out<<"# source changed after RAM calculation\n";}
    apply_spectrum_result(std::move(stale));
    require(!g.spec_valid && !g.spec.error.empty() && g.ds.rows()==2,
        "RAM result source stamp is checked again at UI publication without replacing the recording");
    cancel_recording_overview();g_overview_worker.trim_cache(0);g.overview={};DestroyWindow(g.main);g.main=nullptr;
}

void demotion_edge_cases() {
    reset_document({"previous"},{0,1},{{7,8}});
    const auto path=std::filesystem::absolute(test_dir/"demotion-step.txt");
    {std::ofstream out(path);out<<"Time\tA\n0\t0\n";for(int i=1;i<17;++i)out<<i+9<<'\t'<<i<<'\n';}
    g.main=CreateWindowExW(0,L"STATIC",L"Demotion edge",WS_POPUP,0,0,1000,650,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    auto data=lvm::read_lvm_file(path);const auto expected=precompute_global_gap_step(data.time);
    require(apply_loaded_dataset(std::move(data),path.wstring(),false,0,false),"ordinary resident fixture opens before lazy cadence is computed");
    g.cached_global_gap_step=0;g.cached_global_gap_step_ready=false;
    require(move_resident_recordings_to_disk() && g.ds.rows()==2,"uncached resident fixture can be demoted under memory pressure");
    require(expected==1 && current_filter_sample_step()==expected,
        "demotion before first filter freezes cadence from the full recording rather than its two-sample seed");
    cancel_recording_overview();g_overview_worker.trim_cache(0);g.overview={};DestroyWindow(g.main);g.main=nullptr;
}

void unified_source_opening(const std::filesystem::path& external={},bool opening_only=false) {
    reset_document({"previous"},{0,1},{{7,8}});
    const auto path=external.empty() ? std::filesystem::absolute(test_dir/"whole_source.txt") : std::filesystem::absolute(external);
    if(external.empty()) {
        std::ofstream out(path);out<<std::setprecision(17)<<"Time\tTimeCopy\tA\tB\tLate\n";
        for(int i=0;i<5000;++i) {
            const double t=i/1024.0+(i>=2500 ? 100 : 0);
            const double a=i<100 ? t : std::sin(i*.07);
            out<<t<<'\t'<<t<<'\t'<<a<<'\t'<<2*a;
            if(i>=500)out<<'\t'<<std::cos(i*.11);
            out<<'\n';
        }
    }
    g.main=CreateWindowExW(0,L"STATIC",L"Whole source opening",WS_POPUP,0,0,1000,650,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    if(!external.empty())require(set_resource_policy(false,64),"external full-source opening runs with a 64 MiB data budget");
    const auto started=std::chrono::steady_clock::now();
    // The small fixture explicitly exercises the source API; external large
    // files use the actual automatic interactive decision without mode flags.
    require(external.empty() ? start_async_scan_task(path.wstring()) : load_path_interactive(path.wstring()),"opening starts a full-source job");
    require(g.async_load_stage==AsyncLoadStage::ScanningRange,"large opening scans the source without a fragment prompt");
    g_load_worker.join();MSG message{};
    require(PeekMessageW(&message,g.main,WM_APP_ASYNC_SCAN_DONE,WM_APP_ASYNC_SCAN_DONE,PM_REMOVE)!=FALSE,"opening posts its metadata result");
    std::cout<<"ScanIndex disk hit="<<reinterpret_cast<AsyncScanResult*>(message.lParam)->index_from_disk_cache<<std::endl;
    handle_loading_message(g.main,message.message,message.wParam,message.lParam);
    require(g.async_load_stage==AsyncLoadStage::None && g.overview.render_enabled && g.recording_source && g.ds.rows()==2,
        "ordinary opening publishes the entire source with only two seed rows and no fragment dialog");
    require(g.win_start==g.source_scan_index->range_start && g.win_end==g.source_scan_index->range_end && !g.current_file_partial,
        "initial view spans the complete original recording");
    const auto wait_view=[&] {
        const auto start=std::chrono::steady_clock::now();
        while(g.overview.pending && std::chrono::steady_clock::now()-start<std::chrono::minutes(40)){poll_recording_overview();Sleep(5);}
        if(g.overview.error)std::cout<<"Overview error="<<static_cast<int>(*g.overview.error)<<std::endl;
        require(!g.overview.pending && !g.overview.error && g.overview.view && g.cached_global_gap_step_ready,"full source view and original global gap step publish");
    };
    wait_view();
    PROCESS_MEMORY_COUNTERS_EX memory{};memory.cb=sizeof(memory);
    GetProcessMemoryInfo(GetCurrentProcess(),reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&memory),sizeof(memory));
    std::cout<<"Source opening: bytes="<<std::filesystem::file_size(path)<<", N="<<g.recording_rows<<", seconds="
        <<std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count()<<", seed_rows="<<g.ds.rows()
        <<", peak_ws_mib="<<memory.PeakWorkingSetSize/1048576.0<<", private_mib="<<memory.PrivateUsage/1048576.0<<std::endl;
    require(g.overview.index->sample_count()==g.recording_rows,"display sample count describes the full source, not its seed");
    if(opening_only) {
        cancel_recording_overview();g.overview={};DestroyWindow(g.main);g.main=nullptr;return;
    }
    if(external.empty()) {
        require(g.ds.source_columns==std::vector<std::size_t>{2,3,4},"whole-source discovery removes true time copies and keeps prefix-matching and late columns");
        auto original=lvm::read_lvm_file(path);lvm::drop_duplicate_time_channels(original,original.raw_time);
        require(g.ds.names==original.names,"source names match the original complete-file parser after duplicate removal");
        require(g.overview.gaps.size()==1 && g.overview.gaps[0].right-g.overview.gaps[0].left>100,"gap details retain the original outage");
        std::vector<double> times(5000);for(int i=0;i<5000;++i)times[i]=i/1024.0+(i>=2500 ? 100 : 0);
        require(g.cached_global_gap_step==precompute_global_gap_step(times),"streaming global gap rule equals the old complete-vector rule");
    }
    double a=0,b=0;bool selected=false;
    require(current_fft_source_window(a,b,selected) && !selected && a==g.data_t0 && b==g.data_t1,"FFT defaults to the entire recording");
    zoom_at(.75,.2);
    double a2=0,b2=0;bool selected2=false;current_fft_source_window(a2,b2,selected2);
    require(a==a2 && b==b2 && !selected2,"zoom leaves the common analysis area unchanged");
    const double begin=external.empty() ? 103 : g.source_scan_index->checkpoints.at(g.source_scan_index->checkpoints.size()*3/5).adjusted_time;
    const double end=external.empty() ? 104 : begin+.2;
    require(change_analysis_range(lvm::AnalysisRange::selected(begin,end)),"a numerical interval outside the seed can be selected");
    const auto undo_count=g_undo.size();pop_undo();
    require(!has_fft_window(),"Undo restores the entire analysis range");pop_redo();
    require(has_fft_window() && g.fft_window_start==begin && g_undo.size()==undo_count,"Redo restores the exact numerical interval");
    g.visible.assign(g.ds.channel_count(),0);g.visible[0]=1;
    if(external.empty()) {
        // Supersede an actual file-reading FFT before publishing the new area.
        change_analysis_range(lvm::AnalysisRange::entire());compute_spectrum_from_current_source();
        change_analysis_range(lvm::AnalysisRange::selected(begin,end));
    }
    compute_spectrum_from_current_source();
    const auto fft_start=std::chrono::steady_clock::now();std::optional<lvm::SpectrumWorker::Result> fft;
    while(!(fft=g_spectrum_worker.take_result()) && std::chrono::steady_clock::now()-fft_start<std::chrono::minutes(2))Sleep(1);
    require(fft && fft->generation==g.spec_generation && fft->spectrum.ok,"FFT reads the chosen interval outside the seed in the background");
    lvm::LoadOptions read;read.use_time_window=true;read.time_start=begin;read.time_end=end;read.scan_index=g.source_scan_index;
    auto control=lvm::read_lvm_file(path,read);lvm::drop_duplicate_time_channels(control,control.raw_time);
    // Select by physical column: dropping time duplicates in a short control
    // interval can differ from the complete-recording metadata discovery.
    const auto physical=g.ds.source_columns[0];
    const auto found=std::find(control.source_columns.begin(),control.source_columns.end(),physical);
    require(found!=control.source_columns.end(),"reference reader contains the selected physical signal");
    lvm::Dataset input;input.ok=true;input.time=control.time;input.names={g.ds.names[0]};input.channels={control.channels.at(found-control.source_columns.begin())};
    const auto expected=lvm::compute_spectrum(input,0);
    require(expected.ok && fft->spectrum.n==expected.n && fft->spectrum.freqs==expected.freqs && fft->spectrum.amp==expected.amp,
        "file-backed FFT grid and every amplitude match the original vector calculation exactly");
    apply_spectrum_result(std::move(fft->spectrum));fft.reset();
    if(g.ds.channel_count()>1) {
        g.frf.inputs={0};g.frf.outputs={1};g.frf.options.segment_length=128;
        compute_frf_from_current_source();const auto frf_start=std::chrono::steady_clock::now();
        while(g.frf.pending && std::chrono::steady_clock::now()-frf_start<std::chrono::minutes(2)){poll_frf_result();Sleep(1);}
        require(g.frf.result.ok && g.frf.source_start==begin && g.frf.source_end==end && g.frf.from_selection,
            "streaming FRF uses the same selected interval outside the displayed seed");
        if(external.empty()) {
            const auto response=std::find(control.source_columns.begin(),control.source_columns.end(),g.ds.source_columns[1]);
            lvm::FrfBatchInput oracle;oracle.time=control.time;oracle.references={input.channels[0]};
            oracle.responses={control.channels.at(response-control.source_columns.begin())};
            auto batch=lvm::analyze_frf_batch(std::move(oracle),g.frf.options);
            const auto& frf=batch.common();
            const auto& actual=g.frf.result.common();
            require(frf.ok && actual.frequencies==frf.frequencies,"selected-source FRF frequency grid matches the vector control");
            require(actual.valid==frf.valid,"selected-source FRF H1 mask matches the vector control");
            require(actual.coherence_valid==frf.coherence_valid,"selected-source coherence mask matches the vector control");
            require(actual.reference_amplitude_valid==frf.reference_amplitude_valid,"selected-source reference spectrum mask matches the vector control");
            for(std::size_t i=0;i<frf.reference_amplitude.size();++i)
                require(actual.reference_amplitude[i]==frf.reference_amplitude[i] ||
                    (std::isnan(actual.reference_amplitude[i]) && std::isnan(frf.reference_amplitude[i])),"reference amplitude equals the vector control, including invalid bins");
            for(std::size_t i=0;i<frf.transfer.size();++i)if(frf.valid[i])
                require(actual.transfer[i]==frf.transfer[i],"valid selected-source complex H1 matches the vector control exactly");
            for(std::size_t i=0;i<frf.coherence.size();++i)if(frf.coherence_valid[i])
                require(actual.coherence[i]==frf.coherence[i],"valid selected-source coherence matches the vector control exactly");
        }
    }
    g.mode=AnalysisMode::Time;g.win_start=begin;g.win_end=end;
    synchronize_overview_viewport(512);wait_view();
    HDC screen=GetDC(nullptr),dc=CreateCompatibleDC(screen);HBITMAP image=CreateCompatibleBitmap(screen,800,500);auto old=SelectObject(dc,image);
    draw_chart(dc,{70,45,750,450});
    require(g.vvalid && g.vx0==begin && g.vx1==end,"source graph close-up is rendered from the requested original range");
    SelectObject(dc,old);DeleteObject(image);DeleteDC(dc);ReleaseDC(nullptr,screen);
    ExportOptions options;
    // Stream originals outside the seed, including cancellation/atomic preservation.
    const auto destination=test_dir/"seed_export.csv";{std::ofstream out(destination);out<<"keep";}
    options.selected_range=ExportRangeMode::Selected;options.apply_processing_to_data=false;
    std::atomic<bool> cancelled{true};
    require(!save_source_export(destination.wstring(),options,&cancelled),"cancelled streaming export returns no partial file");
    {std::ifstream preserved(destination);require(std::string((std::istreambuf_iterator<char>(preserved)),{})=="keep","cancelled streaming export preserves the previous destination");}
    require(save_tabular_export(destination.wstring(),options),"streaming export reads the selected originals outside the seed");
    const auto exported=lvm::read_lvm_file(destination);
    require(exported.ok && exported.time==control.time && exported.channels[0]==input.channels[0],"streamed selected export matches every original sample");
    require(!save_source_export(path.wstring(),options),"source export rejects overwriting its live source");
    if(!external.empty()) {
        ULONG_PTR picture_token=0;
        if(std::filesystem::file_size(path)>=20000000000ULL) {
            Gdiplus::GdiplusStartupInput startup;
            require(Gdiplus::GdiplusStartup(&picture_token,&startup,nullptr)==Gdiplus::Ok,"large-record PNG startup");
        }
        g.mode=AnalysisMode::FFT;change_analysis_range(lvm::AnalysisRange::entire());
        const auto started_fft=std::chrono::steady_clock::now();compute_spectrum_from_current_source();
        std::optional<lvm::SpectrumWorker::Result> full;
        while(!(full=g_spectrum_worker.take_result()) && std::chrono::steady_clock::now()-started_fft<std::chrono::minutes(90))Sleep(5);
        require(full && full->generation==g.spec_generation && full->spectrum.ok && full->spectrum.disk,"full real-file FFT selects bounded disk computation");
        require(full->spectrum.n==static_cast<int>(g.recording_rows) && full->spectrum.bin_count()==g.recording_rows/2+1,"full real-file FFT keeps every sample and exact bin count");
        if(std::filesystem::file_size(path)>=10000000000ULL) {
            std::vector<double> peak;
            full->spectrum.read_amplitudes(0,g.recording_rows*31/2048,1,peak);
            const double error=std::abs(peak[0]-1.0);
            std::cout<<"Synthetic full FFT analytic peak error="<<error<<std::endl;
            require(error<1e-5,"complete synthetic FFT preserves the analytic sinusoid amplitude");
        }
        GetProcessMemoryInfo(GetCurrentProcess(),reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&memory),sizeof(memory));
        std::cout<<"Full disk FFT: N="<<full->spectrum.n<<", channels="<<full->spectrum.names.size()<<", seconds="
            <<std::chrono::duration<double>(std::chrono::steady_clock::now()-started_fft).count()<<", result_disk_mib="<<full->spectrum.disk->disk_bytes/1048576.0
            <<", peak_ws_mib="<<memory.PeakWorkingSetSize/1048576.0<<", private_mib="<<memory.PrivateUsage/1048576.0<<std::endl;
        apply_spectrum_result(std::move(full->spectrum));full.reset();g.freq_start=0;g.freq_end=g.spec.nyquist;
        HDC target=CreateCompatibleDC(nullptr);draw_chart(target,{50,40,700,400});DeleteDC(target);
        require(g.vvalid && g.vx1==g.spec.nyquist,"complete real-file disk spectrum renders without resident amplitudes");
        if(picture_token)require(save_png((test_dir/"large_disk_fft.png").wstring()),"full large disk FFT exports a real rendered PNG");
        if(std::filesystem::file_size(path)>=10000000000ULL && g.ds.channel_count()==8) {
            g.spec={};g.spec_valid=false;g.mode=AnalysisMode::Time;
            g.frf.inputs={0};g.frf.outputs={1,2,3,4,5,6,7};g.frf.options.segment_length=2048;g.frf.options.remove_mean=false;
            const auto started_frf=std::chrono::steady_clock::now();compute_frf_from_current_source();
            while(g.frf.pending && std::chrono::steady_clock::now()-started_frf<std::chrono::minutes(30)){poll_frf_result();Sleep(5);}
            require(g.frf.result.ok && g.frf.result.responses.size()==7 && !g.frf.from_selection,"full large-file FRF computes all seven responses through the GUI worker");
            double error=0;
            for(std::size_t c=0;c<7;++c)for(auto bin:{31u,67u}) {
                const auto& response=g.frf.result.responses[c];
                require(response.valid[bin] && response.coherence_valid[bin],"synthetic excited FRF bins remain valid");
                error=std::max(error,std::abs(response.transfer[bin]-std::complex<double>(c+2.0,0)));
                error=std::max(error,std::abs(response.coherence[bin]-1));
            }
            require(error<1e-9,"full large-file H1 and coherence match analytic gains");
            GetProcessMemoryInfo(GetCurrentProcess(),reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&memory),sizeof(memory));
            std::cout<<"Full GUI FRF: N="<<g.recording_rows<<", L=2048, responses=7, seconds="
                <<std::chrono::duration<double>(std::chrono::steady_clock::now()-started_frf).count()<<", peak_ws_mib="<<memory.PeakWorkingSetSize/1048576.0<<", analytic_error="<<error<<std::endl;
            if(picture_token){g.mode=AnalysisMode::FRF;require(save_png((test_dir/"large_frf.png").wstring()),"full seven-response large FRF exports a real rendered PNG");}
        }
        if(picture_token)Gdiplus::GdiplusShutdown(picture_token);
        change_analysis_range(lvm::AnalysisRange::selected(begin,end));g.mode=AnalysisMode::Time;
    }
    if(external.empty()) {
        g.channel_formulas[0]=L"x*x";rebuild_formula_cache_from_state();
        g.noise_threshold_enabled=true;g.noise_threshold_mode=FilterModeLowPass;g.noise_threshold_max=80;g.noise_threshold_min=0;
        const auto processed=processed_recording_source();lvm::RecordingReadRequest request;request.channels={0};request.range=lvm::AnalysisRange::selected(begin,end);request.block_rows=17;
        std::vector<double> processed_time,processed_values;
        processed->replay(request,[&](const auto& time,const auto& values){processed_time.insert(processed_time.end(),time.begin(),time.end());processed_values.insert(processed_values.end(),values[0].begin(),values[0].end());});
        auto whole=lvm::read_lvm_file(path);lvm::drop_duplicate_time_channels(whole,whole.raw_time);
        auto samples=whole.channels[0];for(auto& value:samples)value*=value;
        std::vector<double> spacing;for(std::size_t i=1;i<whole.rows();++i)spacing.push_back(whole.time[i]-whole.time[i-1]);
        FilterSettings settings{FilterModeLowPass,FilterTopologyButterworth,0,80,lvm::typical_sample_spacing(spacing)};
        const auto filtered=filter_signal(whole.time,samples,settings);
        const auto lo=std::lower_bound(whole.time.begin(),whole.time.end(),begin)-whole.time.begin(),hi=std::upper_bound(whole.time.begin(),whole.time.end(),end)-whole.time.begin();
        require(processed_time==control.time && processed_values==std::vector<double>(filtered.begin()+lo,filtered.begin()+hi),"processed source preserves nonlinear formula, full filter warm-up and states across 17-row blocks");
        options.apply_processing_to_data=true;require(save_source_export(destination.wstring(),options),"streaming export supports processed selected data");
        const auto applied=lvm::read_lvm_file(destination);require(applied.ok && applied.channels[0]==processed_values,"processed export uses the same source as analysis and overview");
        const auto project=test_dir/"source_project.AMSig";require(save_project_file(project.wstring()),"source project streams all original channels with processing as settings");
        const auto restored=lvm::read_lvm_file(project);require(restored.ok && restored.rows()==whole.rows() && restored.time==whole.time,"source project contains the complete original timeline, not seed rows");
        auto project_data=restored;lvm::drop_duplicate_time_channels(project_data,project_data.raw_time);
        bool same=project_data.channels.size()==whole.channels.size();
        for(std::size_t c=0;same && c<whole.channels.size();++c){same=project_data.channels[c].size()==whole.channels[c].size();
            for(std::size_t i=0;same && i<whole.rows();++i)same=project_data.channels[c][i]==whole.channels[c][i] || (std::isnan(project_data.channels[c][i]) && std::isnan(whole.channels[c][i]));}
        require(same,"source project preserves all original channel samples, including NaN");
        auto resources=current_analysis_resources();
        auto disk=lvm::compute_disk_spectrum(processed,request,{g.ds.names[0]},resources);
        lvm::Dataset oracle;oracle.ok=true;oracle.time=processed_time;oracle.channels={processed_values};oracle.names={g.ds.names[0]};
        const auto reference=lvm::compute_spectrum(oracle,0);std::vector<double> amplitudes;disk.read_amplitudes(0,0,disk.bin_count(),amplitudes);
        require(disk.ok && amplitudes==reference.amp[0],"filtered-source disk FFT matches the vector calculation exactly");
        apply_spectrum_result(std::move(disk));g.mode=AnalysisMode::FFT;g.freq_start=0;g.freq_end=g.spec.nyquist;
        HDC target=CreateCompatibleDC(nullptr);draw_chart(target,{50,40,700,400});DeleteDC(target);
        require(g.vvalid && g.vx1==g.spec.nyquist,"disk spectrum uses the production GUI renderer");
        options.format=ExportFileFormat::Csv;options.selected_range=ExportRangeMode::Whole;
        require(save_source_export(destination.wstring(),options),"spectrum export streams exact disk bins");
        const auto spectrum_file=lvm::read_lvm_file(destination);require(spectrum_file.ok && spectrum_file.frequency_axis && spectrum_file.rows()==reference.freqs.size(),"streamed disk spectrum reopens with the exact bin count");
        options.save_mode=ExportSaveMode::Project;
        require(start_source_export((test_dir/"async_source_project.AMSig").wstring(),options),"source project export runs in the background");
        cancel_source_export();shutdown_source_exports();
        require(!std::filesystem::exists(test_dir/"async_source_project.AMSig"),"cancelled source project worker publishes no destination");
        hide_loading();g.mode=AnalysisMode::Time;
        const auto invalid=test_dir/"formula_nonfinite.txt";{std::ofstream out(invalid);out<<"0\t0\n1\tnan\n2\tinf\n";}
        const auto previous_source=g.recording_source;
        g.recording_source=lvm::RecordingSource::from_file(invalid,{0,2},{1});g.noise_threshold_enabled=false;
        g.channel_formulas[0]=L"1/(1+abs(x))";rebuild_formula_cache_from_state();
        auto nonfinite=processed_recording_source();lvm::RecordingReadRequest nonfinite_read;nonfinite_read.channels={0};std::vector<double> checked;
        nonfinite->replay(nonfinite_read,[&](const auto&,const auto& values){checked.insert(checked.end(),values[0].begin(),values[0].end());});
        require(checked.size()==3 && checked[0]==1 && std::isnan(checked[1]) && std::isnan(checked[2]),"nonlinear source formulas retain GUI NaN/Inf policy even when the expression could turn infinity into a finite value");
        g.recording_source=previous_source;
    }
    cancel_recording_overview();g_spectrum_worker.cancel();g_frf_worker.cancel();g_frf_worker.clear_cache();
    g.overview={};DestroyWindow(g.main);g.main=nullptr;
}

void global_gap_markers_setting() {
    reset_document({"A"},{0,1,101},{{0,1,2}});
    mark_active_document_saved();
    g.file_name=L"first.lvm";g.gap_details_visible=true;g.gap_details_duration=100;
    g.visible_gap_markers.push_back({{10,10,20,100},100,99});
    DocumentState second=static_cast<const DocumentState&>(g);second.file_name=L"second.lvm";
    g.inactive_documents.push_back(std::move(second));
    g.gap_click_pending=true;g.gap_click_index=0;
    const auto instance=GetModuleHandleW(nullptr);
    WNDCLASSW cls{};cls.lpfnWndProc=SettingsProc;cls.hInstance=instance;cls.lpszClassName=L"GlobalGapsSettingsRegression";
    require(RegisterClassW(&cls)!=0,"global gap setting has a native settings window");
    g.settings_wnd=CreateWindowExW(0,cls.lpszClassName,L"",WS_POPUP,0,0,540,748,nullptr,nullptr,instance,nullptr);
    struct Cleanup {~Cleanup(){if(g.settings_wnd)DestroyWindow(g.settings_wnd);g.settings_wnd=nullptr;}} cleanup;
    require(g.settings_wnd!=nullptr,"global gap settings controls can be created");
    const auto click=[&] {
        SendMessageW(g.settings_wnd,WM_COMMAND,MAKEWPARAM(IDC_SET_GAP_MARKERS,BN_CLICKED),
            reinterpret_cast<LPARAM>(GetDlgItem(g.settings_wnd,IDC_SET_GAP_MARKERS)));
    };
    const auto revision=g.numerical_revision,serial=g.plot_analysis_serial;
    click();
    require(!g.show_gap_markers && !is_toggle_checked(GetDlgItem(g.settings_wnd,IDC_SET_GAP_MARKERS)),
        "the settings checkbox disables the application-wide gap preference");
    require(!g.gap_details_visible && g.visible_gap_markers.empty() && !g.gap_click_pending && g.gap_click_index==-1 &&
        !g.inactive_documents[0].gap_details_visible && g.inactive_documents[0].visible_gap_markers.empty(),
        "disabling gaps clears active and inactive cards and pending gap interactions");
    require(!g.project_dirty && !g.inactive_documents[0].project_dirty && g_undo.empty() &&
        g.numerical_revision==revision && g.plot_analysis_serial==serial,
        "a global display preference does not dirty documents, enter Undo or invalidate numerical caches");
    require(switch_to_document(1) && !g.show_gap_markers,"hidden gaps stay hidden when switching to another open file");
    click();
    require(g.show_gap_markers && switch_to_document(1) && g.show_gap_markers,
        "enabling gaps applies equally when returning to an already open file");
    require(!g.gap_details_visible,"reenabling global gaps does not restore stale per-document detail cards");
    set_gap_markers_visible(false);
    apply_export_metadata_from_comments({"[graph_settings]","show_gap_markers=1"});
    require(!g.show_gap_markers,"legacy projects cannot enable globally hidden gap markers");
    set_gap_markers_visible(true);
    apply_export_metadata_from_comments({"[graph_settings]","show_gap_markers=0"});
    require(g.show_gap_markers,"legacy projects cannot disable globally visible gap markers");
    ExportOptions options;std::ostringstream metadata;
    write_export_metadata(metadata,options,false,0,101,false,{0});
    require(metadata.str().find("show_gap_markers")==std::string::npos,
        "project and export graph metadata no longer stores an application preference");
    set_gap_markers_visible(false);save_runtime_settings_now();g.show_gap_markers=true;load_runtime_settings();
    require(!g.show_gap_markers,"globally hidden gaps persist in the existing INI key across a settings reload");
    const auto snapshot=capture_settings_snapshot();set_gap_markers_visible(true);apply_settings_snapshot(snapshot);
    require(g.show_gap_markers,"restoring document history cannot overwrite the global gap preference");
    set_gap_markers_visible(false);mark_active_document_saved();
    begin_loaded_document();
    require(!has_data() && !g.show_gap_markers,"starting a new file retains the shared preference");
    static_cast<DocumentState&>(g)=g.inactive_documents.back();
    while(has_data()) {
        mark_active_document_saved();
        require(close_active_document() && !g.show_gap_markers,"closing any file, including the last, preserves the global gap preference");
    }
}

void multiple_open_documents() {
    reset_document({"first"}, {0, 1, 2}, {{1, 2, 3}});
    g.file_name = L"first.lvm";
    g.source_path = L"C:\\data\\first.lvm";
    g.win_start = .5; g.win_end = 1.5;
    set_fft_window(.25,1.75);
    g.mode = AnalysisMode::FFT;
    g.channel_colors = {RGB(1, 2, 3)};

    DocumentState second;
    second.ds.ok = true;
    second.ds.names = {"second"};
    second.ds.time = {10, 11, 12};
    second.ds.raw_time = second.ds.time;
    second.ds.channels = {{7, 8, 9}};
    second.visible = {1};
    second.channel_labels = {L"second"};
    second.channel_colors = {RGB(9, 8, 7)};
    second.data_t0 = second.win_start = 10;
    second.data_t1 = second.win_end = 12;
    second.file_name = L"second.lvm";
    second.source_path = L"C:\\data\\second.lvm";
    second.mode = AnalysisMode::FRF;
    second.spec.freqs={1,2,3};second.spec.amp={{1,2,3}};second.spec.ok=true;
    second.spec_valid=second.spec_attempted=true;
    second.frf.result.responses.resize(1);second.frf.result.responses[0].transfer={{1,0},{2,0}};
    second.frf.attempted=true;
    g.inactive_documents.push_back(std::move(second));

    trim_document_analysis_caches(1);
    require(g.inactive_documents[0].spec.freqs.empty() && !g.inactive_documents[0].spec_attempted &&
            g.inactive_documents[0].frf.result.responses.empty() && !g.inactive_documents[0].frf.attempted,
            "inactive numerical results are evicted within the shared cache budget");
    require(g.inactive_documents[0].ds.rows()==3 && g.inactive_documents[0].mode==AnalysisMode::FRF,
            "cache eviction preserves document samples and analysis settings");

    require(open_document_count() == 2, "two datasets are tracked as independent open documents");
    require(switch_to_document(1), "switches to an inactive document");
    require(g.file_name == L"second.lvm" && g.mode == AnalysisMode::FRF && g.win_start == 10,
            "switch restores the selected document's analysis state and time range");
    require(g.channel_colors == std::vector<COLORREF>{RGB(9, 8, 7)},
            "switch restores per-document channel presentation without duplicating samples");
    require(!has_fft_window(),"the second document does not inherit the first document's analysis interval");
    require(switch_to_document(1), "switches back to the original document");
    require(g.file_name == L"first.lvm" && g.mode == AnalysisMode::FFT && g.win_start == .5,
            "original signal and FFT state survive a document round trip");
    require(has_fft_window() && g.fft_window_start==.25 && g.fft_window_end==1.75,"the first document restores its own common analysis interval");
    require(close_active_document() && open_document_count() == 1 && g.file_name == L"second.lvm",
            "closing one file keeps the remaining document open");
}
}

int main(int argc,char** argv) {
    std::filesystem::create_directories(test_dir);
    try {
        if((argc==3 || argc==4) && std::string(argv[1])=="--source-opening") {
            HANDLE job=nullptr;
            const bool opening_only=argc==4 && std::string(argv[3])=="--opening-only";
            if(opening_only)configure_recording_disk_cache(std::filesystem::absolute(test_dir/("opening-"+std::to_string(GetTickCount64()))));
            if(argc==4 && !opening_only) {
                require(std::string(argv[3])=="--commit-128","known process commit cap option");
                job=CreateJobObjectW(nullptr,nullptr);
                JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits{};
                limits.BasicLimitInformation.LimitFlags=JOB_OBJECT_LIMIT_PROCESS_MEMORY;
                limits.ProcessMemoryLimit=128ULL*1024*1024;
                require(job && SetInformationJobObject(job,JobObjectExtendedLimitInformation,&limits,sizeof(limits)) &&
                    AssignProcessToJobObject(job,GetCurrentProcess()),"128 MiB process commit cap is enforced by Windows Job Object");
                std::cout<<"Windows process commit cap: 128 MiB; data admission: Manual 64 MiB (not physical 8 GiB hardware)"<<std::endl;
            }
            unified_source_opening(std::filesystem::u8path(argv[2]),opening_only);
            g_spectrum_worker.shutdown();g_overview_worker.shutdown();g_frf_worker.shutdown();
            if(job)CloseHandle(job);
            std::cout<<checks<<" source opening checks passed\n";return 0;
        }
        document_history_and_save_state(); exports(); save_hotkeys(); channel_coefficient_fields(); point_display_defaults(); status_bar_text(); mode_button_text(); global_gap_markers_setting(); multiple_open_documents(); processing(); fft_recording_recovery();
        display_load_budget(); loading_window_ownership(); bounded_load_recovery(); document_source_and_resources(); background_document_overview(); overview_renderer(); resource_settings_and_load_ownership(); configurable_point_cursor(); analysis_admission_and_publication(); persistent_recording_cache(); filter_bound_crossing(); resident_envelope_and_history(); reopen_spectrum(); fft_selected_gap_range(); stitched_gap_regressions();
        persistent_filter_continuations();background_filtered_resident_view();adaptive_opening_and_cache();demotion_edge_cases();unified_source_opening();spectrum_visibility_cache();
        analysis_preempts_background_overview();
        user_axis_names_outside_plot();
        spectrum_pending_message();
        line_menu_theme();
        submenu_arrow_theme();
        curve_symbols_keep_solid_paths();
        channel_legend_visibility();
        shift_range_with_point_mode();analysis_range_edge_editing();analysis_range_edge_magnet();exact_line_dialog();offscreen_marker_lines();marker_value_readouts();playback_timeline_controls();routed_window_messages();
        measurement_label_units();
        additional_mode_hotkeys();frequency_view_controls();channel_panel_layout_regression();frf_filter_tab();
        frf_integration();
        frf_multi_channels();
        frf_gap_stitching();
        frf_loaded_document_defaults();
        streamed_frf_file_and_invalidation();
        bounded_formula_cache_selection();
        g_spectrum_worker.shutdown();
        g_overview_worker.shutdown();
        g_frf_worker.shutdown();
        require(!g_spectrum_worker.take_result(),"GUI exit joins the FFT caller before analysis pool teardown");
        std::cout << checks << " GUI integration checks passed\n";
        return 0;
    } catch(const std::exception& ex) {
        g_overview_worker.shutdown();
        g_spectrum_worker.shutdown();
        g_frf_worker.shutdown();
        std::cerr << "FAIL after " << checks << " checks: " << ex.what() << '\n';
        return 1;
    }
}
