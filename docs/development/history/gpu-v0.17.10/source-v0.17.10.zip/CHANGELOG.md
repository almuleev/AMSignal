# Changelog

## v0.17.8-cpu.2 (2026-10-21)

Проекты сохраняют условия повторного расчёта АЧХ: роли каналов, H1/Direct,
L, удаление среднего, порог опоры, сглаживание и границы отображения.
Метаданные экспорта содержат версию приложения и UTC-время; CSV АЧХ также
записывает запрошенный L и сглаживание. Сохранены CPU-изменения родительского
v0.17.8-cpu.1, включая исправление амплитуды опоры на Найквисте.
Полный набор ядра: 1405 утверждений; GUI: 7193, без ошибок.
Новых замеров производительности нет. Локальный тег исходников;
публикация и новый комплект EXE не выполнялись.
[Полный журнал RU/EN](docs/releases/v0.17.8-cpu.2.md).

Projects preserve FRF recalculation settings, channel roles, estimator,
requested L, mean removal, reference threshold, smoothing and view bounds.
Export metadata records the application version and UTC timestamp; FRF CSV
also records requested L and display smoothing. Includes the parent CPU
changes and Nyquist reference-amplitude correction. Full core: 1405 assertions;
GUI: 7193, all passed. No new performance measurements. Local source tag;
no publication or newly versioned executable package.

## v0.17.7 (2026-10-17)

Тематические меню и стрелки подменю, выровненные флажки ролей АЧХ,
контрастный прицел точек с размером по умолчанию 21 px. Фигуры различают
кривые для Ч/Б-печати при сплошных линиях и образцах легенды. Обновлены
иллюстрации RU/EN и регрессионные проверки. Новых замеров скорости нет;
EXE без цифровой подписи. [Полный журнал RU/EN](docs/releases/v0.17.7.md).

Themed popup menus and submenu arrows, centered FRF role checkmarks,
theme-aware point cursor with a 21 px default. Grayscale symbols identify
curves while paths and legend samples remain solid. Updated RU/EN images
and regression coverage. No new performance measurements; executables are
unsigned. See the full bilingual notes above.

## v0.17.6 (2026-10-17)

Документационный выпуск: новая главная с тремя режимами, полные RU/EN инструкции,
изображения без курсора, демонстрация двух опор и двух откликов, перенос окружения,
пояснения замеров скорости и обновлённое оформление GitHub. Исходники приложения
и тестов не изменены относительно v0.17.5; отдельные локальные правки не включены.
GUI/CLI пересобираются с версией 0.17.6. [Полный журнал RU/EN](docs/releases/v0.17.6.md).

Documentation release: refreshed three-mode main page, matching RU/EN guides,
cursor-free images, two-reference/two-response example, portability guidance,
benchmark conditions and GitHub presentation. Application and test sources are
unchanged from v0.17.5; separate local edits are excluded. GUI/CLI are rebuilt as
0.17.6. See the full bilingual notes above.

## v0.17.5 (2026-10-16)

Подробное описание: [v0.17.5, RU/EN](docs/releases/v0.17.5.md).
При переходе из Signal в FFT/АЧХ отменяется ненужный фоновый обзор,
сохраняются готовые index/view и рабочий поток. Отменённое уточнение
повторно запрашивается при возврате, готовый вид переиспользуется.
1357 core / 8654 GUI-проверки прошли; все 28 групп полных FFT/H1
в Auto и Manual 64 MiB совпали с эталоном. В контрольной паре с pending
overview первый FFT 8.3187 → 1.9168 с; это не универсальный процент.
Прежние +52% уточнены как эффект перекрытия задач, не регрессия ядра FFT.

FFT/FRF mode changes cancel unnecessary Signal overview work while retaining
ready index/view objects and the reusable worker. Cancelled refinement resumes
on return; ready views are reused. 1357 core / 8654 GUI checks passed, and all
28 complete FFT/H1 result groups matched the baseline in Auto/Manual 64 MiB.
One controlled pending-overview pair improved first FFT from 8.3187 to 1.9168 s;
this is not a universal speedup. The earlier +52% reflects overlapping tasks,
not an established FFT kernel regression. See the full bilingual notes.

## v0.17.4 (2026-10-16)

Подробное описание: [v0.17.4, RU/EN](docs/releases/v0.17.4.md).
Блок видимого диапазона оставлен только в «Каналах» Signal/FFT/АЧХ;
из «Точек» убраны скрытый блок, пустое место и лишняя прокрутка.
Удалены 20 неиспользуемых элементов: четыре функции, 13 полей и три таймера,
чистое сокращение — 76 строк производственного C++. Номера команд, тестовые
API и прежнее поведение legacy-команд сохранены. Обе штатные сборки успешны;
8619 GUI-проверок прошли, 11 PNG до/после совпали по SHA-256. Отдельный
идентичный снимок прошёл 1357 core-проверок. Новых замеров скорости нет.

Visible range controls now appear only in Channels across Signal/FFT/FRF;
Points has no hidden range reservation or extra scrolling. Removed twenty
unused elements: four functions, thirteen fields and three timers, reducing
production C++ by 76 lines. Command IDs, test APIs and legacy behavior are
retained. Standard builds and 8619 GUI checks passed; all eleven PNGs matched
byte for byte. An identical isolated snapshot passed 1357 core checks.
No new cleanup performance measurements; see the full bilingual release notes.

## v0.17.3 (2026-10-16)

Подробное описание: [v0.17.3, RU/EN](docs/releases/v0.17.3.md).
Общий видимый диапазон снизу в Signal/FFT/АЧХ; исправлены перекрытия правой
панели и перерисовка фильтра, включая резкий drag с удержанием. Выделенный
участок имеет контрастные подвижные границы, магнит к исходным отсчётам и
подпись; рабочая область не тонируется. Добавлены карточки значений маркеров,
настройка размера прицела, общий магнит, точная линия одним диалогом, общий
показ разрывов, отдельные лимиты RAM/диска и новые горячие клавиши S/F/R.
8601 GUI-проверка; новых сравнений производительности/10 GB/ПК 8 GiB нет.
Известные disk-регрессии v0.17.2 не объявляются исправленными; EXE не подписаны.

Shared bottom viewport controls across Signal/FFT/FRF; fixed panel overlaps
and slider rendering during abrupt held drags. Analysis bounds are draggable,
snap to original samples and preserve the working-area pixels. Marker cards,
cursor sizes, shared Magnet, one exact-line dialog, global gap markers,
independent RAM/disk budgets and S/F/R mode shortcuts. 8601 GUI checks;
no new performance/large-file claims. See the full bilingual release notes.

## v0.17.2 (2026-10-15)

Полное описание всех изменений после опубликованного rc.3, включая локальную
v0.17.1: [v0.17.2, RU/EN](docs/releases/v0.17.2.md).
Первое открытие строит metadata/ScanIndex одним проходом. RAM-фильтр пишет
допущенные обработанные колонки без копии времени; обзор может оставаться в
RAM. Используются общий executor, точный готовый Cadence и безопасное владение
при trim/отмене. Включены все исправления test1, Spectrum, точек, выделения,
таймлайна, склейки и меню из v0.17.1, очистка кода и инфраструктура SignPath.
На real test2 первое открытие 44,55 → 33,50 с; processed FFT/первый H1 быстрее.
Зафиксированы рост Peak WS ~429 MiB и оставшиеся disk-регрессии Manual 64 MiB;
универсального ускорения нет. Новые тесты 10 GB/ПК 8 GiB не проводились.
Сертификат ожидается: EXE не подписаны. Старые теги и выпуски не заменяются.

Includes every change since published rc.3 and the local v0.17.1 tag.
Cold discovery/indexing share one pass; admitted resident filtering and overview
avoid redundant copies/disk work and share the analysis executor. All v0.17.1
interaction, test1, cleanup and signing-infrastructure fixes are included.
See the bilingual notes for validation, RAM cost and confirmed disk slowdowns.
This release is unsigned; Foundation approval is pending.

## v0.17.1 (2026-10-14)

Подробное двуязычное описание: [v0.17.1](docs/releases/v0.17.1.md).
Полные RAM-оригиналы доступны фильтру/FFT/FRF без копирования; состояния
фильтра сохраняются между запусками. Исправлены точные границы test1,
сообщения Spectrum, курсор точек, Shift-выделение, таймлайн, сочетания меню,
локальная склейка и стиль диалога анализа. Удалён неиспользуемый код.
Добавлена инфраструктура SignPath; заявка отправлена, сертификат ещё ожидается.
Последние проверки: 1262 core / 1026 GUI, 25 signing checks, полные CLI/GUI.
Старые замеры/отчёты архивированы без удаления доказательств.

Full originals are shared without copies; filter continuations persist.
Fixed test1 endpoints and Signal/Spectrum interaction; removed dead code.
Free SignPath infrastructure is prepared, enrollment still pending.
See the bilingual notes for validation, measured readiness and limitations.

## v0.17.0-rc.3 (pre-release, 2026-10-14)

### RU

Полное описание изменений, измерений и ограничений:
[v0.17.0-rc.3](docs/releases/v0.17.0-rc.3.md).

- Исправлены плотные Signal/Spectrum, оранжевая заливка узких разрывов,
  исчезновение графика во время уточнения и галочка автоматического бюджета.
- AMSOIDX2 хранит исходное время на диске; разрывы и временные проходы FFT
  читают бинарный индекс. Склейка поддерживает дисковый источник, навигацию
  и исходный Snap с сохранением фактического времени анализа/экспорта.
- Auto использует доступные RAM/commit с системным резервом; удалены прежние
  потолки 8 GiB/2 GiB и дополнительный численный GUI-предел 384 MiB. Большая
  запись может целиком остаться в RAM; нехватка допуска выбирает блоки/диск.
  N/L, методика FFT/H1/coherence и накопление Welch сохраняются.
- Общий исполнитель растёт по физическим ядрам/affinity и бюджету до 32
  участников. FRF-кэш и четыре viewport адаптируются к памяти; idle планы
  других потоков безопасно вытесняются. Полный replayable документ может
  перейти на диск без изменения численной ревизии, обработки и разметки.
- Исправлены повторное заполнение очищенного FRF-кэша и владение queued
  входом, проверка точного N дисковой подготовки, аварийный fallback FFT,
  сохранение ещё не вычисленного Fs при демоции и публикация RAM FFT.
- Windows CLI получил адаптивный численный допуск и устранение лишней копии
  выбранного входа; его загрузчик остаётся резидентным. GUI-сборка принимает
  OutputDirectory, не требуя перезаписи запущенной программы.
- 1222 core / 881 GUI; 38 новых edge-проверок, повторные реальные 1,024 ГБ
  и полные синтетические 10 GB RAM/disk испытания с указанными условиями.
  Парное сравнение с 0.16.7: 22 численных случая и два полных GUI-прогона,
  побитовое совпадение. FRF ускорился, но выигрыша всех операций не заявляется.
- Область текущих испытаний — до 10 GB; 20 GB исключены. Физический ПК
  8 GiB не испытан, бюджеты не покрывают всю память процесса, дисковые
  операции требуют места/времени; больших Direct/Auto L и FAMOS обещаний нет.

### EN

Complete changes, measurements and limitations:
[v0.17.0-rc.3](docs/releases/v0.17.0-rc.3.md).

- Fixed dense Signal/Spectrum rendering, orange shading of narrow gaps,
  disappearing plots during refinement and the automatic-budget checkbox.
- AMSOIDX2 stores original timestamps on disk; gaps and FFT timeline passes
  use the binary index. Disk-source stitching supports navigation and exact
  Snap while preserving actual analysis/export timestamps.
- Auto uses available RAM/commit with system headroom; removed the former
  8 GiB/2 GiB and additional 384 MiB GUI caps. Large inputs can remain fully
  in RAM; insufficient admission selects blocks/disk. N/L, FFT/H1/coherence
  methodology and Welch accumulation are preserved.
- The shared executor grows within physical cores/affinity, work and memory,
  at most 32 participants. FRF/four-viewport caches adapt to admission; idle
  plans from other threads are safely evicted. Complete replayable documents
  can move to disk without changing numerical revision or user settings.
- Fixed stale FRF cache refills and queued-input ownership, exact disk-input
  count validation, fatal FFT fallback exceptions, uncached Fs demotion and
  RAM FFT source-version publication checks.
- Windows CLI has adaptive numerical admission and avoids an extra selected
  input copy; loading remains resident. GUI builds support OutputDirectory.
- 1222 core / 881 GUI checks; 38 new edge checks, repeated real 1.024 GB
  and complete synthetic 10 GB RAM/disk tests under documented conditions.
  Paired 0.16.7 comparison: 22 numerical cases and two full GUI runs match
  bitwise. FRF is faster; universal speedup is not claimed.
- Current test priority is ≤10 GB; 20 GB excluded. Physical 8 GiB hardware
  was not tested; budgets do not cover all process memory, disk work needs
  space/time, and large Direct/Auto L or FAMOS claims are not made.

## v0.17.0-rc.2 (pre-release)

### RU

Большие записи автоматически открываются целиком через дисковый обзор.
«Анализ → Вся запись / Участок / Взять видимый участок» задаёт общую область
FFT и FRF независимо от zoom. Удалены Light Mode из приветствия/настроек,
его флаги, обязательный диалог фрагмента и отдельная команда полного FRF
в меню «Вид». Старый ключ проекта игнорируется, устаревшие INI-ключи удаляются
при сохранении настроек; номера действующих команд сохранены.

- Общий immutable RecordingSource удерживает файл/ScanIndex и проверяет
  размер/mtime до/после чтения и перед публикацией. Две seed-строки служат
  только UI; N хранится отдельно. Полный состав каналов проверяется по всей
  записи, поздние столбцы и каналы, похожие на время только в начале, сохраняются.
- Overview хранит точные extrema/позиции/разрывы на диске. Zoom читает нужный
  уровень или оригиналы; Signal-Snap читает исходные отсчёты асинхронно.
  Отмена, смена документа, Undo/Redo и SourceChanged не публикуют устаревшую точку.
- Формулы и причинный фильтр используют общий обработанный источник для
  обзора, Snap, FFT/FRF и экспорта. Состояния biquad переносятся между блоками;
  участок прогревается от начала записи, Fs определяется по полной временной
  оси прежним точным правилом. Нелинейная огибающая строится по значениям,
  не преобразованием готовых min/max. Недействительные значения нелинейной
  формулы следуют GUI-правилу, включая конечные выражения от Inf.
- Полный FFT сохраняет N, сетку, интерполяцию, удаление DC, сжатие разрывов
  и нормировку. При недостаточном RAM-допуске выполняется tiled дисковый
  radix-2/Bluestein; усреднение FFT блоков не используется. Рабочий резерв
  24 MiB, численный максимум 384 MiB с сохранёнными планами; временный диск
  до 64 GiB с предварительной оценкой места. После расчёта остаются дисковые
  амплитуды и ограниченные summaries; неактивные результаты ограничены 2 GiB.
- FRF сохраняет Welch-перекрытие, порядок накопления Sxx/Syy/Sxy, общую FFT
  средней опоры, H1/coherence, слабую маску и точное определение Fs.
  Spectrum/FRF используют общий исполнитель; дисковый FFT последовательный.
- Auto/manual бюджет данных (64…65536 MiB) учитывает capacity документов,
  допуски загрузки/анализа и общие индексы, ограничивается доступными RAM/commit.
  Отмена удерживает резерв до уничтожения массивов. Это частичный учёт данных,
  не лимит всей памяти процесса; N/L не сокращаются при отказе.
- Частный дисковый LRU ScanIndex/обзоров: 2 GiB/256 элементов, lease активных
  файлов, versioned пути и owner-lock. Повторное открытие использует AMSCIDX1;
  повреждённый/недоступный кэш сохраняет ограниченное сканирование.
  Если общий каталог занят другим процессом или недоступен, обзор использует
  временный частный кэш с той же общей квотой ScanIndex/overview; последний
  lease удаляет только собственные файлы.
- CSV/TXT/LVM и переносимый проект потоково читают оригиналы всей записи или
  выбранного участка, FFT экспортирует настоящие бины. Проект содержит полную
  raw запись и настройки. Экспорт выполняется в фоне с отменой и атомарной
  заменой назначения; открытый source не перезаписывается.
- Уведомление ожидания принадлежит главному окну, не является topmost и не
  захватывает фокус фонового приложения. Обновлены README и карта архитектуры.

Проверки: 1157 core / 851 GUI; синтетические 10/20 GB, N=47 390 720/94 785 536,
46/49 внешних проверок при Manual 64 MiB и commit-пределе процесса 128 MiB.
Полный FFT одного канала: 1189,27/2431,28 с; H1 семи откликов с L=2048:
221,776/441,325 с; Peak WS до H1 31,5859/33,293 MiB. Ошибки FFT-пика
5,60284e-11/2,98433e-09, H1/coherence 9,8323e-16/4,44089e-16.
20 GB открыт повторно с готовым обзором; холодный прогон превысил прежний
таймаут стенда и не считается успешным замером открытия.
Остальные проверенные размеры/замеры и ограничения перечислены в описании этого
предварительного выпуска. Физический ПК с 8 GiB не испытывался; Windows
Job Object с ограничением commit — отдельная проверка. Нет нового сопоставимого
замера FAMOS. Склейка дискового времени недоступна, далёкий фильтр/Snap требует
повторного прогрева, широкий FFT-Snap синхронный, временный диск обязателен.
Дисковый спектр пока рисует ломаную без визуального сплайна/символов кривых.
CLI собран, его пользовательское открытие остаётся векторным.

### EN

Large recordings open automatically as complete disk overviews.
Analysis → Entire recording / Interval / Use visible interval defines one
FFT/FRF area independently of zoom. Light Mode controls/flags, the mandatory
fragment prompt and the separate full-FRF View command are removed. Legacy
project keys are ignored and obsolete INI keys retired on settings save;
active command numbers remain compatible.

- Immutable RecordingSource owns the file/index and checks size/mtime around
  reads and publication. Two seed rows are UI-only; N is stored separately.
  Whole-source channel discovery preserves late columns and signals that
  resemble time only in the prefix.
- Disk overview stores exact extrema, positions and gaps. Zoom reads levels
  or originals; asynchronous Signal-Snap always reads source samples.
  Cancellation, document switching, Undo/Redo and SourceChanged reject stale points.
- A shared processed source supplies formulas/causal filters to overview,
  Snap, FFT/FRF and exports. Biquad states span blocks, intervals warm up from
  the beginning, and filter Fs follows the original exact full-timeline rule.
  Nonlinear extrema are built from samples. Non-finite nonlinear inputs
  follow the canonical GUI policy, including expressions finite at Inf.
- Full FFT preserves N, grid, interpolation, DC removal, gap compression and
  scaling. Insufficient RAM admission selects tiled disk radix-2/Bluestein,
  never averaged block FFTs. Working admission is 24 MiB; the 384 MiB numerical
  cap includes retained plans. Temporary disk allowance is 64 GiB with space
  preflight. Only amplitudes/bounded summaries survive; inactive disk results
  are limited to 2 GiB.
- FRF preserves Welch overlap, Sxx/Syy/Sxy accumulation order, shared averaged
  reference FFT, H1/coherence, weak-input masks and exact Fs. Spectrum/FRF
  share an executor; disk FFT is sequential.
- Auto/manual data budgets (64…65536 MiB) track document capacities, load and
  analysis reservations and shared indexes, constrained by available RAM/commit.
  Cancellation retains admission until buffers die. This is partial data
  accounting, not a process-wide cap; failures never silently reduce N/L.
- Private ScanIndex/overview LRU: 2 GiB/256 entries, active leases, versioned
  paths and an owner lock. AMSCIDX1 accelerates index reuse; unavailable or
  corrupt caches fall back to bounded scanning.
  If the shared directory is locked by another process or unavailable, overview
  uses a private temporary cache with the same shared ScanIndex/overview quota;
  the last lease removes only owned files.
- CSV/TXT/LVM and portable projects stream originals for the whole recording
  or selected interval; FFT exports exact bins. Projects include all raw samples
  and settings. Background export supports cancellation and atomic replacement;
  it cannot overwrite a live source.
- The owned loading notice is not topmost and does not steal background focus.
  README and architecture documentation are updated.

Validation: 1157 core / 851 GUI checks; synthetic 10/20 GB,
N=47,390,720/94,785,536, 46/49 external checks with Manual 64 MiB and a hard
128 MiB process commit cap. Full one-channel FFT: 1189.27/2431.28 s;
seven-response H1, L=2048: 221.776/441.325 s; process Peak WS through H1:
31.5859/33.293 MiB. FFT peak errors: 5.60284e-11/2.98433e-09;
H1/coherence: 9.8323e-16/4.44089e-16. The 20 GB opening reused an overview
index; its preceding cold run exceeded the old harness timeout and is not
a successful opening measurement.
Other verified sizes, measurements and limitations are listed in the prerelease
description. Physical 8 GiB hardware was not tested; Windows Job Object commit
limits are a separate test. No new comparable FAMOS benchmark was made.
Disk-source time stitching is unavailable, distant filtered reads/Snap replay
the warm-up prefix, wide FFT-Snap is synchronous, and temporary disk is required.
Disk spectra currently use polylines without visual splines/curve symbols.
CLI builds successfully but its user-facing loading remains vector-based.

## v0.17.0-rc.1 (pre-release)

### Ограниченная память и H1/coherence

- Добавлены блочное чтение выбранных исходных столбцов, неизменяемый дисковый
  вход FRF и точное определение Fs внешней сортировкой. Перекрытие Welch,
  усреднение опор, порядок Sxx/Syy/Sxy, порог слабой опоры и финализация сохранены.
- Radix-2 FFT выполняется в рабочих массивах; произвольные длины сохраняют
  Bluestein. Удалены лишние копии общей опоры/времени и ненужное суммирование
  среднего. Быстрые комплексные проверки сохраняют обнаружение переполнения abs.
- FFT/FRF используют общий исполнитель до четырёх участников с последовательным
  запасным путём. Планировщик учитывает рабочие массивы и сохранённые планы;
  слишком большой FRF-сегмент отклоняется, Auto/Direct не меняют L скрыто.
- Ограничены кэши входа, обработки и результатов неактивных документов.
  Численная ревизия отделена от generation; изменённый файл требует открытия заново.
  Оформление и его Undo/Redo сохраняют численный вход и результат; подписи
  каналов FRF обновляются без повторного расчёта.
- Причинный фильтр переносит состояния между блоками. Анализ полного файла
  доступен через «Вид → АЧХ: вся запись», без расширения фрагмента на графике
  и изменения выделения FFT. Большие файлы сначала индексируются; объём
  отображаемого Dataset ограничен оценкой памяти.
- Добавлены регрессии блоков, фильтров, отмены, кэша и полного источника GUI.
  Внешний отчёт отдельно фиксирует реальные размеры синтетических файлов,
  подготовку, численный расчёт, память, точность и ограничения крупных испытаний.
- Повторная проверка перед выпуском исправила обработку ошибок открытия,
  чтения и закрытия временных файлов: возвращается ошибка ресурсов без
  частичного результата. Чтение рабочих плиток проверяет диапазон и отмену.
  Сложные формулы сохраняют порядок аффинной/тождественной обработки GUI.
- На Windows кэш Bluestein освобождается системным FLS при выходе потока.
  Стресс короткоживущих потоков воспроизвёл повреждение памяти с эмулируемым
  TLS и в исходной v0.16.11. Новый путь выдержал 3000 FFT-потоков; двенадцать
  полных запусков ядра прошли. На остальных платформах остаётся thread_local.
- Проверки: 457 численных и 425 GUI; 15 362 827 сравнений с v0.16.11
  и 12 434 787 сравнений реальной записи N=337132, измеренная ошибка 0.
  Синтетические 10/20 GB испытаны на численном стенде при L=2048 и семи откликах.
  Пик интерактивного GUI и полная фильтрованная запись 20 GB не измерены;
  дисковый снимок требует свободного места, большой повтор перечитывает источник.

### Bounded memory and H1/coherence

- Added block reads of selected source columns, immutable disk-backed FRF input,
  and exact sample-rate inference using external sorting. Welch overlap,
  reference averaging, Sxx/Syy/Sxy order, weak-reference rules and finalization
  preserve the existing method.
- Radix-2 FFT now transforms working arrays in place; arbitrary lengths retain
  Bluestein. Removed redundant shared reference/time copies and disabled-mean
  sums. Faster complex checks retain abs-overflow detection.
- FFT/FRF share an executor with up to four participants and a sequential
  fallback. Scheduling accounts for workspace and retained plans; oversized
  FRF segments fail explicitly without silently changing Auto/Direct lengths.
- Bounded input, processing and inactive-document result caches. Numerical
  input revisions are separate from job generations; changed files require reopening.
  Appearance changes and their Undo/Redo preserve numerical inputs/results;
  FRF channel captions update without recalculation.
- Causal filter state continues across blocks. View → FRF: entire recording
  analyzes the indexed source without expanding the display fragment or
  changing FFT selection. Large files are indexed first; displayed Dataset
  allocation uses a conservative memory allowance.
- Added block/filter/cancellation/cache and full-source GUI regressions.
  The external report separates synthetic file sizes, preparation, numerical
  execution, memory, accuracy and the limits of large-record testing.
- Pre-release review fixed scratch-file open/read/close failure handling:
  resource errors cannot publish partial results. Tile reads check bounds and
  cancellation. Complex formulas retain GUI affine/identity arithmetic order.
- Windows Bluestein caches use native FLS cleanup on thread exit. A short-lived
  thread stress reproduced heap corruption with emulated TLS in both the
  original v0.16.11 and updated build. Native FLS passed 3000 FFT threads and
  twelve complete core runs; other platforms retain thread_local storage.
- Validation: 457 numerical and 425 GUI checks; 15,362,827 frozen-baseline
  comparisons and 12,434,787 real-record comparisons at N=337132 with measured
  error 0. Synthetic 10/20 GB files were tested in the numerical harness with
  L=2048 and seven responses. Interactive GUI peak memory and a fully filtered
  20 GB record were not measured; scratch storage needs free disk space and
  large repeated calculations reread the source.

## v0.16.11

### Компоновка подписей осей и легенды

- Пользовательская подпись X в Сигнале, Спектре и АЧХ расположена справа
  на одной строке с физическим названием оси, сразу под числовыми делениями.
  Ей отводится не больше трети ширины графика; физическое название занимает
  оставшееся поле с отступом. Длинные подписи сокращаются многоточием.
  Нижнее поле окна и PNG уменьшено с 66 до 44 пикселей.
- Крестик легенды каналов находится справа в первой строке и не добавляет
  отдельный заголовок. Его колонка исключена из областей переключения каналов.
- Частотные подписи АЧХ измеряются осевым шрифтом и сдвигаются внутрь
  графика у краёв в линейной и логарифмической шкале.
- Обновлены пиксельные проверки подписей; добавлены проверка компактной
  легенды и экспорт PNG с длинной крайней частотой. Все 398 GUI-проверок
  пройдены. Обновлены правила работы и карта модулей.

### Axis caption and legend layout

- Editable X names in Signal, Spectrum and FRF sit on the right of the same
  row as the physical axis caption, immediately below numeric ticks. Names
  receive at most one third of the plot width; the physical caption uses
  the remaining space with a gap. Long captions are ellipsized.
  The bottom margin in the window and PNG exports is reduced from 66 to 44 pixels.
- The channel legend close control shares the first row without adding
  a header. Its column is excluded from channel visibility hit areas.
- FRF frequency labels are measured using the axis font and shifted inside
  the plot at its edges on both linear and logarithmic scales.
- Updated caption pixel checks; added a compact legend check and PNG export
  with a long endpoint frequency. All 398 GUI checks pass.
  Updated repository guidance and the module map.

## v0.16.10

### Легенда каналов и оформление осей

- Легенду каналов в режимах «Сигнал» и «Спектр» можно скрыть крестиком
  и вернуть через «Вид → Легенда каналов». Скрытие сразу освобождает область
  для мыши и не меняет видимость самих каналов.
- Видимость легенды хранится отдельно у каждого документа, входит в Undo/Redo
  и сохраняется в графических метаданных проекта `.AMSig`. Старые проекты
  и новые файлы по умолчанию показывают легенду. PNG учитывает её видимость.
  В FRF пункт недоступен; отдельная полоса обозначений Ч/Б-кривых сохранена.
- У пользовательских названий X/Y убраны непрозрачные подложки. Y расположена
  над общей областью графика, X — справа в отдельной строке ниже числовых
  делений и физического названия оси. Оформление едино для Сигнала, Спектра
  и АЧХ, в том числе с показанным и скрытым графиком средней опоры.
- Названия используют общий осевой шрифт и цвет текущей темы; длинный текст
  сокращается многоточием в пределах ширины графика. Поля окна и PNG
  резервируют место для названий, физических подписей и подписи экспорта;
  инвалидация включает верхнюю строку Y.
- Добавлены проверки легенды, истории, состояния документов, сохранения
  проекта, PNG и пиксельные проверки размещения названий во всех режимах,
  обеих темах и при узком графике. Всего проходят 396 GUI-проверок;
  тестовые PNG проверены визуально. Обновлены правила работы и карта модулей.

### Channel legend and axis appearance

- The channel legend in Signal and Spectrum can be hidden with its close
  control and restored through View → Channel legend. Hiding immediately
  releases its mouse hit areas without changing channel visibility.
- Legend visibility belongs to each document, supports Undo/Redo and is
  stored in `.AMSig` project graph metadata. Older projects and new files
  show the legend by default. PNG exports follow its visibility. The command
  is disabled in FRF; the separate grayscale curve legend remains unchanged.
- Removed opaque backgrounds from editable X/Y names. Y sits above the
  overall plot area; X is right-aligned in its own row below numeric ticks
  and the physical axis caption. Signal, Spectrum and FRF share this layout,
  including FRF with its mean-reference graph shown or hidden.
- Names use the shared axis font and the current theme's axis color. Long
  names are ellipsized within the plot width. Window and PNG margins reserve
  space for names, physical captions and the export credit; invalidation
  includes the outer Y row.
- Added legend, history, document state, project roundtrip and PNG checks,
  plus pixel checks for names in all modes, both themes and narrow plots.
  All 396 GUI checks pass; generated PNGs were visually inspected.
  Updated repository guidance and the module map.

## v0.16.9

### Названия режимов и панель FRF

- Режим «Время» / `Time` переименован в «Сигнал» / `Signal` в кнопке,
  меню, статусе, подсказках, справочнике горячих клавиш и настройках осей.
  Физическая ось времени и заголовки экспорта сохраняют прежние названия.
- «Сглаживание линий» / `Line smoothing` переименовано в
  «Сглаживание каналов» / `Channel smoothing`.
- Список семейства фильтра снова расположен справа от подписи, как список
  режима; оба списка выровнены в общей колонке с учётом языка интерфейса.
- В FRF добавлена третья вкладка «Фильтр» / `Filter` рядом с «Каналы» и
  «Точки». Она использует общий фильтр всех каналов текущего документа,
  поддерживает Undo и прокрутку. Выбранная вкладка сохраняется при входе
  в FRF. Пересчёт с фильтром зависит от переключателя обработки каналов.
- Удалены отдельные кнопки Calculate, CSV и PNG из правой панели FRF;
  подсказка сдвинута вверх. Enter в поле L продолжает запускать расчёт,
  экспорт доступен через общие команды приложения.
- Добавлены 13 GUI-проверок вкладок, общего фильтра, Undo, прокрутки,
  отсутствия удалённых кнопок и расчёта по Enter; обновлены проверки названий.
  Всего успешно проходят 353 GUI-проверки. Численные ядра и форматы проектов
  не изменены.

### Mode names and FRF panel

- Renamed the Time mode to Signal in the toolbar, menu, status, tooltips,
  shortcut reference and axis settings. Physical time-axis labels and export
  headers retain their existing names.
- Renamed Line smoothing to Channel smoothing in both interface languages.
- Restored the filter-family selector to the right of its label, like the
  mode selector. Both selectors share a column with language-aware label widths.
- Added a third Filter tab beside Channels and Points in FRF. It uses the
  current document's shared filter for all channels, with Undo and scrolling.
  Entering FRF preserves the selected tab. Applying the filter to FRF remains
  controlled by the channel-processing toggle.
- Removed separate Calculate, CSV and PNG buttons from the FRF panel and
  moved the hint up. Enter in L still starts calculation; export remains
  available through the application's shared commands.
- Added 13 GUI checks covering tabs, the shared filter, Undo, scrolling,
  removed buttons and Enter-triggered calculation; updated mode-name checks.
  All 353 GUI checks pass. Numerical kernels and project formats are unchanged.

## v0.16.8

### Интерфейс и измерительные подписи

- Согласованы русские и английские названия: `Auto scale`, `Spectrum (FFT)` /
  `Спектр (БПФ)`, `Filter family` / `Семейство фильтра`, `ФНЧ`/`ФВЧ`,
  общая формула для всех каналов и отдельное сглаживание линий.
- В FRF входная роль называется `Reference channels`; подсказка описывает
  отклик относительно опоры. Ось модуля обозначена `FRF magnitude |H|` /
  `АЧХ |H|` без безусловного утверждения о безразмерности.
- Локализованы границы частоты, прямой метод, автоматическая длина сегмента,
  перекрытие, когерентность и показания под курсором. Убраны русские `КД`,
  `ΔКД` и `(сгл.)` из английских показаний; стандартное `ед.` выводится как `units`.
- Обратная разность частот `1/Δf` теперь имеет единицу секунды; `1/Δt`
  сохраняет герцы. Подпись переключателя зависит от режима; при совпадении X
  обратная разность на графике отображается как `—` вместо нуля.
- Общий формат подписей разностей применяется к Time, FFT и обоим графикам
  FRF. Нижний график средней опоры показывает `A` и `ΔA` с единицами амплитуды,
  верхний — `Δ|H|`. Числовое расстояние координат явно обозначено
  `d (условн.)` / `d (coord.)` и не является физическим замером.
- Семейство фильтра вынесено на отдельную полноширинную строку панели.
- Численное ядро FFT/FRF и формат сохранённых проектов не изменены.
  Добавлены шесть проверок единиц и подписей: всего проходят 340 GUI-проверок.

### Interface and measurement labels

- Aligned Russian and English names: `Auto scale`, `Spectrum (FFT)` /
  `Спектр (БПФ)`, `Filter family` / `Семейство фильтра`, Russian low-/high-pass
  filter abbreviations, the global formula for all channels, and line smoothing.
- FRF inputs are named `Reference channels`; the tooltip describes response
  relative to reference. The magnitude axis reads `FRF magnitude |H|` /
  `АЧХ |H|` without assuming every input/output ratio is dimensionless.
- Localized frequency limits, the direct estimator, automatic segment length,
  overlap, coherence, and cursor readouts. Removed Russian KD/difference/smoothing
  labels from English readouts; the default amplitude unit is displayed as `units`.
- Reciprocal frequency separation `1/Δf` now uses seconds; `1/Δt` retains
  hertz. The toggle follows the current mode; equal X coordinates show `—`
  instead of a zero reciprocal separation on the plot.
- A shared difference formatter serves Time, FFT and both FRF plots. The mean
  reference plot displays `A` and `ΔA` with amplitude units; the upper plot
  displays `Δ|H|`. Numerical coordinate distance is explicitly labelled
  `d (условн.)` / `d (coord.)` and is not a physical measurement.
- The filter family selector has its own full-width row.
- FFT/FRF numerical kernels and saved-project formats are unchanged.
  Six new unit/label checks bring the passing GUI suite to 340 checks.

## v0.16.7

### Производительность

- Пакетный FRF переиспользует окно, FFT средней опоры, Sxx, порог слабого
  входа и спектр опоры в одном проходе по сегментам. Syy/Sxy, комплексный H1,
  coherence и ошибки остаются отдельными для каждого отклика. Одиночный
  отклик сохраняет прежний путь; FFT всех сегментов не сохраняются.
- Независимые каналы больших FFT вычисляются общим пулом до четырёх участников,
  включая вызывающий поток. Малые записи, один канал и занятый пул используют
  последовательный путь. Параллелизм ограничен оценкой рабочих массивов и кэшей;
  результаты и ошибки собираются в исходном порядке после завершения задач.
- Длина DFT, сетка, нормировка, настройки анализа и точность накоплений сохранены.
- На test1.lvm, Ryzen 5 5600X, GCC 14.2.0, `-O2`, после прогрева и семи
  повторов: FFT восьми каналов N=262144 — 151,05 → 51,59 мс,
  N=337132 — 595,03 → 327,46 мс; пакетный H1/coherence с одной опорой
  и семью откликами, L=2048, Hann, 50% overlap, remove_mean=false —
  210,36 → 135,87 мс. База этих замеров — v0.16.6; это не универсальная гарантия.
- Пик commit процесса для полного FFT вырос с 122 до 256 MiB; бюджет
  планировщика 384 MiB не является ограничением памяти всего приложения.
  Все 26 случаев совпали с базой побайтно. Контроль одиночных путей в одном
  процессе не подтвердил существенного ухудшения.
- Выход GUI явно отменяет и завершает FFT-worker до разрушения общего пула.
  Прошли 340 численных и 334 GUI-проверки, полные сборки CLI и GUI.

### Performance

- Batch FRF reuses the window, averaged-reference FFT, Sxx, weak-input threshold
  and reference spectrum in one segment pass. Each response retains its own
  Syy/Sxy, complex H1, coherence and errors. Single-response calculations keep
  their previous path; segment FFTs are not retained as a bank.
- Independent channels in large FFTs use one pool with up to four participants,
  including the caller. Small inputs, single channels and contending callers
  use the sequential path. Estimated workspaces/caches bound scheduling;
  ordered results and errors are collected after all jobs finish.
- DFT length, frequency grid, normalization, settings and accumulation precision
  are preserved.
- On test1.lvm, Ryzen 5 5600X, GCC 14.2.0, `-O2`, after warm-up and seven
  repeats: eight-channel FFT N=262144 — 151.05 → 51.59 ms,
  N=337132 — 595.03 → 327.46 ms; batch H1/coherence with one reference
  and seven responses, L=2048, Hann, 50% overlap, remove_mean=false —
  210.36 → 135.87 ms. These measurements use v0.16.6 as baseline and are not
  a universal speed guarantee.
- Full-record FFT peak process commit increased from 122 to 256 MiB; the
  384 MiB scheduling allowance is not a process memory limit. All 26 cases
  matched the baseline byte for byte. In-process single-path controls did not
  confirm a substantial regression.
- GUI exit explicitly cancels and joins the FFT worker before pool destruction.
  Passed 340 numerical and 334 GUI checks, plus full CLI and GUI builds.

## v0.16.6

### Производительность

- Проверки отмены radix-2 вынесены из внутреннего арифметического цикла
  между блоками не более 16384 butterfly без перезапуска рекуррентного twiddle.
- Bluestein переиспользует один завершённый план chirp и FFT ядра свёртки
  на поток, до 64 MiB. При смене длины старый план освобождается; отменённый
  план не публикуется, большие планы остаются временными.
- На test1.lvm (8 каналов, 337132 отсчёта; GCC 14.2.0, `-O2`, Ryzen 5 5600X)
  медиана полного FFT снизилась с 4103,07 до 938,38 мс, а H1/coherence
  одной пары при L=2048, Hann, 50% overlap и remove_mean=false —
  со 133,81 до 40,91 мс. Это результаты одной серии, не универсальная гарантия.
- Длина записи, частотная сетка и настройки анализа сохранены. Проверенные
  FFT, комплексный H1, coherence и маски совпали с прежним ядром побайтово.
- Добавлены регрессии границ блоков, холодных/повторных/заменённых планов,
  отмены и независимых кэшей потоков. Прошли 314 проверок ядра и 333 GUI-проверки.

### Performance

- Radix-2 cancellation checks now run between chunks of at most 16384
  butterflies, outside the arithmetic loop, without restarting recurrent twiddles.
- Bluestein reuses one completed chirp/convolution-kernel FFT plan per thread,
  up to 64 MiB. Changing the length releases the previous plan; cancelled plans
  are not published, and larger plans remain temporary.
- On test1.lvm (8 channels, 337132 samples; GCC 14.2.0, `-O2`, Ryzen 5 5600X),
  median full-record FFT time decreased from 4103.07 to 938.38 ms. Single-pair
  H1/coherence with L=2048, Hann, 50% overlap and remove_mean=false decreased
  from 133.81 to 40.91 ms. These are measurements from one series, not a universal guarantee.
- Record length, frequency grid and analysis settings are preserved. Tested FFT,
  complex H1, coherence and masks match the previous kernel byte for byte.
- Added regression coverage for chunk boundaries, cold/warm/replaced plans,
  cancellation and independent thread caches. All 314 core and 333 GUI checks passed.

## v0.16.5

### Исправлено

- После удаления повторяющихся столбцов времени автоматически выданные имена
  каналов `Channel_N` нумеруются подряд в порядке оставшихся каналов. Имена,
  явно заданные в исходном файле, сохраняются без изменений.
- Добавлена регрессионная проверка чередующихся столбцов времени и каналов,
  включая случай с явно заданными именами.

### Fixed

- After duplicate time columns are removed, automatically generated `Channel_N`
  names are numbered consecutively in the order of the remaining channels.
  Names explicitly provided by the source file remain unchanged.
- Added regression coverage for interleaved time and signal columns, including
  explicitly named channels.

## v0.16.4

### Исправлено

- Перетаскивание нижнего графика средней опоры в АЧХ снова панорамирует общую
  с КД частотную ось X. Его вертикальная составляющая меняет только верхнюю
  границу независимой Y-шкалы опоры, сохраняя нулевую базу — так же, как КД и
  Spectrum.

### Fixed

- Dragging the lower averaged-Reference graph in FRF again pans the frequency
  X axis shared with KD. Its vertical component changes only the upper bound
  of the Reference's independent Y scale while retaining a zero baseline,
  matching KD and Spectrum.

## v0.16.3

### Исправлено

- В АЧХ кнопка **Автомасштабирование** теперь возвращает автоматические
  Y-диапазоны одновременно для КД и средней опоры. Если вручную изменена
  только шкала опоры, кнопка больше не переводит её в ручной режим повторно.
- Перетаскивание нижнего графика средней опоры изменяет только его собственную
  шкалу Y. Общая с КД ось частоты X не смещается даже при диагональном движении
  мыши.
- Состояние кнопки и пункта меню автомасштаба в АЧХ учитывает обе вертикальные
  шкалы, поэтому не показывает Auto, когда одна из них уже изменена вручную.

### Fixed

- In FRF, **Auto-scale** now restores automatic Y ranges for both KD and the
  averaged Reference. If only the Reference scale was changed manually, the
  control no longer switches it back to manual mode.
- Dragging the lower averaged-Reference graph changes only its own Y scale.
  The frequency X axis shared with KD does not move, even during a diagonal
  drag.
- The FRF Auto-scale button and menu state now account for both vertical
  scales, so Auto is not shown while either scale has been adjusted manually.

## v0.16.2

### Новый функционал

- Нижний график средней опоры в АЧХ получил независимый перемещаемый диапазон
  Y: `Ctrl`+колесо масштабирует его вокруг указателя, а `Alt`+колесо и
  перетаскивание панорамируют. Частотная ось X остаётся синхронизированной с
  графиком КД.

### Доработано

- Ручные границы Y нижнего графика сохраняются в проекте `.AMSig`, поэтому
  выбранный вид опоры восстанавливается после повторного открытия файла.

### New functionality

- The lower averaged-Reference graph in FRF now has an independently movable
  Y range: `Ctrl`+mouse wheel zooms around the pointer, while `Alt`+mouse
  wheel and dragging pan it. Its X frequency view remains synchronized with
  the KD graph.

### Improved

- Manual lower-Reference Y limits are saved in `.AMSig` projects, restoring
  the chosen view after reopening a file.

## v0.16.1

### Исправлено

- Горизонтальная направляющая теперь подчиняется Snap при постановке и
  переносе: она получает Y ближайшей отображаемой кривой. В АЧХ для обеих
  направляющих используется сглаженная отображаемая кривая.
- Удаление выбранной точки, маркера или направляющей надёжно обрабатывается
  клавишами `Delete` и `Backspace`, включая случай, когда до этого фокус был
  у поля правой панели.
- После удаления последней точки группа сразу исчезает из списка; Undo/Redo
  восстанавливает и снова удаляет группу вместе с точкой.
- Метка маркера больше не закрывает значение совпадающей вертикальной
  направляющей.

### Доработано

- Разметка теперь выбирается акцентной рамкой в режиме «Курсор». Активные
  инструменты создания оставляют короткий клик созданием объекта, а тягу от
  4 пикселей — панорамированием. ПКМ больше не выполняет скрытую очистку.
- Одна группа не получает одинаковую точку повторно; в текущем режиме также
  исключены повторные маркеры и направляющие. Точки разных групп по-прежнему
  могут совпадать.
- Маркер всегда показывает точку в своей позиции, вертикальную и
  горизонтальную направляющие. При совпадении с вертикальной линией подписи
  разводятся по разные стороны; у левого края они не перекрываются.
- Пункт «Справка → О программе» переименован в «Справка → Начальный экран»
  (`Help → Start screen`).

### Fixed

- Horizontal guides now honor Snap during placement and dragging, taking Y
  from the nearest displayed curve. In FRF, both guide orientations use the
  displayed smoothed curve.
- `Delete` and `Backspace` reliably remove the selected point, marker, or
  guide, including after focus had been in a right-side-panel edit control.
- A point group disappears as soon as its last point is removed; Undo/Redo
  restores and removes that group together with the point.
- A marker label no longer obscures the value of a coincident vertical guide.

### Improved

- Cursor mode selects annotations with an accent outline. Placement tools keep
  a short click for creation and use a drag of 4+ pixels for panning; right
  click no longer performs an implicit clear.
- A group cannot receive a duplicate point; duplicate markers and guides are
  also prevented in the current mode, while points from separate groups may
  still coincide.
- Every marker shows its point plus vertical and horizontal guides. Coincident
  marker and vertical-guide labels use opposite sides of the line and remain
  non-overlapping at the left edge.
- `Help → About` is now named `Help → Start screen`.

## v0.16.0

### Исправлено

- В АЧХ числовые шкалы, подписи и границы обоих графиков корректно остаются
  видимыми после расчёта, навигации и изменения масштаба; правую панель при
  навигации не нужно перерисовывать, поэтому её элементы не мигают.
- Панель АЧХ больше не обрезает русские и английские служебные подписи;
  улучшены отступы между строками и высота многострочной подсказки.

### Доработано

- Во всех режимах физические вертикальные шкалы имеют отдельные подписи и
  единый отступ, а пользовательские X/Y настраиваются независимо для Time,
  Spectrum и АЧХ. Новые АЧХ используют линейную частотную ось по умолчанию.
- Нижний график средней опоры АЧХ получил отдельные измерительные точки,
  собственную физическую шкалу, серый захват разделителя и возможность
  увеличить его почти до высоты графика КД.
- Разметка и её история согласованы между Time, Spectrum и АЧХ: точки,
  маркеры и направляющие не смешиваются между режимами, а проекты сохраняют
  дополнительные точки средней опоры.

### Новый функционал

- Существующие точки, маркеры, вертикальные и горизонтальные линии можно
  перетаскивать во всех трёх режимах. Захват объекта имеет приоритет над
  активным инструментом добавления; Snap применяется при переносе, а перенос
  является одним действием Undo/Redo.
- В верхней панели добавлена кнопка `🔒` для блокировки разметки. Она запрещает
  добавление, перенос и очистку разметки активного документа, не мешая
  навигации графика; повторное нажатие снимает блокировку.

### Fixed

- FRF numeric scales, labels and plot borders now remain visible after
  calculation, navigation and zooming. Navigation no longer needs to repaint
  the right panel, so its controls do not flicker.
- FRF panel text is no longer clipped in Russian or English; row spacing and
  the multiline hint height were improved.

### Improved

- Every mode has separate physical vertical-scale captions with consistent
  spacing, while editable X/Y names are independent for Time, Spectrum and
  FRF. New FRF views use a linear frequency axis by default.
- The lower averaged-Reference plot now has its own measurement points,
  physical scale, grey splitter grip and a resizable height that can closely
  match the KD plot.
- Annotation storage and history are aligned across Time, Spectrum and FRF:
  points, markers and guides remain separate by mode, and projects preserve
  averaged-Reference points.

### New functionality

- Existing points, markers, vertical guides and horizontal guides can be
  dragged in every mode. Object capture takes precedence over an active
  placement tool; Snap is retained during a move, and each move is one
  Undo/Redo action.
- A `🔒` toolbar button locks annotations. It prevents adding, moving and
  clearing annotations in the active document without preventing graph
  navigation; press it again to unlock.

## v0.15.5

- Во всех режимах графика добавлена явная подпись вертикальной шкалы: в Time
  и FFT показаны амплитуда и настраиваемые единицы Y. В настройках прежняя
  «Буква Y» переименована в «Единицы Y»; старое служебное значение `Y`
  автоматически заменяется нейтральным `ед.`.
- В АЧХ раздельно обозначены безразмерный коэффициент `КД |H|` и физические
  единицы амплитуды средней опоры. Русские подписи КД, опоры и частотной оси
  сокращены так, чтобы не обрезаться в рабочей области графика.
- Подписи АЧХ теперь рисуются последним слоем на непрозрачной подложке, поэтому
  не мигают и не закрываются маркерами, направляющими или измерениями при
  панорамировании и масштабировании. Числовые подписи Y автоматически
  пропускают слишком близкие позиции на компактном графике средней опоры, но
  линии сетки сохраняются полностью.
- Added explicit vertical-scale labels to every graph mode: Time and FFT now
  show amplitude with configurable Y units. Settings rename the former “Y
  label” to “Y units”, and the old decorative `Y` value automatically becomes
  a neutral unit placeholder.
- FRF now distinguishes the dimensionless `KD |H|` scale from the physical
  amplitude units of the averaged Reference. Compact Russian labels for the
  coefficient, Reference and frequency axis fit within the graph workspace.
- FRF scale labels are rendered last on opaque backing plates, preventing
  flicker or occlusion by markers, guides and measurements during pan or zoom.
  Closely spaced Y tick labels on a compact Reference plot are omitted while
  retaining the complete grid.

## v0.15.4

- Лицензия проекта заменена на GNU GPLv3. При распространении изменённых версий
  должны сохраняться GPLv3, уведомления об авторстве и доступность
  соответствующего исходного кода. Ранее выпущенные версии под MIT сохраняют
  условия этой лицензии.
- Replaced the project license with GNU GPLv3. Distributed modified versions
  must retain GPLv3, copyright notices and the availability of corresponding
  source code. Earlier MIT releases retain their original terms.

## v0.15.3

- В АЧХ добавлено переключение логарифмической и линейной частотной шкалы без
  повторного расчёта. Исправлены преобразования координат для маркеров, линий,
  точек, масштабирования и панорамирования в обоих режимах.
- График средней опоры можно скрыть, менять его высоту перетаскиванием
  разделителя и масштабировать по Y отдельно через Ctrl+колесо. Настройки
  источника АЧХ, шкалы и графика опоры сохраняются в проекте.
- При возврате на вкладку FFT завершённый кэш того же участка используется без
  нового вычисления. Окно предупреждения о несохранённом проекте приведено к
  тематическому оформлению AMSignal.
- Панель АЧХ переразмечена для русских подписей: длинные значения сглаживания
  и частотной шкалы полностью видны, переключатель средней опоры занимает
  всю строку, а пояснения и диапазон источника не обрезаются.
- Маркеры, вертикальные и горизонтальные линии работают единообразно в Time,
  FFT и АЧХ: инструмент остаётся активным после постановки нескольких
  объектов и выключается кнопкой «Курсор» или клавишей `Esc`.
- Added linear/logarithmic frequency-axis switching for FRF without rerunning
  the calculation, including correct coordinates for annotations, zoom, and pan.
- The average-Reference plot can be hidden, resized with its divider, and
  independently Y-scaled with Ctrl+wheel. FRF source, axis, and Reference-view
  settings now persist in a project.
- Returning to FFT reuses a completed cache for the same source. The unsaved
  project prompt now uses AMSignal's themed dialog.
- Reflowed the FRF panel for complete Russian labels: smoothing and frequency
  axis values fit, the average-Reference toggle uses a full row, and helper
  text and the source range are no longer clipped.
- Markers and vertical/horizontal guide lines now behave identically in Time,
  FFT, and FRF: the selected tool remains active for repeated placement and
  is exited with Cursor or `Esc`.

## v0.15.2

- АЧХ теперь показывает натуральный коэффициент `|H|` без dB с вертикальной
  шкалой от нуля. Под ним добавлен отдельный линейный амплитудный график
  арифметически усреднённой опоры; те же значения доступны в FRF CSV.
- Исправлены единицы и подписи вертикальных/горизонтальных линий и измерительных
  точек в режиме АЧХ. Обработка каналов включена для новых FRF-документов по
  умолчанию, а панель поясняет спад фильтра и сокращение одинаковой обработки
  Reference/Response в коэффициенте передачи.
- В меню «Вид» добавлены фигуры кривых для Ч/Б-печати. Режим сочетает разные
  штрихи и маркеры на Time, FFT, FRF и PNG, поддерживает Undo/Redo и сохраняется
  в проекте.
- FRF now displays the natural `|H|` ratio without dB and keeps the vertical
  scale anchored at zero. A separate linear amplitude plot for the
  arithmetically averaged Reference is shown below and exported to FRF CSV.
- Corrected FRF units and labels for guide lines and measurement points.
  Channel processing is enabled by default for new FRF documents, and the
  panel explains filter roll-off and cancellation of equal Reference/Response
  processing in the transfer ratio.
- Added a View option for grayscale curve identification. Distinct dash and
  marker combinations apply to Time, FFT, FRF, and PNG, participate in
  Undo/Redo, and persist in project files.

## v0.15.0

- Добавлена одновременная работа с несколькими исходными файлами. Диалог
  открытия принимает множественный выбор, а drag-and-drop добавляет все
  переданные файлы; один фоновый загрузчик обрабатывает их последовательно.
- Каждый файл теперь является самостоятельным документом: отдельно хранятся
  каналы и их цвета, формулы и фильтрация, временное выделение, режим
  Time/FFT/FRF, кэши спектра и АЧХ, точки, линии и параметры отображения.
  Переключение между документами не копирует большие массивы измерений:
  состояния перемещаются между активным и неактивными слотами.
- В верхнюю панель добавлен заметный селектор `Файлы (N): <имя>` для быстрого
  перехода к любому открытому источнику и соседняя кнопка закрытия текущего
  файла. Запасной список сохранён в `Файл → Открытые файлы`.
- При переключении отменяются только незавершённые FFT/FRF-задачи; готовые
  результаты и отдельные параметры каждого документа сохраняются. Добавлены
  регрессионные проверки переключения и закрытия файлов.
- Added concurrent work with multiple source files. The Open dialog supports
  multi-select, drag-and-drop adds every supplied file, and one background
  loader processes them sequentially.
- Each file is now an independent document with its own channels and colors,
  formulas and filtering, time selection, Time/FFT/FRF mode, spectrum and FRF
  caches, measurement annotations, and display settings. Switching documents
  moves state between active and inactive slots without copying large sample
  arrays.
- Added a prominent top-bar `Files (N): <name>` selector for fast document
  switching and an adjacent Close button. `File → Open files` remains as an
  alternative list.
- Switching cancels only unfinished FFT/FRF tasks; completed results and each
  document's settings remain available. Added regression coverage for document
  switching and closing.

## v0.14.0

- Полностью переработано «Сохранить как»: теперь оно явно разделяет проект,
  обработанные каналы и исходные каналы. Проект сохраняет исходные отсчёты и
  все восстанавливаемые параметры; обработанные каналы записываются с уже
  применёнными формулами и фильтром; исходные каналы сохраняются без обработки.
  В диалоге убрана лишняя верхняя подсказка, проект стоит первым и оставляет
  доступными только имя и расположение файла.
- Добавлен переносимый формат проекта `.AMSig`. При первом запуске AMSignal
  регистрирует ассоциацию этого расширения в профиле текущего пользователя
  Windows, поэтому проекты открываются двойным кликом без прав администратора.
- Горячие клавиши сохранения приведены к однозначной схеме: `Ctrl+S` сохраняет
  текущий проект и запрашивает имя для нового, `Ctrl+Shift+S` открывает
  «Сохранить как», `Ctrl+Alt+S` экспортирует PNG. Прежняя стандартная
  привязка `Ctrl+S` для PNG автоматически переносится при загрузке настроек.
- Добавлены регрессионные проверки исходного и проектного экспорта, восстановления
  настроек проекта и стандартных сочетаний клавиш. Сценарии сборки дополнены
  библиотеками Windows, нужными для регистрации пользовательской ассоциации.
- Reworked the entire `Save as` flow around three explicit choices: project,
  processed channels, and original channels. A project stores raw samples and
  every restorable setting; processed-channel exports bake in formulas and
  filters; original-channel exports remain unprocessed. The redundant heading
  was removed, and the first project option only permits naming and locating
  the file.
- Added the portable `.AMSig` project format. On first run, AMSignal registers
  a per-user Windows association, so projects open by double-click without
  administrator rights.
- Standard save shortcuts are now unambiguous: `Ctrl+S` saves the current
  project or asks for a new project location, `Ctrl+Shift+S` opens `Save as`,
  and `Ctrl+Alt+S` exports PNG. The previous default `Ctrl+S` PNG binding is
  migrated automatically when settings load.
- Added regression coverage for raw and project export, project-setting recovery,
  and the default shortcuts. Build scripts now link the Windows libraries used
  for the per-user file association.

## v0.13.6

- Во всех редактируемых полях AMSignal клавиша Enter теперь подтверждает
  введённое значение. В панели АЧХ она запускает расчёт из поля длины сегмента
  и применяет диапазон из полей частоты; в панели каналов подтверждает общий
  коэффициент и имя группы точек; в настройках сохраняет подписи осей. В
  числовых и диапазонном диалогах Enter активирует основное действие. Прежнее
  поведение индивидуального множителя и переименования канала сохранено.
- Переключатели языка, светлой и тёмной темы собраны в одну верхнюю строку
  раздела «Общие», без отдельной подписи темы. Русская подпись тёмной темы
  приведена к написанию «Темная тема».
- Карта архитектуры и правила проекта уточнены: Enter означает подтверждение
  значения в редактируемом поле и запуск его явного действия либо сохранение
  значения при потере фокуса.
- Enter now confirms a value in every editable AMSignal field. In the FRF
  panel it starts calculation from the segment-length field and applies the
  entered frequency range; in the channel panel it confirms the global
  coefficient and a point-group name; in Settings it saves axis labels.
  Numeric and range dialogs activate their primary action with Enter. Existing
  channel-multiplier and channel-renaming behaviour is retained.
- Language, Light-theme, and Dark-theme controls are grouped into one top row
  in General Settings, with no separate theme label. The Russian Dark-theme
  caption was also normalized to «Темная тема».
- The architecture map and project guidance now explicitly document that Enter
  confirms editable-field input by invoking its explicit action or committing
  the value on focus loss.

## v0.13.5

- Приведены к палитре AMSignal выпадающие списки метода и сглаживания АЧХ,
  выбора клавиши, формата и области экспорта, а также режима и топологии
  фильтра. Закрытая часть списков имеет собственные скруглённую рамку,
  индикатор фокуса и стрелку; пункты сохраняют owner-draw оформление.
- The FRF method and smoothing, hotkey key, export format and range, and
  filter mode and topology drop-downs now use the AMSignal palette. Their
  closed fields have a rounded frame, focus indicator, and custom arrow while
  preserving owner-drawn list items.
- Меню «Файл → Недавние файлы» получило оформление вложенного меню приложения:
  каждый файл отображается карточкой с именем и приглушённым путём. Исправлено
  определение уровня вложенных popup-меню.
- The `File → Recent files` menu now uses the nested AMSignal menu treatment:
  every entry is a card with a file name and muted path. Popup nesting levels
  are now classified correctly.
- В панели каналов индивидуальный множитель перенесён в компактное поле справа
  от имени канала. Поле применяет значение как формулу `coefficient*x` по
  Enter или при потере фокуса и использует тематическую рамку вместо тяжёлого
  системного края.
- The channel panel now has a compact per-channel multiplier field beside each
  channel name. It applies `coefficient*x` on Enter or focus loss and uses a
  themed frame instead of the heavy system edge.

## v0.13.4

- В нижней строке состояния во всех рабочих режимах теперь показана подпись
  `AMSignal · Alexander Muleev · al.muleev@gmail.com`. Рабочий текст не
  перекрывает её, а скрытый нативный статус-контрол больше не закрывает
  отрисованную строку. В PNG-экспорте добавлена подпись `Generated by AMSignal`
  в свободном нижнем правом поле.
- The status bar in every working mode now shows
  `AMSignal · Alexander Muleev · al.muleev@gmail.com`. Its owner-drawn content
  is no longer covered by the hidden native status control, and working text
  does not overlap the credit. PNG exports now include `Generated by AMSignal`
  in the free lower-right area.

## v0.13.3

- Меню выбора ролей АЧХ теперь использует палитру приложения в тёмной теме,
  включая фон, границы, подсветку, текст и флажки. В светлой теме сохранено
  нативное меню Windows. Повторное нажатие на тот же контроль надёжно скрывает
  popup даже при смене фокуса окна.
- The FRF role menu now uses the application palette in Dark theme, including
  its background, borders, hover state, text, and checkmarks. Light theme keeps
  the native Windows menu appearance. A second click on the same control now
  reliably hides the popup even while its window loses focus.
- В АЧХ исправлены маркеры и точки измерения: оба инструмента используют
  координаты Hz/КД, корректно отображаются на логарифмической шкале и не
  смешиваются с аннотациями времени или FFT.
- FRF markers and measurement points are fixed: both use Hz/KD coordinates,
  render correctly on the logarithmic frequency axis, and remain separate from
  Time and FFT annotations.
- В АЧХ кнопка `Точки` теперь открывает встроенную правую панель точек:
  она временно заменяет панель расчёта, а повторное нажатие возвращает её.
  Пункты общих настроек в меню и на стартовом экране сохранены отдельно.
- In FRF, the `Points` button now opens the docked point panel in place
  of the calculation panel; pressing it again restores the FRF controls.
  General Settings remain separately available in the menu and welcome screen.

## v0.13.2

- Выпущена стабилизированная версия выбора ролей АЧХ: постоянное системно
  оформленное меню, скруглённые границы, выбор без скрытия правой панели,
  независимая очистка текущей роли через `Clear` и отсутствие предвыбора
  каналов как для нового, так и для загруженного документа.
- Released the stabilized FRF role-selection interface: a persistent
  system-themed menu with rounded corners, selection without hiding the
  right panel, independent clearing of the current role through `Clear`,
  and no preselected channels for either new or loaded documents.

## v0.13.1

- Выбор опор и откликов в АЧХ возвращён к одному меню-подобному Win32-popup с
  системными флажками из первой версии. Изменение флажка сразу обновляет роль и
  запускает нужный пересчёт, но popup остаётся открытым для выбора нескольких
  каналов; остальные контроли правой панели не скрываются. Он закрывается
  кликом вне него или повторным
  нажатием того же контрола. Удалены встроенный редактор ролей, кнопки Apply/Cancel и обмен
  ролями.
- При новом или загруженном документе роли опор и откликов не предвыбраны. Окно
  выбора имеет слегка скруглённые границы. На кнопках выводятся
  имена каналов, если они помещаются, иначе число выбранных каналов; под
  несколькими опорами показывается `AVG of N channels`. Пункт `Clear` очищает
  только открытую роль и оставляет меню открытым. Каналы, уже назначенные
  противоположной роли, видны в списке, но недоступны, поэтому роли не могут
  пересекаться.
- FRF support and response selection has returned to one menu-like Win32 popup
  with the original system checkbox appearance. Each toggle takes effect immediately
  and triggers the required recalculation while the popup remains open for multi-select;
  the remaining right-panel controls stay visible. It closes on an outside click or a second click on the same control. The embedded
  role editor, Apply/Cancel buttons, and role swap action have been removed.
- A new or loaded document starts with no preselected support or response roles.
  The selection popup has lightly rounded corners. Buttons
  show channel names when they fit and a selected-channel count otherwise; multiple
  supports also show `AVG of N channels`. The `Clear` item removes only the open
  role and leaves the menu open. Channels already assigned to the opposite
  role remain visible but disabled, so roles cannot overlap.

## v0.13.0

- Программа переименована в `AMSignal`: обновлены заголовки окон, справка,
  метаданные экспортируемых LVM-файлов, документация и скрипты запуска.
  Файл пользовательских настроек теперь называется `AMS.ini`.
- The application is now named `AMSignal`: window titles, help text, exported
  LVM metadata, documentation, and launch scripts have been updated. The user
  settings file is now named `AMS.ini`.
- Артефакты GUI-релиза теперь используют единый формат
  `AMSignal-<version>-x64.exe`, например `AMSignal-0.13.0-x64.exe`; номер в
  имени файла не содержит префикс `v` тега.
- GUI release artifacts now use the consistent
  `AMSignal-<version>-x64.exe` format, for example `AMSignal-0.13.0-x64.exe`;
  the file version omits the tag's leading `v`.

## v0.12.7

- Добавлен режим АЧХ: независимые наборы опор и откликов, H1/Welch и Direct,
  фоновый расчёт, coherence, логарифмическая частота, экспорт CSV/PNG и
  поддержка нескольких откликов. По вертикали отображается линейный
  коэффициент динамичности `КД = abs(H)`, то есть отношение амплитуды отклика
  к средней амплитуде опор; перевод в dB не используется.
- Added an FRF mode with separate support/response selection, H1/Welch and
  Direct estimators, background calculation, coherence, logarithmic frequency,
  CSV/PNG export, and multiple response curves. The vertical scale is the
  linear dynamic coefficient `KD = abs(H)`, not dB.
- Бины со слабой опорой исключаются из кривой и CSV, а coherence остаётся
  диагностической величиной и не скрывает данные автоматически. Убрана min/max-отрисовка, создававшая вертикальные иглы; сглаживание
  графика на логарифмической частотной шкале выбирается от выключенного до
  1/3 октавы и не меняет исходные данные экспорта.
- Weak-reference bins are excluded from the curve and CSV, while coherence is
  diagnostic and does not hide data automatically. Rendering no longer draws min/max spike columns; optional display-only
  logarithmic smoothing ranges from off to one-third octave.
- Удалены порог и визуальная отметка coherence: coherence остаётся только
  диагностическим значением под курсором и в CSV.
- Removed the coherence threshold and visual marking: coherence remains a
  diagnostic value under the cursor and in CSV.
- Легенда нескольких откликов больше не выводится поверх графика АЧХ.
- The multi-response legend is no longer drawn over the FRF plot.
- Выбор опор и откликов перенесён из двух всплывающих меню в единый диалог с
  двумя списками, проверкой пересечения и обменом ролями.
- Support and response selection moved from popup menus into an editor embedded
  in the FRF panel, with role-overlap validation and a swap action.
- FRF использует общие с Time/FFT точки измерения и вертикальные/горизонтальные
  линии в Hz и КД, включая группы, настройки отображения и Undo/Redo.
- FRF now reuses the Time/FFT measurement points and vertical/horizontal guides
  in Hz and KD, including groups, display settings, and Undo/Redo.

- Добавлены короткие правила `AGENTS.md` и карта `docs/ARCHITECTURE.md` для адресного поиска по проекту. Удалён устаревший `PROJECT_CONTEXT.md`; исторические отчёты перенесены в локальный архив, исключённый из Git. Обновлены ссылки в README.
- Убраны повторные и малоценные условия тестов; сохранены полные сравнения FFT для 10 и 10 000 разрывов, проверки Light Mode, экспорта и истории. Усилена проверка успешности двух расчётов FFT. Пройдены 197 проверок ядра и 141 проверка GUI.
- Added concise agent rules and an architecture map, removed redundant test assertions, and excluded local historical reports from version control. Core and GUI regression suites retain gap, caching, export, and history coverage.

- GUI переведён на самостоятельные модули `.cpp/.hpp`: убраны включения реализаций, вынесены FFT, временная ось, загрузка, боковая панель, настройки и обработчики сообщений. `gui_main.cpp` сокращён с 4869 до 138 строк.
- GUI и интеграционные тесты линкуются с одинаковыми объектными файлами. Добавлены инкрементальная сборка и запуск GUI-тестов через `build_gui.ps1 -Test`; обновлён Makefile. Проверены маршрутизация команд, клавиш и завершение отменённой загрузки.
- GUI implementations now compile as separate modules with explicit headers. The application and integration tests share object files; incremental builds and PowerShell GUI test execution are supported.

- Light Mode больше не пересчитывает FFT при скрытии и повторном показе каналов из текущего расчёта, в том числе во время фонового задания. Новый расчёт требуется при включении канала вне текущего кэша или изменении данных, участка и обработки. Добавлены проверки настоящего асинхронного пути GUI через невидимое служебное окно.

- Повторно проверена склейка для FFT: исправлены короткие разрывы в 2–4 шага, оценка шага при преобладании больших разрывов, зависимость интерполяции от длительности разрыва и влияние отсчётов вне лимита CLI на частотную шкалу.
- Склейка графика использует общее с FFT правило определения пропусков; преобразование координат сохраняет точность при больших разрывах и выполняет обратный поиск по индексам отсчётов.
- Добавлено сравнение всех частотных бинов и амплитуд с эталоном для 10 и 10 000 разрывов, двух каналов, выделенных диапазонов, Light Mode и экспорта. Уточнены ограничения автоматического определения шага и обработка NaN.
- Исправлено определение версии в сценариях сборки и упаковки для Git, отвергающего NUL в качестве файла исключений.
- Rechecked FFT gap compression, cadence estimation with dominant outages, short gaps, jitter correction across huge outages, and sample-cap isolation. Added complete-spectrum reference comparisons and GUI selection/export regressions.

## v0.12.5

- Исправлена потеря одиночных выбросов при автомасштабировании Light Mode и пропуск узких пиков при плотной отрисовке спектра. Диапазоны отрисовки хранятся в double.
- Добавлен режим «Склеивать пропуски времени на графике». Он сжимает все разрывы на экранной оси и не меняет исходные данные, измерения или экспорт.
- Ползунок фильтра применяет изменение после отпускания; одно движение создаёт одно действие Undo. Undo восстанавливает удалённые измерения. История ограничена 128 действиями и 64 МиБ полезной нагрузки.
- Экспортированный спектр открывается непосредственно по сохранённым частотам и амплитудам, без повторного FFT и применения временных формул. Time и временной фильтр для него недоступны.
- Снижены лишние копирования при фильтрации, освобождаются ненужные кэши. Запись метаданных теперь целиком находится в `gui_export_metadata.cpp`.
- CLI поддерживает Unicode-пути Windows. Сборки GUI/CLI маркируются тегом, commit и dirty; добавлены `build_cli.ps1` и CI. `Start GUI.bat` выбирает последнюю собранную программу.
- FFT больше не отклоняет запись из-за неравномерных или округлённых меток времени: добавлена линейная интерполяция на равномерную сетку. Большие разрывы исключаются только из временной шкалы FFT, а все отсчёты выбранного диапазона остаются в расчёте.
- Исправлен масштаб частотной оси после повторного перехода в FFT и завершения фонового расчёта.
- FFT now resamples uneven timestamps and removes large timestamp gaps from its time scale while retaining every selected sample in the calculation.
- Fixed frequency axis fitting when returning to FFT mode after background calculation.

## v0.12.4

- Разделены группы точек для временного и FFT-режимов: у каждого режима теперь свой набор, свой активный элемент и своя отрисовка, чтобы при переключении режимов точки не смешивались.
- Проверены тексты в интерфейсе и релизных строках: русские подписи должны отображаться корректно без `???` и битых символов.
- Point groups are now separated between time and FFT modes, with independent active groups and rendering so markers no longer mix when switching views.
- UI and release text were checked to keep Russian strings readable and avoid `???` or broken characters.

## v0.12.1

- Вынесены крупные блоки интерфейса из `gui_main.cpp` в отдельные `gui_*.cpp/.hpp` модули, чтобы упростить поддержку и дальнейшее развитие проекта.
- Исправлено окно горячих клавиш: добавлен сброс всех привязок к заводским настройкам, расширен список доступных клавиш и устранено исчезновение пунктов в списке и выпадающем поле.
- Файл настроек теперь создаётся под именем `AMGV.ini`.
- Исправлены подписи `Δx`, `Δy` и `1/Δt` в панели точек и связанные элементы интерфейса.
- The GUI was split into separate `gui_*.cpp/.hpp` modules to make `gui_main.cpp` smaller and easier to maintain.
- The hotkeys window now includes a full reset to defaults, a broader key picker, and stable item rendering so entries no longer disappear from the list or combo box.
- The settings file is now created as `AMGV.ini`.
- Point readouts now show `Δx`, `Δy`, and `1/Δt` correctly in the point panel and related UI.

## v0.12.0

- Исправлено отображение русских и английских строк в меню, подсказках и справке; интерфейс снова показывает корректный текст.
- Fixed broken Russian and English text in menus, tooltips, and help so the UI renders readable strings again.

## v0.11.5

- Вынесены обработчики хоткеев, настроек и связанных диалогов в `gui_settings_hotkeys.cpp`, чтобы разгрузить `gui_main.cpp`.
- Extracted hotkey, settings, and related dialog helpers into `gui_settings_hotkeys.cpp` to keep `gui_main.cpp` smaller.
- Удалены подтверждённые неиспользуемые переменные в фильтре и импорте метаданных экспорта.
- Removed confirmed unused variables in the filter and export metadata import path.

## v0.11.4

- Добавлена возможность сохранять скрытые каналы при экспорте.
- Added the ability to keep hidden channels in exported files.
- Добавлена поддержка загрузки файлов `.csv` и восстановления экспортных настроек из встроенных комментариев.
- Added `.csv` file loading and restored export settings from embedded comments.
- Улучшена совместимость экспорта для TXT / CSV / LVM и частотного режима.
- Improved export compatibility for TXT / CSV / LVM and frequency mode.

## v0.11.3

- Упрощён экспорт: отдельные действия для `TXT`, `CSV` и `LVM` сведены в единый `Save as…` с выбором формата, области выгрузки и режима обработки данных.
- Simplified export: separate `TXT`, `CSV`, and `LVM` actions were merged into one `Save as…` flow with format, range, and processing-mode selection.
- В окне экспорта оставлены дополнительные опции для точек, маркеров, направляющих, формул, фильтра и настроек графика.
- The export dialog still lets you include points, markers, guide lines, formulas, filter settings, and graph settings.
- Убран лишний поясняющий текст и уплотнена компоновка окна экспорта.
- Removed the extra explanatory note and tightened the export dialog layout.

## v0.11.1

- Расширен экспорт: теперь отдельно выбираются область выгрузки, состав сохраняемых данных и режим обработки формул/фильтра.
- Added richer export controls: the export range, included data, and formula/filter handling can now be configured independently.
- Обновлён диалог экспорта и описания опций в интерфейсе.
- Updated the export dialog and the option descriptions in the UI.

## v0.11.0

- Ребрендинг проекта: основное имя приложения изменено на `AM Graph Viewer`, а release-файл теперь называется `AMGraphViewer-v0.11.0-win-x64.exe`.
- Rebranded the project so the main app name is now `AM Graph Viewer`, and the release artifact is now `AMGraphViewer-v0.11.0-win-x64.exe`.
- Обновлены build/release-скрипты, ссылки в документации и пользовательские заголовки.
- Updated the build/release scripts, documentation links, and user-facing window titles.

## v0.10.7

- Исправлены подписи в верхнем меню: пункты общих настроек, горячих клавиш, линий и вертикального панорамирования больше не обрезаются.
- Fixed top-menu labels so general settings, hotkeys, line tools, and vertical panning are shown in full.
- Добавлены глобальные подписи осей X/Y, которые отображаются в углах графика и настраиваются отдельно в окне настроек.
- Added global X/Y axis labels rendered in the graph corners, with dedicated settings fields.
- Настройка отображения измерительных значений теперь хранится отдельно для каждой группы точек.
- Measurement read-outs are now stored separately for each point group.
- Улучшена обработка `.lvm`: имена каналов из чередующихся таблиц сохраняются корректнее, а секции времени восстанавливаются точнее.
- Improved `.lvm` parsing: channel names from interleaved tables are preserved more reliably, and section timing is reconstructed more accurately.
- Окна горячих клавиш и выбора диапазона подстроены под размеры экрана и не блокируют основное приложение.
- The hotkeys dialog and range-selection prompt now fit the screen better and no longer block the main app.

## v0.10.5

- Доработана работа с пропущенными промежутками: подписи внутри графика убраны, сами разрывы по-прежнему выделяются, а подробная информация теперь открывается отдельным окном по клику.
- Окно горячих клавиш больше не блокирует основное приложение: оно открывается в пределах рабочей области экрана, при нехватке высоты использует прокрутку и не мешает дальнейшей работе с главным окном.
- Упрощена сборка проекта: версия приложения теперь передаётся через define, а generated-файл `build_version.hpp` удалён из репозитория.
- Reworked gap handling: inline labels are removed from the plot, the highlighted gaps remain visible, and detailed information is now shown in a separate dialog on click.
- The hotkeys window no longer blocks the main app: it stays within the monitor work area, uses scrolling when vertical space is limited, and keeps the rest of the UI interactive.
- Simplified the build pipeline by passing the app version through a define and removing the generated `build_version.hpp` file from the repository.

## v0.10.4

- Переработан welcome-экран: стартовая страница теперь устойчиво адаптируется к разным размерам окна, получила переключатели темы и более согласованную компоновку.
- Light mode и правая рабочая панель доработаны для больших файлов: выбор временного диапазона, скрытие каналов по умолчанию, более аккуратные отступы, единый стиль переключателей и исправления текстовых артефактов при ресайзе.
- Улучшено редактирование в интерфейсе: ввод имени канала завершается по клику вне поля, текстовые поля больше не перехватывают горячие клавиши, а компактная легенда каналов зачёркивает только название скрытого канала.
- Исправлена обработка много-секционных `.lvm` с повреждёнными временными блоками: время секций теперь восстанавливается по `Date` / `Time` / `X0`, а на больших разрывах времени график больше не рисует ложные прямые линии.
- Reworked the welcome screen so the start page adapts cleanly across window sizes, includes theme switching, and keeps a more consistent layout.
- Refined Light mode and the right-side work panel for large files with explicit time-range selection, channels hidden by default, better spacing, unified toggle styling, and resize artefact fixes.
- Improved in-app editing: channel rename closes on outside click, text inputs no longer trigger global hotkeys, and the compact channel legend now strikes through only the hidden channel name.
- Fixed multi-section `.lvm` handling for corrupted time blocks by rebuilding section timing from `Date` / `Time` / `X0`, while large time gaps now break the plot instead of drawing misleading straight lines.

## v0.10.3

- Исправлено обрезание текста Light mode на приветственном экране и в настройках.
- Подсказка Light mode теперь помещается целиком и не подрезается по нижней границе.
- Обновлена версия релиза для текущего набора UI-исправлений.
- Fixed Light mode text clipping on the welcome screen and in Settings.
- The Light mode hint now fits fully and no longer gets clipped at the bottom.
- Bumped the release version for the current UI polish pass.

## v0.10.2

- Добавлен `undo/redo` для изменений в настройках каналов и точек: видимость, переименование, цвета, коэффициенты и параметры отображения точек теперь откатываются через `Ctrl+Z` / `Ctrl+Shift+Z`.
- Added `undo/redo` for channel and point setting changes: visibility, renaming, colours, coefficients, and point display options can now be reverted with `Ctrl+Z` / `Ctrl+Shift+Z`.
- Исправлено некорректное отображение текста на кнопках правой панели после изменения размера окна: подписи больше не вылезают за границы соседних кнопок.
- Fixed button text clipping in the right-side panel after window resizing so labels no longer spill into neighbouring controls.
- Упрощена панель точек: укорочены подписи переключателей, убрана лишняя подсказка под списком каналов, добавлена явная кнопка смены цвета выбранного канала.
- Streamlined the side panels: shorter point toggle labels, the extra channel hint removed, and an explicit colour picker button for the selected channel.
- Привязка точек и маркеров к графику теперь выбирает ближайшую видимую точку по экранному расстоянию, а не только по оси X.
- Point and marker snapping now chooses the nearest visible point by on-screen distance instead of snapping by X only.

## v0.10.1

- Убраны все добавленные подсказки по формулам из правой рабочей панели.
- Removed the newly added formula hints from the right-side work panel.
- Все пользовательские упоминания формул в панели преобразований переименованы в коэффициенты.
- Reworded the transform panel UI so user-facing formula labels are now presented as coefficients.
- Добавлена отдельная кнопка для сброса всех локальных коэффициентов каналов без затрагивания общего коэффициента.
- Added a separate action to reset all per-channel local coefficients without changing the global coefficient.

## v0.10.0

- Добавлена формульная система преобразования сигналов: общая формула для всех графиков и отдельная формула для выбранного канала.
- Added formula-based signal transforms with a shared formula for all charts and a separate formula for the selected channel.
- В правой рабочей панели появились подсказки по формулам, объяснение переменной `x` и примеры выражений.
- Added inline formula help, an explanation for the `x` variable, and ready-to-use expression examples in the right-side work panel.
- Пункт `About` теперь открывает стартовый welcome-экран, а сам экран показывает версию текущей сборки.
- The About action now opens the start welcome screen, which also shows the current build version.

## v0.10.0-rc1

- Добавлена встроенная правая рабочая панель с вкладками для каналов и точек.
- Added a docked right-side work panel with separate tabs for channels and points.
- В панель каналов вынесены быстрые коэффициенты: общий множитель, общее слагаемое и коэффициенты выбранного канала.
- The channel panel now exposes quick transform coefficients: global multiplier, global offset, and per-channel coefficients for the selected channel.
- В панель точек добавлено переименование групп, а отдельное окно настроек очищено от дублирующих блоков каналов и точек.
- Point groups can now be renamed from the panel, while the separate settings window has been reduced to non-duplicated general settings and hotkeys.

## v0.9.3

- Исправлено поведение выделенного диапазона при приближении: индикация больше не пропадает, если текущий экран смещён относительно выделенного окна.
- Fixed selected-range behaviour during zooming: the visual indication no longer disappears when the current viewport moves away from the selected window.
- Штриховка и затемнение теперь подчёркивают именно невыделенную область, а внутри выделенного диапазона оставлена только мягкая подсветка без лишнего визуального шума.
- Hatch shading now emphasizes the non-selected area, while the selected range keeps only a soft tint without extra visual noise.

## v0.9.2

- Добавлено ручное задание точных значений для вертикальных и горизонтальных линий.
- Added manual input for exact vertical and horizontal guide line values.
- Выбор диапазона через `Shift` стал заметнее: остальные участки графика приглушены штриховкой, а маркеры диапазона остаются видимыми.
- Shift-based range selection is now easier to read: the rest of the graph is muted with a subtle hatch, and the range handles stay visible.

## v0.9.1

- Added real application screenshots to the GitHub presentation.
- Promoted the dark main workspace and measurement-group workflow as the primary README visuals.
- Cleaned up screenshot assets so the repository keeps only the selected UI images.

## v0.9.0

- Переработано оформление GitHub-страницы: новый баннер, более аккуратная документация и визуальные превью.
- Reworked the GitHub presentation with a new banner, cleaner documentation, and visual previews.
- Добавлены базовые элементы публичного проекта: лицензия MIT, шаблоны для issues и более аккуратная структура репозитория.
- Added public-project essentials: MIT license, issue templates, and cleaner repository hygiene.
- Добавлены независимые группы точек измерения с отдельными цветами и видимостью.
- Introduced independent measurement point groups with separate colours and visibility.
- Обновлено окно настроек: управление цветом активной группы, цветом выбранной группы и видимостью групп.
- Updated the settings window to manage active point colour, selected group colour, and group visibility.
- Улучшены undo/redo для точек и отображение состояния точек.
- Improved point-related undo/redo and point status reporting.

## v0.8.3

- Восстановлено взаимодействие в окне настроек после прошлых UI-рефакторингов.
- Restored settings interactions after earlier UI refactors.
- Доработано поведение меню и настроек.
- Refined menu and settings behaviour.
- Продолжена полировка темы и согласованности интерфейса.
- Continued polishing theme and interface consistency.

## v0.8.1

- Fixed mojibake in Russian interface labels.
- Refined active button visuals and unified `Auto zoom` naming.
- Clamped edge axis labels so they stay inside the chart area.
- Simplified playback speed selection to direct numeric input.

## v0.8.0

- Rebuilt the welcome screen into a cleaner start page.
- Added a unified settings window for language, hotkeys, markers and measurement options.
- Moved channel renaming into the channel list.
- Added signal transform controls with global and per-channel multiplier/offset.

## v0.5.1

- Fixed strict monotonic time rebuild behaviour.
- Corrected DC/Nyquist FFT edge-bin scaling.
- Improved CLI validation for `--fft-samples`.

## v0.5.0

- Added drag and drop support.
- Added channel renaming.
- Added start/end navigation shortcuts.
- Added vertical panning support.
