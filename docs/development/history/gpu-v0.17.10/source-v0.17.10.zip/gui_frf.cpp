#include "gui_frf.hpp"
#include "gui_frequency_view.hpp"
#include "gui_dialogs.hpp"
#include "gui_analysis_source.hpp"
#include <iomanip>
#include <sstream>
#include "gui_state.hpp"
#include "gui_text.hpp"
#include "gui_processing.hpp"
#include "gui_render.hpp"
#include "gui_status.hpp"
#include "gui_menu.hpp"
#include "gui_controls.hpp"
#include "gui_side_panel.hpp"
#include "gui_settings_window.hpp"
#include "gui_ids.hpp"
#include "recording_source.hpp"
#include "gui_resources.hpp"
#include "gui_recording_processing.hpp"

namespace gui {
lvm::FrfWorker g_frf_worker;
void show_frf_channel_menu(bool supports);
void set_frf_channels_from_menu(bool supports,std::vector<int> selection);
void clear_frf_channel_selection(bool supports);
namespace {
enum {
    InputLabel = 7100, Input, InputSummary, OutputLabel, Output, Processing,
    LowLabel, Low, HighLabel, High, ApplyRange, Method, Source,
    Calculate, // Internal command for Enter in L; no corresponding button.
    EstimatorLabel = 7117, Estimator, LengthLabel, Length,
    SmoothingLabel, Smoothing, AxisScaleLabel, AxisScale, Reference
};
constexpr double smoothing_choices[] = {0, 1.0/24.0, 1.0/12.0, 1.0/6.0, 1.0/3.0};
int smoothing_choice(double octaves) {
    for (int i=0;i<5;++i)
        if (std::fabs(octaves-smoothing_choices[i])<1e-12) return i;
    return 0;
}
HWND control(int id) { return g.frf_panel ? GetDlgItem(g.frf_panel, id) : nullptr; }
const wchar_t* tr(const wchar_t* en, const wchar_t* ru) { return g_str == &kEn ? en : ru; }
void label(int id, const wchar_t* value) { if (HWND h = control(id)) SetWindowTextW(h, value); }
WNDPROC g_frf_edit_proc = nullptr;

LRESULT CALLBACK FrfEditProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg == WM_GETDLGCODE) {
        return CallWindowProcW(g_frf_edit_proc, hwnd, msg, wp, lp) | DLGC_WANTALLKEYS;
    }
    if (msg == WM_KEYDOWN && wp == VK_RETURN) {
        HWND panel = GetParent(hwnd);
        const int action = Calculate;
        SendMessageW(panel, WM_COMMAND, MAKEWPARAM(action, BN_CLICKED),
                     reinterpret_cast<LPARAM>(GetDlgItem(panel, action)));
        return 0;
    }
    return CallWindowProcW(g_frf_edit_proc, hwnd, msg, wp, lp);
}
bool read_segment_length() {
    wchar_t text[64]{};
    GetWindowTextW(control(Length), text, 64);
    double value=0;
    if (!parse_wide_double_text(text,value) || !std::isfinite(value) || value<0 || value>100000000 ||
        std::floor(value)!=value || (value!=0 && (value<4 || std::fmod(value,2)!=0))) {
        MessageBoxW(g.frf_panel, tr(L"Use 0 (Auto), or an even L >= 4.", L"Укажите 0 (Авто) или чётное L ≥ 4."), L"FRF", MB_OK);
        return false;
    }
    g.frf.options.segment_length=static_cast<std::size_t>(value);
    return true;
}
LRESULT CALLBACK FrfPanelProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
        case WM_CREATE: {
            g.frf_panel = hwnd;
            HINSTANCE inst = reinterpret_cast<CREATESTRUCTW*>(lp)->hInstance;
            auto make = [&](int id, const wchar_t* cls, DWORD style, int x, int y, int w, int h) {
                HWND c = CreateWindowExW(0, cls, L"", WS_CHILD | WS_VISIBLE | style, x, y, w, h,
                    hwnd, reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)), inst, nullptr);
                SendMessageW(c, WM_SETFONT, reinterpret_cast<WPARAM>(g.ui_font), TRUE);
            };
            make(InputLabel, L"STATIC", SS_LEFT, 12, 4, 278, 18);
            make(Input, L"BUTTON", BS_OWNERDRAW | WS_TABSTOP, 12, 22, 278, 24);
            make(InputSummary, L"STATIC", SS_LEFT, 12, 47, 278, 24);
            // The active UI font has descenders that do not fit in a standard
            // 18px static control. Reserve their full line box before Outputs.
            make(OutputLabel, L"STATIC", SS_LEFT, 12, 74, 278, 18);
            make(Output, L"BUTTON", BS_OWNERDRAW | WS_TABSTOP, 12, 92, 278, 24);
            make(Processing, L"BUTTON", BS_OWNERDRAW | WS_TABSTOP, 12, 120, 278, 28);
            make(EstimatorLabel, L"STATIC", SS_LEFT, 12, 152, 130, 18);
            make(LengthLabel, L"STATIC", SS_LEFT, 156, 152, 134, 18);
            make(Estimator, L"COMBOBOX", CBS_DROPDOWNLIST | CBS_OWNERDRAWFIXED | CBS_HASSTRINGS | CBS_NOINTEGRALHEIGHT | WS_VSCROLL | WS_TABSTOP, 12, 172, 130, 200);
            make(Length, L"EDIT", WS_BORDER | ES_NUMBER | WS_TABSTOP, 156, 172, 134, 24);
            make(Method, L"STATIC", SS_LEFT, 12, 202, 278, 44);
            make(SmoothingLabel, L"STATIC", SS_LEFT, 12, 250, 92, 18);
            make(Smoothing, L"COMBOBOX", CBS_DROPDOWNLIST | CBS_OWNERDRAWFIXED | CBS_HASSTRINGS | CBS_NOINTEGRALHEIGHT | WS_VSCROLL | WS_TABSTOP, 108, 248, 182, 200);
            make(AxisScaleLabel, L"STATIC", SS_LEFT, 12, 276, 92, 18);
            make(AxisScale, L"COMBOBOX", CBS_DROPDOWNLIST | CBS_OWNERDRAWFIXED | CBS_HASSTRINGS | CBS_NOINTEGRALHEIGHT | WS_VSCROLL | WS_TABSTOP, 108, 274, 182, 100);
            make(Reference, L"BUTTON", BS_OWNERDRAW | WS_TABSTOP, 12, 300, 278, 24);
            make(Source, L"STATIC", SS_LEFT, 12, 326, 278, 28);
            install_themed_combo(control(Estimator));
            install_themed_combo(control(Smoothing));
            install_themed_combo(control(AxisScale));
            for (const int id : {Length}) {
                if (HWND edit = control(id)) {
                    WNDPROC previous = reinterpret_cast<WNDPROC>(
                        SetWindowLongPtrW(edit, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(FrfEditProc)));
                    if (!g_frf_edit_proc) g_frf_edit_proc = previous;
                }
            }
            SendMessageW(control(Estimator), CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(L"H1 (Welch)"));
            SendMessageW(control(Estimator), CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(tr(L"Direct Y/X", L"Прямой Y/X")));
            const wchar_t* const smoothing_en[] = {L"Off",L"1/24 octave",L"1/12 octave",L"1/6 octave",L"1/3 octave"};
            const wchar_t* const smoothing_ru[] = {L"Без сглаживания",L"1/24 октавы",L"1/12 октавы",L"1/6 октавы",L"1/3 октавы"};
            const wchar_t* const* smoothing_text = g_str == &kEn ? smoothing_en : smoothing_ru;
            for (const wchar_t* choice : {smoothing_text[0], smoothing_text[1], smoothing_text[2], smoothing_text[3], smoothing_text[4]})
                SendMessageW(control(Smoothing),CB_ADDSTRING,0,reinterpret_cast<LPARAM>(choice));
            SendMessageW(control(AxisScale),CB_ADDSTRING,0,reinterpret_cast<LPARAM>(tr(L"Logarithmic",L"Логарифмическая")));
            SendMessageW(control(AxisScale),CB_ADDSTRING,0,reinterpret_cast<LPARAM>(tr(L"Linear",L"Линейная")));
            refresh_frf_controls(true);
            return 0;
        }
        case WM_COMMAND: {
            const int id = LOWORD(wp), code = HIWORD(wp);
            if (id==Estimator && code==CBN_SELCHANGE) {
                if (!read_segment_length()) {
                    SendMessageW(control(Estimator),CB_SETCURSEL,g.frf.options.estimator==lvm::FrfEstimator::H1 ? 0 : 1,0);
                    return 0;
                }
                g.frf.options.estimator=SendMessageW(control(Estimator),CB_GETCURSEL,0,0)==1 ?
                    lvm::FrfEstimator::Direct : lvm::FrfEstimator::H1;
                compute_frf_from_current_source();
                return 0;
            }
            if (id==Smoothing && code==CBN_SELCHANGE) {
                const int choice=static_cast<int>(SendMessageW(control(Smoothing),CB_GETCURSEL,0,0));
                if (choice>=0 && choice<5)
                    g.frf.display_smoothing_octaves=smoothing_choices[choice];
                refresh_frf_controls(); set_status(); invalidate_plot();
                return 0;
            }
            if (id==AxisScale && code==CBN_SELCHANGE) {
                g.frf.logarithmic_frequency_axis=SendMessageW(control(AxisScale),CB_GETCURSEL,0,0)!=1;
                sync_frf_frequency_limits();
                refresh_frf_controls(); set_status(); invalidate_plot();
                return 0;
            }
            if ((id==Input || id==Output) && code==BN_CLICKED) {
                show_frf_channel_menu(id==Input);
                return 0;
            }
            if (code != BN_CLICKED && code != BN_DOUBLECLICKED) return 0;
            if (id == Processing) {
                g.frf.apply_processing = !g.frf.apply_processing;
                invalidate_frf();
                compute_frf_from_current_source();
            } else if (id == Reference) {
                g.frf.show_reference_amplitude=!g.frf.show_reference_amplitude;
                refresh_frf_controls(); invalidate_plot();
            } else if (id == Calculate) {
                if (read_segment_length()) compute_frf_from_current_source();
            } else if (id == ApplyRange) {
                handle_frequency_view_command(g.main,MAKEWPARAM(IDC_FREQUENCY_VIEW_APPLY,BN_CLICKED));
            }
            return 0;
        }
        case WM_DRAWITEM: {
            auto* dis = reinterpret_cast<DRAWITEMSTRUCT*>(lp);
            if (!dis || !dis->hwndItem) break;
            if (dis->CtlType == ODT_COMBOBOX && (dis->CtlID == Estimator || dis->CtlID == Smoothing || dis->CtlID == AxisScale)) {
                draw_settings_combo_item(dis);
                return TRUE;
            }
            wchar_t text[128]{}; GetWindowTextW(dis->hwndItem, text, 128);
            if (dis->CtlID == Processing || dis->CtlID == Reference) {
                draw_themed_check_control(dis->hDC, dis->rcItem, text,
                    dis->CtlID == Processing ? g.frf.apply_processing : g.frf.show_reference_amplitude,
                    (dis->itemState & ODS_SELECTED) != 0, true, false, false);
            } else {
                draw_themed_button(dis->hDC, dis->rcItem, text,
                    (dis->itemState & ODS_SELECTED) != 0, false, false);
            }
            return TRUE;
        }
        case WM_MEASUREITEM: {
            auto* mis = reinterpret_cast<MEASUREITEMSTRUCT*>(lp);
            if (mis && mis->CtlType == ODT_COMBOBOX && (mis->CtlID == Estimator || mis->CtlID == Smoothing || mis->CtlID == AxisScale)) {
                measure_settings_combo_item(mis);
                return TRUE;
            }
            break;
        }
        case WM_CTLCOLORSTATIC:
        case WM_CTLCOLORBTN: {
            HDC dc = reinterpret_cast<HDC>(wp);
            SetTextColor(dc, g_theme->text_primary); SetBkMode(dc, TRANSPARENT);
            return reinterpret_cast<LRESULT>(g_panel_brush);
        }
        case WM_CTLCOLOREDIT:
        case WM_CTLCOLORLISTBOX: {
            HDC dc = reinterpret_cast<HDC>(wp);
            SetTextColor(dc, g_theme->text_primary); SetBkColor(dc, g_theme->bg_plot);
            return reinterpret_cast<LRESULT>(g_input_brush);
        }
        case WM_ERASEBKGND: {
            RECT r; GetClientRect(hwnd, &r);
            FillRect(reinterpret_cast<HDC>(wp), &r, g_panel_brush);
            return 1;
        }
        case WM_DESTROY: g.frf_panel = nullptr; return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}
}

std::wstring frf_error_text(lvm::FrfError e) {
    if (e==lvm::FrfError::InvalidChannels) return tr(
        L"Select at least one Support and Response without shared channels.",
        L"Выберите хотя бы одну опору и отклик без общих каналов.");
    if (g_str == &kEn) return to_w(lvm::frf_error_text(e));
    switch (e) {
        case lvm::FrfError::None: return L"";
        case lvm::FrfError::InvalidChannels: break;
        case lvm::FrfError::FrequencyData: return L"Для FRF нужны исходные сигналы во времени.";
        case lvm::FrfError::TooShort: return L"В выбранном участке меньше L отсчётов. Уменьшите L или расширьте участок.";
        case lvm::FrfError::InvalidTime: return L"Временные метки должны быть конечными и строго возрастающими.";
        case lvm::FrfError::MissingValues: return L"В выбранных каналах есть пропущенные или бесконечные значения.";
        case lvm::FrfError::InvalidOptions: return L"Некорректные параметры FRF.";
        case lvm::FrfError::WeakReference: return L"Во входном канале нет достаточного переменного сигнала.";
        case lvm::FrfError::Overflow: return L"Превышены численные ограничения или недостаточно памяти для FRF.";
        case lvm::FrfError::ResourceLimit: return L"Недостаточно ресурсов FRF. Проверьте бюджет данных и место для временных файлов или задайте меньшую длину L для H1.";
        case lvm::FrfError::SourceChanged: return L"Исходный файл изменился. Откройте запись заново перед расчётом АЧХ.";
    }
    return L"Не удалось рассчитать FRF.";
}

namespace {
bool valid_selection(std::vector<int> references,std::vector<int> responses) {
    const int count=static_cast<int>(g.ds.channel_count());
    if (references.empty() || responses.empty()) return false;
    for (auto* list:{&references,&responses}) {
        std::sort(list->begin(),list->end());
        if (list->front()<0 || list->back()>=count || std::adjacent_find(list->begin(),list->end())!=list->end()) return false;
    }
    for (int channel:references) if (std::binary_search(responses.begin(),responses.end(),channel)) return false;
    return true;
}
}

namespace {
struct FrfRoleMenu {
    HWND window=nullptr;
    HFONT font=nullptr;
    bool owns_font=false;
    bool supports=true;
    int width=0, row_height=0, channel_rows=0, clear_top=0, hot_row=-1;
} g_frf_role_menu;
int g_frf_role_menu_suppressed_role=-1;

bool role_menu_disabled(int channel) {
    const auto& opposite=g_frf_role_menu.supports ? g.frf.outputs : g.frf.inputs;
    return std::find(opposite.begin(),opposite.end(),channel)!=opposite.end();
}
void close_frf_role_menu() {
    if (g_frf_role_menu.window) DestroyWindow(g_frf_role_menu.window);
}
bool cursor_over_role_control(bool supports) {
    RECT bounds{};
    if (!GetWindowRect(control(supports ? Input : Output),&bounds)) return false;
    POINT cursor{}; GetCursorPos(&cursor);
    return PtInRect(&bounds,cursor)!=FALSE;
}
int role_menu_row(POINT point) {
    const int row=(point.y-2)/g_frf_role_menu.row_height;
    if (point.y>=2 && row>=0 && row<g_frf_role_menu.channel_rows) return row;
    if (point.y>=g_frf_role_menu.clear_top &&
        point.y<g_frf_role_menu.clear_top+g_frf_role_menu.row_height) return -2;
    return -1;
}
void draw_role_menu(HWND window,HDC dc) {
    RECT area{}; GetClientRect(window,&area);
    const bool dark=g_theme==&kDarkTheme;
    HTHEME theme=dark ? nullptr : OpenThemeData(window,L"MENU");
    if (theme) {
        DrawThemeBackground(theme,dc,MENU_POPUPBACKGROUND,0,&area,nullptr);
        DrawThemeBackground(theme,dc,MENU_POPUPBORDERS,0,&area,nullptr);
    } else {
        HBRUSH background=CreateSolidBrush(dark ? g_theme->bg_panel : GetSysColor(COLOR_MENU));
        FillRect(dc,&area,background); DeleteObject(background);
        if (dark) {
            HBRUSH border=CreateSolidBrush(g_theme->frame);
            FrameRect(dc,&area,border); DeleteObject(border);
        }
    }
    HGDIOBJ previous=SelectObject(dc,g_frf_role_menu.font);
    SetBkMode(dc,TRANSPARENT);
    const auto& selected=g_frf_role_menu.supports ? g.frf.inputs : g.frf.outputs;
    for (int channel=0;channel<g_frf_role_menu.channel_rows;++channel) {
        RECT item{2,2+channel*g_frf_role_menu.row_height,g_frf_role_menu.width-2,
            2+(channel+1)*g_frf_role_menu.row_height};
        const bool disabled=role_menu_disabled(channel);
        const bool checked=std::find(selected.begin(),selected.end(),channel)!=selected.end();
        const bool hot=channel==g_frf_role_menu.hot_row;
        if (theme) {
            DrawThemeBackground(theme,dc,MENU_POPUPITEM,
                disabled ? (hot ? MPI_DISABLEDHOT : MPI_DISABLED) : (hot ? MPI_HOT : MPI_NORMAL),&item,nullptr);
        } else if (hot && !disabled) {
            HBRUSH hover=CreateSolidBrush(dark ? g_theme->btn_hover : GetSysColor(COLOR_HIGHLIGHT));
            FillRect(dc,&item,hover); DeleteObject(hover);
        }
        constexpr int check_size=16;
        const int check_top=item.top+(g_frf_role_menu.row_height-check_size)/2;
        RECT check{item.left+3,check_top,item.left+3+check_size,check_top+check_size};
        if (theme) {
            DrawThemeBackground(theme,dc,MENU_POPUPCHECKBACKGROUND,disabled ? MCB_DISABLED : MCB_NORMAL,&check,nullptr);
            if (checked) DrawThemeBackground(theme,dc,MENU_POPUPCHECK,disabled ? MC_CHECKMARKDISABLED : MC_CHECKMARKNORMAL,&check,nullptr);
        } else if (dark) {
            HBRUSH frame=CreateSolidBrush(g_theme->frame);
            FrameRect(dc,&check,frame); DeleteObject(frame);
            if (checked) {
                HPEN pen=CreatePen(PS_SOLID,2,disabled ? g_theme->text_secondary : g_theme->accent);
                HGDIOBJ old_pen=SelectObject(dc,pen);
                MoveToEx(dc,check.left+4,check.top+(check.bottom-check.top)/2,nullptr);
                LineTo(dc,check.left+8,check.bottom-5);
                LineTo(dc,check.right-4,check.top+4);
                SelectObject(dc,old_pen); DeleteObject(pen);
            }
        } else {
            DrawFrameControl(dc,&check,DFC_BUTTON,DFCS_BUTTONCHECK|(checked ? DFCS_CHECKED : 0)|(disabled ? DFCS_INACTIVE : 0));
        }
        SetTextColor(dc,dark ? (disabled ? g_theme->text_secondary : g_theme->text_primary) :
            GetSysColor(disabled ? COLOR_GRAYTEXT : (hot ? COLOR_HIGHLIGHTTEXT : COLOR_MENUTEXT)));
        const std::wstring name=std::to_wstring(channel+1)+L": "+channel_display_label(channel);
        RECT text{check.right+4,item.top,item.right-6,item.bottom};
        DrawTextW(dc,name.c_str(),-1,&text,DT_LEFT|DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS);
    }
    RECT separator{2,g_frf_role_menu.clear_top-5,g_frf_role_menu.width-2,g_frf_role_menu.clear_top-1};
    if (theme) DrawThemeBackground(theme,dc,MENU_POPUPSEPARATOR,0,&separator,nullptr);
    else {
        HBRUSH separator_brush=CreateSolidBrush(dark ? g_theme->separator : GetSysColor(COLOR_MENU));
        FillRect(dc,&separator,separator_brush); DeleteObject(separator_brush);
    }
    const bool can_clear=!selected.empty();
    const bool clear_hot=g_frf_role_menu.hot_row==-2;
    RECT clear{2,g_frf_role_menu.clear_top,g_frf_role_menu.width-2,
        g_frf_role_menu.clear_top+g_frf_role_menu.row_height};
    if (theme) {
        DrawThemeBackground(theme,dc,MENU_POPUPITEM,
            can_clear ? (clear_hot ? MPI_HOT : MPI_NORMAL) : (clear_hot ? MPI_DISABLEDHOT : MPI_DISABLED),&clear,nullptr);
    } else if (clear_hot && can_clear) {
        HBRUSH hover=CreateSolidBrush(dark ? g_theme->btn_hover : GetSysColor(COLOR_HIGHLIGHT));
        FillRect(dc,&clear,hover); DeleteObject(hover);
    }
    SetTextColor(dc,dark ? (can_clear ? g_theme->text_primary : g_theme->text_secondary) :
        GetSysColor(can_clear ? (clear_hot ? COLOR_HIGHLIGHTTEXT : COLOR_MENUTEXT) : COLOR_GRAYTEXT));
    RECT clear_text{27,clear.top,clear.right-6,clear.bottom};
    DrawTextW(dc,tr(L"Clear",L"Очистить"),-1,&clear_text,DT_LEFT|DT_VCENTER|DT_SINGLELINE);
    SelectObject(dc,previous);
    if (theme) CloseThemeData(theme);
}
LRESULT CALLBACK FrfRoleMenuProc(HWND window,UINT message,WPARAM wp,LPARAM lp) {
    switch (message) {
        case WM_CREATE: {
            return 0;
        }
        case WM_PAINT: {
            PAINTSTRUCT paint{}; HDC dc=BeginPaint(window,&paint);
            draw_role_menu(window,dc); EndPaint(window,&paint);
            return 0;
        }
        case WM_MOUSEMOVE: {
            TRACKMOUSEEVENT track{sizeof(track),TME_LEAVE,window,0};
            TrackMouseEvent(&track);
            POINT point{GET_X_LPARAM(lp),GET_Y_LPARAM(lp)};
            const int row=role_menu_row(point);
            if (row!=g_frf_role_menu.hot_row) {
                g_frf_role_menu.hot_row=row;
                InvalidateRect(window,nullptr,FALSE);
            }
            return 0;
        }
        case WM_MOUSELEAVE:
            if (g_frf_role_menu.hot_row!=-1) {
                g_frf_role_menu.hot_row=-1;
                InvalidateRect(window,nullptr,FALSE);
            }
            return 0;
        case WM_LBUTTONUP: {
            POINT point{GET_X_LPARAM(lp),GET_Y_LPARAM(lp)};
            const int channel=role_menu_row(point);
            if (channel==-2) {
                clear_frf_channel_selection(g_frf_role_menu.supports);
                InvalidateRect(window,nullptr,FALSE);
            } else if (channel>=0 && !role_menu_disabled(channel)) {
                auto selected=g_frf_role_menu.supports ? g.frf.inputs : g.frf.outputs;
                auto it=std::find(selected.begin(),selected.end(),channel);
                if (it==selected.end()) selected.push_back(channel); else selected.erase(it);
                set_frf_channels_from_menu(g_frf_role_menu.supports,std::move(selected));
                InvalidateRect(window,nullptr,FALSE);
            }
            return 0;
        }
        case WM_KEYDOWN:
            if (wp==VK_ESCAPE) { close_frf_role_menu(); return 0; }
            return 0;
        case WM_ERASEBKGND:
            return 1;
        case WM_ACTIVATE:
            if (LOWORD(wp)==WA_INACTIVE) {
                if (cursor_over_role_control(g_frf_role_menu.supports))
                    g_frf_role_menu_suppressed_role=g_frf_role_menu.supports ? 1 : 0;
                PostMessageW(window,WM_CLOSE,0,0);
            }
            return 0;
        case WM_CLOSE: DestroyWindow(window); return 0;
        case WM_DESTROY:
            if (g_frf_role_menu.owns_font) DeleteObject(g_frf_role_menu.font);
            g_frf_role_menu={};
            return 0;
    }
    return DefWindowProcW(window,message,wp,lp);
}
}

void show_frf_channel_menu(bool supports) {
    const int role=supports ? 1 : 0;
    if (g_frf_role_menu_suppressed_role==role) {
        g_frf_role_menu_suppressed_role=-1;
        return;
    }
    g_frf_role_menu_suppressed_role=-1;
    if (g_frf_role_menu.window) {
        if (g_frf_role_menu.supports==supports) { close_frf_role_menu(); return; }
        close_frf_role_menu();
    }
    static bool registered=false;
    if (!registered) {
        WNDCLASSW window_class{}; window_class.hInstance=GetModuleHandleW(nullptr);
        window_class.lpfnWndProc=FrfRoleMenuProc; window_class.hCursor=LoadCursor(nullptr,IDC_ARROW);
        window_class.lpszClassName=L"AMSignalFrfRoleMenu";
        RegisterClassW(&window_class); registered=true;
    }
    NONCLIENTMETRICSW metrics{};
    metrics.cbSize=sizeof(metrics);
    SystemParametersInfoW(SPI_GETNONCLIENTMETRICS,sizeof(metrics),&metrics,0);
    g_frf_role_menu.font=CreateFontIndirectW(&metrics.lfMenuFont);
    g_frf_role_menu.owns_font=g_frf_role_menu.font!=nullptr;
    if (!g_frf_role_menu.font) g_frf_role_menu.font=static_cast<HFONT>(GetStockObject(DEFAULT_GUI_FONT));
    RECT anchor{}; GetWindowRect(control(supports ? Input : Output),&anchor);
    HDC dc=GetDC(nullptr); HGDIOBJ previous=SelectObject(dc,g_frf_role_menu.font);
    int widest=anchor.right-anchor.left;
    for (std::size_t c=0;c<g.ds.channel_count();++c) {
        const std::wstring name=std::to_wstring(c+1)+L": "+channel_display_label(static_cast<int>(c));
        SIZE size{}; GetTextExtentPoint32W(dc,name.c_str(),static_cast<int>(name.size()),&size);
        widest=std::max(widest,static_cast<int>(size.cx)+40);
    }
    SelectObject(dc,previous); ReleaseDC(nullptr,dc);
    g_frf_role_menu.supports=supports;
    g_frf_role_menu.width=std::min(std::max(widest,180),500);
    g_frf_role_menu.row_height=std::max(GetSystemMetrics(SM_CYMENU),20);
    g_frf_role_menu.channel_rows=static_cast<int>(g.ds.channel_count());
    g_frf_role_menu.clear_top=2+g_frf_role_menu.channel_rows*g_frf_role_menu.row_height+5;
    const int height=g_frf_role_menu.clear_top+g_frf_role_menu.row_height+2;
    g_frf_role_menu.window=CreateWindowExW(WS_EX_TOOLWINDOW,L"AMSignalFrfRoleMenu",L"",WS_POPUP|WS_BORDER,
        anchor.left,anchor.bottom,g_frf_role_menu.width,height,g.main,nullptr,GetModuleHandleW(nullptr),nullptr);
    if (g_frf_role_menu.window) {
        HRGN rounded=CreateRoundRectRgn(0,0,g_frf_role_menu.width+1,height+1,10,10);
        if (!SetWindowRgn(g_frf_role_menu.window,rounded,TRUE)) DeleteObject(rounded);
        ShowWindow(g_frf_role_menu.window,SW_SHOWNORMAL);
    }
}

bool set_frf_channels(std::vector<int> references,std::vector<int> responses) {
    if (!valid_selection(references,responses)) return false;
    std::sort(references.begin(),references.end()); std::sort(responses.begin(),responses.end());
    if (references==g.frf.inputs && responses==g.frf.outputs) return true;
    g.frf.inputs=std::move(references); g.frf.outputs=std::move(responses);
    invalidate_frf();
    if (g.mode==AnalysisMode::FRF) compute_frf_from_current_source();
    refresh_frf_controls();
    return true;
}
void set_frf_channels_from_menu(bool supports,std::vector<int> selection) {
    std::sort(selection.begin(),selection.end());
    selection.erase(std::unique(selection.begin(),selection.end()),selection.end());
    auto references=supports ? selection : g.frf.inputs;
    auto responses=supports ? g.frf.outputs : selection;
    const auto& other=supports ? responses : references;
    selection.erase(std::remove_if(selection.begin(),selection.end(),[&](int channel) {
        return std::find(other.begin(),other.end(),channel)!=other.end();
    }),selection.end());
    if (supports) references=selection; else responses=selection;
    if (references==g.frf.inputs && responses==g.frf.outputs) return;
    g.frf.inputs=std::move(references); g.frf.outputs=std::move(responses);
    invalidate_frf();
    if (g.mode==AnalysisMode::FRF) compute_frf_from_current_source();
    refresh_frf_controls();
}
void clear_frf_channel_selection(bool supports) {
    set_frf_channels_from_menu(supports,{});
}
std::wstring frf_curve_label(std::size_t response) {
    if (response>=g.frf.output_names.size()) return L"";
    return g.frf.output_names[response]+L" / "+g.frf.input_name;
}

void invalidate_frf(bool reset_view) {
    g_frf_worker.cancel();
    ++g.frf.generation;
    g.frf.pending = false; g.frf.attempted = false;
    g.frf.result = {};
    if (reset_view) { g.frf.view_initialized = false; g.frf.auto_y = true; }
}

namespace {
void replay_frf_recording(const lvm::RecordingSource& recording,
                         const lvm::RecordingReadRequest& request,
                         const lvm::RecordingBlockConsumer& consume,
                         const std::atomic<bool>* cancel) {
    try { recording.replay(request,consume,cancel); }
    catch(const lvm::RecordingFailure& failure) {
        if(failure.error==lvm::RecordingError::SourceChanged)
            throw lvm::FrfSourceFailure(lvm::FrfError::SourceChanged);
        if(failure.error==lvm::RecordingError::ResourceLimit)
            throw lvm::FrfSourceFailure(lvm::FrfError::ResourceLimit);
        throw;
    }
}
bool current_frf_source_window(double& a,double& b,bool& selected) {
    return current_fft_source_window(a,b,selected);
}
}
void refresh_frf_channel_names() {
    g.frf.input_name.clear();g.frf.output_names.clear();
    for(int c:g.frf.inputs) {
        if(!g.frf.input_name.empty())g.frf.input_name+=L", ";
        g.frf.input_name+=channel_display_label(c);
    }
    if(g.frf.inputs.size()>1)g.frf.input_name=L"AVG("+g.frf.input_name+L")";
    for(int c:g.frf.outputs)g.frf.output_names.push_back(channel_display_label(c));
}
void compute_frf_from_current_source() {
    invalidate_frf();
    g.frf.attempted = true;
    double a = 0, b = 0; bool selected = false;
    lvm::FrfBatchResult failure;
    failure.options=g.frf.options;
    if(g.loaded_source_stamp_valid) {
        std::error_code ec;
        const auto path=std::filesystem::path(g.source_path);
        if(std::filesystem::file_size(path,ec)!=g.loaded_source_size || ec ||
           std::filesystem::last_write_time(path,ec)!=g.loaded_source_modified || ec)
            failure.error=lvm::FrfError::SourceChanged;
    }
    if(failure.error!=lvm::FrfError::None) {
        g_frf_worker.clear_cache();apply_frf_result(std::move(failure));return;
    }
    if (g.ds.frequency_axis) failure.error = lvm::FrfError::FrequencyData;
    else if (!valid_selection(g.frf.inputs,g.frf.outputs)) failure.error=lvm::FrfError::InvalidChannels;
    else if (!current_frf_source_window(a, b, selected)) failure.error = lvm::FrfError::TooShort;
    if (failure.error != lvm::FrfError::None) { apply_frf_result(std::move(failure)); return; }
    g.frf.source_start = a; g.frf.source_end = b; g.frf.from_selection = selected;
    if(g.frf.apply_processing && g.noise_threshold_enabled)share_resident_recording();
    refresh_frf_channel_names();
    try {
        auto resources=current_analysis_resources();
        g.frf.attempted=true;
        if(!resources.memory_bytes)throw lvm::FrfSourceFailure(lvm::FrfError::ResourceLimit);
        std::vector<std::size_t> channels(g.frf.inputs.begin(),g.frf.inputs.end());
        channels.insert(channels.end(),g.frf.outputs.begin(),g.frf.outputs.end());
        ensure_channel_formula_vectors();
        g.frf.processing_description = L"raw";
        if (g.frf.apply_processing) {
            g.frf.processing_description = L"global=" + g.global_formula +
                L"; filter=" + std::to_wstring(g.noise_threshold_enabled) +
                L"; mode=" + std::to_wstring(g.noise_threshold_mode) +
                L"; topology=" + std::to_wstring(g.noise_threshold_topology) +
                L"; low=" + format_optional_edit_number(g.noise_threshold_min) +
                L"; high=" + format_optional_edit_number(g.noise_threshold_max);
            for (auto c:channels) g.frf.processing_description+=L"; channel["+std::to_wstring(c)+L"]="+g.channel_formulas[c];
        }
        if (g.main) {
            g.frf.pending = true;
            std::ostringstream key;
            const auto path=std::filesystem::path(g.source_path);
            std::error_code ec;
            const auto file_size=std::filesystem::file_size(path,ec);
            const auto modified=ec ? std::filesystem::file_time_type{} : std::filesystem::last_write_time(path,ec);
            key << path.u8string().size() << ':' << path.u8string() << ':' << file_size << ':'
                << modified.time_since_epoch().count() << ':' << g.numerical_revision << ':'
                << std::hexfloat << a << ':' << b << ':' << g.frf.apply_processing << ':' << g.frf.inputs.size();
            for(auto c:channels)key << ':' << c;
            // Revision is separate from generation; the processing description
            // also captures undo-restored formula/filter values exactly.
            key << ':' << g.frf.processing_description.size();
            for(auto c:g.frf.processing_description)key << ':' << static_cast<unsigned>(c);
            const auto input_key=key.str();
            if(!g_frf_worker.submit_cached(g.frf.options,g.frf.generation,input_key,resources)) {
                // The previous key cannot serve this request. Free its cache
                // before admitting a new input; active cancelled work still owns it.
                g_frf_worker.clear_cache();
                resources=current_analysis_resources();g.frf.attempted=true;
                const auto lo=std::lower_bound(g.ds.time.begin(),g.ds.time.end(),a);
                const auto hi=std::upper_bound(g.ds.time.begin(),g.ds.time.end(),b);
                const bool stream=(g.recording_source && g.ds.rows()<3 && g.recording_rows>g.ds.rows()) ||
                    (g.current_file_partial && g.source_scan_index) ||
                    (1024.0L*1024+static_cast<long double>(hi-lo)*(channels.size()+1)*8+
                     std::min<std::size_t>(hi-lo,1048576)*16.0L)>resources.budget->available()/2;
                if(stream && (ec || g.ds.source_columns.size()!=g.ds.channel_count()))
                    throw std::runtime_error("Streaming FRF requires an unchanged source file and physical column mapping.");
                if(stream && !ec && g.ds.source_columns.size()==g.ds.channel_count()) {
                    resources=current_analysis_resources(48ULL*1024*1024);g.frf.attempted=true;
                    const auto recording=current_recording_source();
                    lvm::RecordingReadRequest read;
                    read.range=lvm::AnalysisRange::selected(a,b);
                    read.channels=channels;
                    constexpr std::uint64_t preparation_base=32ULL*1024*1024;
                    const auto available=resources.budget->available();
                    if(available<=preparation_base+1024*1024)throw lvm::FrfSourceFailure(lvm::FrfError::ResourceLimit);
                    read.block_bytes=static_cast<std::size_t>(std::min<std::uint64_t>(16ULL*1024*1024,(available-preparation_base)/2));
                    auto reservation=resources.budget->reserve(preparation_base+read.block_bytes);
                    if(!reservation)throw lvm::FrfSourceFailure(lvm::FrfError::ResourceLimit);
                    const bool processing=g.frf.apply_processing, filtering=processing && g.noise_threshold_enabled;
                    const auto global=g.global_formula_rpn;
                    const bool global_identity=g.global_formula_identity, global_affine=g.global_formula_affine;
                    const double global_mul=g.global_formula_mul, global_add=g.global_formula_add;
                    std::vector<char> formula_identity;
                    std::vector<std::vector<FormulaToken>> formulas;
                    std::vector<TransformRuntimeKind> kinds;
                    std::vector<double> mul,add;
                    for(auto c:channels) {
                        formulas.push_back(g.channel_formula_rpn[c]);kinds.push_back(g.channel_transform_kind[c]);
                        formula_identity.push_back(g.channel_formula_identity[c]);
                        mul.push_back(g.channel_transform_mul[c]);add.push_back(g.channel_transform_add[c]);
                    }
                    FilterSettings filter{g.noise_threshold_mode,g.noise_threshold_topology,
                        g.noise_threshold_min,g.noise_threshold_max,current_filter_sample_step()};
                    const bool full_filter=filtering && (a<g.ds.time.front() || b>g.ds.time.back());
                    // Filters warm up from the loaded recording's first sample,
                    // rather than resetting at the selected window or a block.
                    if(filtering)read.range.interval.start=full_filter && g.source_scan_index
                        ? g.source_scan_index->range_start : std::min(a,g.ds.time.front());
                    lvm::FrfSource source;source.references=g.frf.inputs.size();source.responses=g.frf.outputs.size();
                    if(g.overview.index) {
                        const auto rows=g.overview.index->sample_range(lvm::AnalysisRange::selected(a,b));
                        source.expected_samples=static_cast<std::size_t>(rows.second-rows.first);
                    } else if(a<=recording->bounds().start && b>=recording->bounds().end)source.expected_samples=g.recording_rows;
                    const auto shared_processed=g.overview.render_enabled ? processed_recording_source(processing,0,resources.budget) : nullptr;
                    source.replay=[shared_processed,recording,read,a,processing,filtering,filter,full_filter,global,formulas,kinds,mul,add,
                                   global_identity,global_affine,global_mul,global_add,formula_identity]
                        (const lvm::FrfBlockConsumer& consume,const std::atomic<bool>* cancel) {
                        if(shared_processed) {
                            auto exact=read;exact.range=lvm::AnalysisRange::selected(a,read.range.interval.end);
                            replay_frf_recording(*shared_processed,exact,consume,cancel);return;
                        }
                        auto effective_filter=filter;
                        if(full_filter) {
                            lvm::FrfSource timeline;
                            auto time_read=read;time_read.channels.clear();
                            time_read.range.interval.end=recording->bounds().end;
                            timeline.replay=[recording,time_read](const auto& visitor,const auto* flag) {
                                replay_frf_recording(*recording,time_read,visitor,flag);
                            };
                            const auto inspected=lvm::inspect_frf_timeline(timeline,cancel);
                            if(inspected.error!=lvm::FrfError::None)throw lvm::FrfSourceFailure(inspected.error);
                            effective_filter.sample_step=inspected.sample_dt;
                        }
                        std::vector<FilterStream> filters;
                        for(std::size_t c=0;c<formulas.size();++c)filters.emplace_back(effective_filter);
                        const auto process_block=[&](const auto& time,const auto& raw) {
                            auto values=raw; // One bounded block, never the recording.
                            if(processing)for(std::size_t c=0;c<values.size();++c) {
                                for(std::size_t i=0;i<values[c].size();++i) {
                                    if(cancel && (i & 4095)==0 && cancel->load())throw std::runtime_error("Operation cancelled.");
                                    const double x=values[c][i];
                                    if(kinds[c]==TransformRuntimeKind::Affine)values[c][i]=x*mul[c]+add[c];
                                    else if(kinds[c]==TransformRuntimeKind::CachedFormula) {
                                        const auto y=global_identity ? x : (global_affine ? x*global_mul+global_add : eval_formula_rpn(global,x));
                                        const auto z=std::isfinite(y) ? (formula_identity[c] ? y : eval_formula_rpn(formulas[c],y))
                                            : std::numeric_limits<double>::quiet_NaN();
                                        values[c][i]=std::isfinite(z) ? z : std::numeric_limits<double>::quiet_NaN();
                                    }
                                }
                                if(filtering)values[c]=filters[c].process(time,values[c],cancel);
                            }
                            const auto start=std::lower_bound(time.begin(),time.end(),a)-time.begin();
                            if(start==static_cast<std::ptrdiff_t>(time.size()))return;
                            if(!start)consume(time,values);
                            else {
                                std::vector<double> selected_time(time.begin()+start,time.end());
                                for(auto& column:values)column.erase(column.begin(),column.begin()+start);
                                consume(selected_time,values);
                            }
                        };
                        replay_frf_recording(*recording,read,process_block,cancel);
                    };
                    g_frf_worker.submit(std::move(source),g.frf.options,g.frf.generation,input_key,resources,std::move(reservation));
                } else {
                    auto reservation=reserve_analysis_input(resources,static_cast<std::size_t>(hi-lo),channels.size(),true);
                    lvm::Dataset pair;
                    build_time_window_dataset(g.ds,a,b,pair,&channels,g.frf.apply_processing);
                    lvm::FrfBatchInput input;input.time=std::move(pair.time);
                    for(std::size_t i=0;i<pair.channels.size();++i)
                        (i<g.frf.inputs.size() ? input.references : input.responses).push_back(std::move(pair.channels[i]));
                    g_frf_worker.submit(std::move(input),g.frf.options,g.frf.generation,input_key,resources,std::move(reservation));
                }
            }
            refresh_frf_controls(); set_status(); invalidate_plot();
        } else {
            const auto lo=std::lower_bound(g.ds.time.begin(),g.ds.time.end(),a);
            const auto hi=std::upper_bound(g.ds.time.begin(),g.ds.time.end(),b);
            auto reservation=reserve_analysis_input(resources,static_cast<std::size_t>(hi-lo),channels.size(),true);
            lvm::Dataset pair;
            build_time_window_dataset(g.ds,a,b,pair,&channels,g.frf.apply_processing);
            lvm::FrfBatchInput input;input.time=std::move(pair.time);
            for(std::size_t i=0;i<pair.channels.size();++i)
                (i<g.frf.inputs.size() ? input.references : input.responses).push_back(std::move(pair.channels[i]));
            auto prepared=lvm::prepare_frf_batch(std::move(input),nullptr,reservation);
            if(!reservation->shrink_to(prepared->resident_bytes))throw lvm::FrfSourceFailure(lvm::FrfError::ResourceLimit);
            apply_frf_result(lvm::compute_prepared_frf(*prepared,g.frf.options,nullptr,resources));
        }
    } catch (const lvm::FrfSourceFailure& error) {
        failure.error=error.error;apply_frf_result(std::move(failure));
    } catch (const std::bad_alloc&) {
        failure.error=lvm::FrfError::ResourceLimit;apply_frf_result(std::move(failure));
    } catch (const lvm::RecordingFailure& error) {
        failure.error = error.error==lvm::RecordingError::SourceChanged ? lvm::FrfError::SourceChanged :
            (error.error==lvm::RecordingError::ResourceLimit ? lvm::FrfError::ResourceLimit : lvm::FrfError::Overflow);
        apply_frf_result(std::move(failure));
    } catch (...) {
        failure.error = lvm::FrfError::Overflow;
        apply_frf_result(std::move(failure));
    }
}

bool ensure_current_frf() {
    double start = 0, end = 0; bool selected = false;
    if(g.frf.result.ok && g.loaded_source_stamp_valid) {
        std::error_code ec;const auto path=std::filesystem::path(g.source_path);
        if(std::filesystem::file_size(path,ec)!=g.loaded_source_size || ec ||
           std::filesystem::last_write_time(path,ec)!=g.loaded_source_modified || ec)invalidate_frf();
    }
    if (g.frf.attempted && !g.frf.pending &&
        (g.frf.result.options.estimator!=g.frf.options.estimator ||
         g.frf.result.options.segment_length!=g.frf.options.segment_length ||
         g.frf.result.options.remove_mean!=g.frf.options.remove_mean ||
         g.frf.result.options.window!=g.frf.options.window ||
         g.frf.result.options.reference_threshold!=g.frf.options.reference_threshold))
        invalidate_frf();
    if (g.frf.attempted && current_frf_source_window(start, end, selected) &&
        (start != g.frf.source_start || end != g.frf.source_end || selected != g.frf.from_selection))
        invalidate_frf();
    if (!g.frf.attempted) compute_frf_from_current_source();
    return g.frf.result.ok && !g.frf.pending;
}

void apply_frf_result(lvm::FrfBatchResult result) {
    auto reservation=std::move(result.memory_reservation);
    if(g.loaded_source_stamp_valid) {
        std::error_code error;const auto path=std::filesystem::path(g.source_path);
        if(std::filesystem::file_size(path,error)!=g.loaded_source_size || error ||
           std::filesystem::last_write_time(path,error)!=g.loaded_source_modified || error) {
            result={};result.options=g.frf.options;result.error=lvm::FrfError::SourceChanged;
        }
    }
    g.frf.result = std::move(result); g.frf.pending = false;
    reservation.reset(); // Arrays now enter document resident accounting.
    if (g.frf.result.ok) {
        const auto& f = g.frf.result.common().frequencies;
        const double lo = std::log10(f[1]), hi = std::log10(f.back());
        if (!g.frf.view_initialized || g.frf.log_end <= lo || g.frf.log_start >= hi) {
            g.frf.log_start = lo; g.frf.log_end = hi;
        } else {
            g.frf.log_start = std::max(lo, g.frf.log_start);
            g.frf.log_end = std::min(hi, g.frf.log_end);
        }
        g.frf.frequency_start=std::pow(10.0,g.frf.log_start);
        g.frf.frequency_end=std::pow(10.0,g.frf.log_end);
        g.frf.view_initialized = true;
    }
    refresh_frf_controls();
    if (g.mode == AnalysisMode::FRF) { set_status(); if (g.main) invalidate_plot(); }
}

void poll_frf_result() {
    if (auto r = g_frf_worker.take_result())
        if (r->generation == g.frf.generation) apply_frf_result(std::move(r->frf));
}

void on_frf_processing_changed() {
    ++g.numerical_revision;
    refresh_frf_controls(true);
    if (!g.frf.apply_processing) return;
    invalidate_frf();
    if (g.mode == AnalysisMode::FRF) compute_frf_from_current_source();
}

std::wstring frf_status_text() {
    if (g.frf.pending) return tr(L"Calculating FRF…", L"Вычисление АЧХ…");
    if (!g.frf.result.ok) return gui::frf_error_text(g.frf.result.error);
    wchar_t buf[256]{};
    const auto& r = g.frf.result.common();
    swprintf(buf, 256, tr(L"FRF: %.6g–%.6g Hz | N=%zu | Fs=%.6g Hz | Hann | %ls", L"АЧХ: %.6g–%.6g Гц | N=%zu | Fs=%.6g Гц | Hann | %ls"),
        g.frf.frequency_start, g.frf.frequency_end,
        r.sample_count, 1.0 / r.sample_dt,
        g.frf.apply_processing ? tr(L"Processed", L"С обработкой") : tr(L"Raw", L"Исходные"));
    std::wstring text = buf;
    if (r.gaps_ignored) text = tr(L"Warning: Gaps ignored | ",
        L"Внимание: пропуски времени не учтены | ") + text;
    wchar_t method[160]{};
    swprintf(method,160,tr(L" | %ls L=%zu K=%zu Δf=%.6g Hz overlap=%.0f%%", L" | %ls L=%zu K=%zu Δf=%.6g Гц перекрытие=%.0f%%"),
        r.options.estimator==lvm::FrfEstimator::H1 ? L"H1" : tr(L"Direct", L"Прямой"),
        r.segment_length,r.averages,1.0/(r.sample_dt*r.segment_length),
        100.0*r.overlap_samples/r.segment_length);
    text+=method;
    for (std::size_t i=0;i<g.frf.result.responses.size();++i)
        if (!g.frf.result.responses[i].ok) text+=L" | "+g.frf.output_names[i]+L": "+gui::frf_error_text(g.frf.result.responses[i].error);
    if (r.averages<2) text+=tr(L" | Coherence unavailable: K < 2",L" | Когерентность недоступна: K < 2");
    return text;
}

void create_frf_panel(HWND parent, HINSTANCE instance) {
    WNDCLASSW wc{};
    wc.hInstance = instance; wc.lpfnWndProc = FrfPanelProc;
    wc.lpszClassName = L"AMGraphFrfPanel"; wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    RegisterClassW(&wc);
    g.frf_panel = CreateWindowExW(0, wc.lpszClassName, L"FRF", WS_CHILD | WS_CLIPCHILDREN,
        0, 0, kRightPanel, 400, parent, nullptr, instance, nullptr);
}

void layout_frf_panel() {
    if (!g.frf_panel) return;
    const bool show = g.mode == AnalysisMode::FRF && g.side_panel_visible && !welcome_visible() && g.side_panel_tab == 0;
    if (show) {
        RECT r; GetClientRect(g.main, &r);
        constexpr int tabs_height = 44;
        const int viewport_top=kTopBar+tabs_height,viewport_bottom=r.bottom-kBottomBar-6;
        const int y=viewport_top-g.side_scroll_y;
        const int top=std::max(0,viewport_top-y),bottom=std::min(kFrfChannelContentHeight,viewport_bottom-y);
        MoveWindow(g.frf_panel,r.right-kRightPanel,y,kRightPanel,kFrfChannelContentHeight,FALSE);
        // The role/settings child scrolls with the shared range block and is
        // clipped below the tabs, including partially visible native controls.
        HRGN region=CreateRectRgn(0,top,kRightPanel,std::max(top,bottom));
        if(!SetWindowRgn(g.frf_panel,region,FALSE))DeleteObject(region);
        ShowWindow(g.frf_panel,bottom>top ? SW_SHOW : SW_HIDE);
    } else ShowWindow(g.frf_panel,SW_HIDE);
}

void refresh_frf_controls(bool repopulate) {
    refresh_frf_channel_names();
    if (!g.frf_panel) return;
    label(InputLabel, tr(L"Reference channels", L"Опоры"));
    label(OutputLabel, tr(L"Responses", L"Отклики"));
    label(Processing, tr(L"Apply channel processing", L"Применять обработку каналов"));
    label(EstimatorLabel, tr(L"Estimator",L"Метод")); label(LengthLabel,tr(L"L (0 = Auto)", L"L (0 = Авто)"));
    label(SmoothingLabel, tr(L"Smoothing",L"Сглаживание"));
    label(AxisScaleLabel, tr(L"Frequency axis",L"Ось частоты"));
    label(Reference, tr(L"Show mean reference",L"Показывать среднюю опору"));
    const auto& r=g.frf.result.common();
    wchar_t details[192]{};
    if (r.segment_length && !g.frf.pending) {
        swprintf(details,192,tr(L"%ls · Hann · L=%zu · K=%zu\nΔf=%.6g Hz · overlap=%.0f%% (%zu)", L"%ls · Hann · L=%zu · K=%zu\nΔf=%.6g Гц · перекрытие=%.0f%% (%zu)"),
            r.options.estimator==lvm::FrfEstimator::H1 ? L"H1" : tr(L"Direct", L"Прямой"),
            r.segment_length,r.averages,1.0/(r.sample_dt*r.segment_length),
            100.0*r.overlap_samples/r.segment_length,r.overlap_samples);
        label(Method,details);
    } else label(Method,g.frf.pending ? tr(L"Calculating…",L"Вычисление…") : L"");
    EnableWindow(control(Length),g.frf.options.estimator==lvm::FrfEstimator::H1);
    if (repopulate) {
        SendMessageW(control(Estimator),CB_SETCURSEL,g.frf.options.estimator==lvm::FrfEstimator::H1 ? 0 : 1,0);
        SendMessageW(control(Smoothing),CB_SETCURSEL,smoothing_choice(g.frf.display_smoothing_octaves),0);
        SendMessageW(control(AxisScale),CB_SETCURSEL,g.frf.logarithmic_frequency_axis ? 0 : 1,0);
        label(Length,std::to_wstring(g.frf.options.segment_length).c_str());
    }
    const auto button_text=[&](const std::vector<int>& channels,bool reference) {
        if (channels.empty()) return std::wstring(reference ? tr(L"Choose reference channels…",L"Выбрать опоры…") :
            tr(L"Choose responses…",L"Выбрать отклики…"));
        std::wstring names;
        for (int channel:channels) {
            if (!names.empty()) names+=L", ";
            names+=channel_display_label(channel);
        }
        HWND button=control(reference ? Input : Output);
        if (!button || !g.ui_font)
            return names.size()<=34 ? names+L" ▾" : std::to_wstring(channels.size())+
                tr(L" channels selected ▾",L" каналов выбрано ▾");
        RECT rect{}; GetClientRect(button,&rect);
        HDC dc=GetDC(button); HGDIOBJ previous=SelectObject(dc,g.ui_font);
        SIZE extent{}; GetTextExtentPoint32W(dc,names.c_str(),static_cast<int>(names.size()),&extent);
        SelectObject(dc,previous); ReleaseDC(button,dc);
        if (extent.cx<=rect.right-rect.left-30) return names+L" ▾";
        return std::to_wstring(channels.size())+tr(L" channels selected ▾",L" каналов выбрано ▾");
    };
    label(Input,button_text(g.frf.inputs,true).c_str());
    label(Output,button_text(g.frf.outputs,false).c_str());
    label(InputSummary,g.frf.inputs.size()>1 ? (tr(L"Mean of ",L"Среднее из ")+std::to_wstring(g.frf.inputs.size())+
        tr(L" channels",L" каналов")).c_str() : L"");
    wchar_t source[192]{};
    swprintf(source, 192, tr(L"%ls: %.5g–%.5g s", L"%ls: %.5g–%.5g с"),
        g.frf.from_selection ? tr(L"Interval", L"Участок") : tr(L"Entire recording",L"Вся запись"),
        g.frf.source_start, g.frf.source_end);
    label(Source, source);
    InvalidateRect(control(Processing), nullptr, TRUE);
    InvalidateRect(control(Reference), nullptr, TRUE);
    sync_frequency_view_controls();
}

bool set_frf_frequency_range(double low, double high) {
    if (!g.frf.result.ok || !std::isfinite(low) || !std::isfinite(high) || low <= 0 || high <= low) return false;
    const auto& f = g.frf.result.common().frequencies;
    if (low < f[1] * (1 - 1e-9) || high > f.back() * (1 + 1e-9)) return false;
    g.frf.log_start = std::log10(std::max(low, f[1]));
    g.frf.log_end = std::log10(std::min(high, f.back()));
    g.frf.frequency_start=std::max(low,f[1]);
    g.frf.frequency_end=std::min(high,f.back());
    refresh_frf_controls(); set_status(); if (g.main) invalidate_plot();
    return true;
}
void sync_frf_frequency_limits() {
    if (g.frf.logarithmic_frequency_axis) {
        g.frf.frequency_start=std::pow(10.0,g.frf.log_start);
        g.frf.frequency_end=std::pow(10.0,g.frf.log_end);
    } else {
        g.frf.log_start=std::log10(g.frf.frequency_start);
        g.frf.log_end=std::log10(g.frf.frequency_end);
    }
}
void reset_frf_view() {
    if (!g.frf.result.ok) return;
    g.frf.auto_y = true;
    g.frf.reference_auto_y = true;
    set_frf_frequency_range(g.frf.result.common().frequencies[1], g.frf.result.common().frequencies.back());
}
bool frf_command_supported(int id) {
    switch (id) {
        case IDC_PLAY: case IDM_VISMOOTH:
            return false;
    }
    return true;
}
} // namespace gui
